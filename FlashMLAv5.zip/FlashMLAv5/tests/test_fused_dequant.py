"""
Verify the MODEL1 dequant+gather implementation against the reference.
"""
import sys
sys.path.insert(0, '/home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA')

import types
_mock_cuda = types.ModuleType("flash_mla.cuda")
sys.modules["flash_mla.cuda"] = _mock_cuda

import torch, importlib.util, os

_spec = importlib.util.spec_from_file_location(
    "ref_torch", os.path.join(os.path.dirname(__file__), "..", "flash_mla", "torch", "ref.py"),
)
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)

from tests.quant import quantize_k_cache, dequantize_k_cache, FP8KVCacheLayout

d_qk = 512
layout = FP8KVCacheLayout.MODEL1_FP8Sparse


@torch.inference_mode()
def test_flatten_roundtrip():
    device = torch.device("cuda:0")
    num_blocks, block_size = 4, 64
    N = num_blocks * block_size

    kv_bf16 = torch.randn(num_blocks, block_size, 1, d_qk,
                          dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    kv_fp8_data = quantize_k_cache(kv_bf16, layout)
    kv_ref = dequantize_k_cache(kv_fp8_data, layout).squeeze(2)

    (kv_fp8, kv_bf16, k_u8, d_nope, d_rope,
     n_tiles, t_size, rope_off, pg_bytes, bs, bpt) = ref_torch._get_cache_views(kv_fp8_data)

    # Extract scale bytes for verification (using same slice logic as old _flatten_kvcache)
    flat = kv_fp8_data.view(num_blocks, -1)
    k_scale = (
        flat[:, bs * bpt:]
        .view(num_blocks, bs, 8)[:, :, :n_tiles]
        .reshape(N, n_tiles)
        .view(torch.uint8)
    )
    # Reconstruct: gather nope+rope from flat as_strided views using page-level indexing
    nope_fp8_vals = torch.empty(N, d_nope, dtype=torch.float32, device=device)
    rope_vals = torch.empty(N, d_rope, dtype=torch.bfloat16, device=device)
    scale_f32 = torch.pow(2.0, k_scale.float() - 127.0)

    for i in range(N):
        pg = i // bs
        po = i % bs
        nope_byte_base = pg * pg_bytes + po * bpt
        rope_byte_base = nope_byte_base + d_nope
        nope_fp8_vals[i] = kv_fp8[nope_byte_base : nope_byte_base + d_nope].float()
        rope_vals[i] = kv_bf16[rope_byte_base // 2 : rope_byte_base // 2 + d_rope]

    for ti in range(n_tiles):
        t_off = ti * t_size
        nope_fp8_vals[:, t_off:t_off + t_size] *= scale_f32[:, ti:ti + 1]

    reconstructed = torch.cat([nope_fp8_vals.to(torch.bfloat16), rope_vals], dim=1)
    diff = (reconstructed.float() - kv_ref.float().reshape(N, d_qk)).abs()
    print(f"flatten round-trip: max_diff={diff.max():.6f}")
    assert diff.max() < 0.1, f"FAIL: max_diff={diff.max()}"
    print("flatten_roundtrip test PASSED\n")


@torch.inference_mode()
def test_fused_gather():
    device = torch.device("cuda:0")
    num_blocks, block_size = 8, 64
    N = num_blocks * block_size

    kv_bf16 = torch.randn(num_blocks, block_size, 1, d_qk,
                          dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    kv_fp8_data = quantize_k_cache(kv_bf16, layout)
    kv_ref = dequantize_k_cache(kv_fp8_data, layout)

    (kv_fp8, kv_bf16, k_u8, d_nope, d_rope,
     n_tiles, t_size, rope_off, pg_bytes, bs, bpt) = ref_torch._get_cache_views(kv_fp8_data)

    topk = 32
    perm = torch.randperm(N, device=device)[:topk]
    indices = perm.view(1, 1, topk).contiguous()

    gathered_fused, _ = ref_torch._fused_gather_kv(
        kv_fp8, kv_bf16, k_u8, indices, None,
        d_nope, d_rope, n_tiles, t_size, rope_off, pg_bytes, bs, bpt,
    )

    kv_ref_flat = kv_ref.squeeze(2).reshape(-1, d_qk)
    expected = kv_ref_flat[perm].view(1, 1, topk, d_qk)

    diff = (gathered_fused.float() - expected.float()).abs()
    print(f"fused_gather: max_diff={diff.max():.6f}")
    assert diff.max() < 0.1, f"FAIL: max_diff={diff.max()}"
    print("fused_gather test PASSED\n")


@torch.inference_mode()
def test_decode_end_to_end():
    device = torch.device("cuda:0")
    block_size, topk = 64, 64
    b, s_q, h_q, d_v = 2, 1, 16, 512
    num_blocks = max(topk * 2 // block_size, 4)

    q = torch.randn(b, s_q, h_q, d_qk, dtype=torch.bfloat16, device=device)
    kv_bf16 = torch.randn(num_blocks, block_size, 1, d_qk,
                          dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    k_cache = quantize_k_cache(kv_bf16, layout)
    N = num_blocks * block_size
    indices = torch.randint(0, N, (b, s_q, topk), dtype=torch.int32, device=device)
    softmax_scale = d_qk ** (-0.5)
    attn_sink = torch.randn(h_q, dtype=torch.float32, device=device)

    out_new, lse_new = ref_torch.flash_mla_decode_torch(
        q=q, k_cache=k_cache, indices=indices,
        head_dim_v=d_v, softmax_scale=softmax_scale, attn_sink=attn_sink,
    )

    kv_deq = dequantize_k_cache(k_cache, layout)
    kv_flat = kv_deq.view(-1, d_qk)
    gathered = kv_flat[indices.view(-1)].view(b, s_q, topk, d_qk).float()
    gathered[gathered != gathered] = 0.0
    q_flat = q.float().view(b * s_q, h_q, d_qk)
    gkv_flat = gathered.view(b * s_q, topk, d_qk)
    attn_w = q_flat @ gkv_flat.transpose(-1, -2) * softmax_scale
    lse_ref = attn_w.logsumexp(dim=-1)
    attn_w = torch.exp(attn_w - lse_ref.unsqueeze(-1))
    out_ref = attn_w @ gkv_flat[..., :d_v]
    out_ref = out_ref.view(b, s_q, h_q, d_v)
    lse_ref = lse_ref.view(b, s_q, h_q)
    if attn_sink is not None:
        out_ref *= (1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - lse_ref))).unsqueeze(-1)
    out_ref = out_ref.to(torch.bfloat16)
    lse_ref = lse_ref.transpose(1, 2)

    out_diff = (out_new.float() - out_ref.float()).abs()
    lse_diff = (lse_new.float() - lse_ref.float()).abs()
    print(f"decode: out max={out_diff.max():.6f} mean={out_diff.mean():.6f}")
    print(f"decode: lse max={lse_diff.max():.6f} mean={lse_diff.mean():.6f}")
    assert out_diff.max() < 0.5, "FAIL"
    print("decode_end_to_end test PASSED\n")


if __name__ == "__main__":
    test_flatten_roundtrip()
    test_fused_gather()
    test_decode_end_to_end()
