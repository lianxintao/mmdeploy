"""
3-way comparison — V2 (DSv4 shapes): Triton fused vs optimized torch vs original torch.

DSv4 shapes:
  q:          [b, 1, 64, 512]
  k_cache:    [num_swa_pages, 256, 1, 584]
  indices:    [b, 1, 128]
  extra (C128): k_cache [N, 2, 1, 584]     indices [b, 1, 8256]
  extra (C4):   k_cache [N, 64, 1, 584]    indices [b, 1, 512] or [b, 1, 64]

Usage:
    python tests/compare_three_methods_v2.py
"""
import sys, os, time, types
from typing import Optional, Tuple

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

_mock_cuda = types.ModuleType("flash_mla.cuda")
sys.modules["flash_mla.cuda"] = _mock_cuda

import torch, importlib.util

_spec = importlib.util.spec_from_file_location(
    "ref_torch", os.path.join(os.path.dirname(__file__), "..", "flash_mla", "torch", "ref.py"),
)
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)

_spec2 = importlib.util.spec_from_file_location(
    "triton_kernel", os.path.join(os.path.dirname(__file__), "..", "flash_atten", "triton_kernel.py"),
)
triton_kernel = importlib.util.module_from_spec(_spec2)
_spec2.loader.exec_module(triton_kernel)

from tests.quant import quantize_k_cache, dequantize_k_cache, FP8KVCacheLayout

# ── DSv4 Constants ──────────────────────────────────────────────────────────
D_QK = 512
D_NOPE = 448
D_ROPE = 64
D_V = 512
H_Q = 64
LAYOUT = FP8KVCacheLayout.MODEL1_FP8Sparse  # 584B/token, ceil_div(ps*584,576)*576 per page


# ═══════════════════════════════════════════════════════════════════════════════
# KV cache builder (originally from compare_three_methods.py, adapted for DSv4)
# ═══════════════════════════════════════════════════════════════════════════════

def build_fp8_kv_cache(kv_bf16: torch.Tensor, page_size: int):
    """Build FP8 KV cache compatible with all three implementations (vectorized).

    DSv4 layout per token: 448 FP8 nope + 128 BF16 rope + 8 UE8M0 scales = 584 bytes.
    Page layout: ceil_div(page_size * 584, 576) * 576 bytes.
    """
    total_tokens = kv_bf16.shape[0]
    num_pages = (total_tokens + page_size - 1) // page_size
    pad_len = num_pages * page_size - total_tokens

    if pad_len > 0:
        kv_bf16 = torch.cat([
            kv_bf16,
            torch.zeros(pad_len, D_QK, dtype=torch.bfloat16, device=kv_bf16.device),
        ], dim=0)

    N = num_pages * page_size
    kv_bf16 = kv_bf16.view(N, D_QK).clone()
    nope_bf16 = kv_bf16[:, :D_NOPE]
    rope_bf16 = kv_bf16[:, D_NOPE:]

    # Quantize nope per-group (7 groups of 64)
    nope_fp8 = torch.empty(N, D_NOPE, dtype=torch.float8_e4m3fn, device=kv_bf16.device)
    scales_ue8m0 = torch.empty(N, D_NOPE // 64, dtype=torch.uint8, device=kv_bf16.device)
    for g in range(D_NOPE // 64):
        gs, ge = g * 64, (g + 1) * 64
        chunk = nope_bf16[:, gs:ge].float()
        amax = chunk.abs().max(dim=-1).values.clamp(min=1e-8)
        scale = amax / 448.0
        nope_fp8[:, gs:ge] = (chunk / scale.unsqueeze(-1)).to(torch.float8_e4m3fn)
        raw = torch.clamp(scale.log2().ceil() + 127, 1, 254).to(torch.uint8)
        scales_ue8m0[:, g] = raw

    # DSv4 page: ceil_div(page_size * 584, 576) * 576 bytes
    bytes_per_token = D_NOPE + D_ROPE * 2 + 8  # 448 + 128 + 8 = 584
    page_total = (page_size * bytes_per_token + 575) // 576 * 576
    raw = torch.zeros(num_pages * page_total, dtype=torch.uint8, device=kv_bf16.device)
    raw_view = raw.view(num_pages, page_total)

    nope_bytes = nope_fp8.view(torch.uint8).view(N, D_NOPE)
    rope_bytes = rope_bf16.view(torch.uint8).view(N, D_ROPE * 2)
    scales = scales_ue8m0.view(N, D_NOPE // 64)

    nope_paged = nope_bytes.view(num_pages, page_size, D_NOPE)
    rope_paged = rope_bytes.view(num_pages, page_size, D_ROPE * 2)
    scales_paged = scales.view(num_pages, page_size, D_NOPE // 64)

    raw_view[:, :page_size * bytes_per_token] = (
        raw_view[:, :page_size * bytes_per_token]
        .view(num_pages, page_size, bytes_per_token)
    )
    tmp = raw_view[:, :page_size * bytes_per_token].view(num_pages, page_size, bytes_per_token)
    tmp[:, :, :D_NOPE] = nope_paged
    tmp[:, :, D_NOPE:D_NOPE + D_ROPE * 2] = rope_paged
    tmp[:, :, D_NOPE + D_ROPE * 2:D_NOPE + D_ROPE * 2 + (D_NOPE // 64)] = scales_paged

    k_cache = raw.view(torch.float8_e4m3fn).view(num_pages, page_total, 1)
    k_cache = k_cache[:, :page_size * bytes_per_token, :].view(num_pages, page_size, 1, bytes_per_token)
    return k_cache, kv_bf16


# ═══════════════════════════════════════════════════════════════════════════════
# Method A: Triton fused kernel
# ═══════════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def method_triton_kernel(q, k_cache, indices, topk_length, attn_sink, softmax_scale,
                         extra_k_cache=None, extra_indices=None, extra_topk_length=None):
    return triton_kernel.flash_mla_sparse_decode_triton(
        q, k_cache, indices, topk_length, attn_sink,
        D_V, softmax_scale,
        extra_k_cache=extra_k_cache,
        extra_indices=extra_indices,
        extra_topk_length=extra_topk_length,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Method B: Optimized torch
# ═══════════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def method_torch_opt(q, k_cache, indices, topk_length, attn_sink, softmax_scale,
                     extra_k_cache=None, extra_indices=None, extra_topk_length=None):
    if indices.ndim == 2:
        indices_3d = indices.unsqueeze(1)
    else:
        indices_3d = indices
    if extra_indices is not None and extra_indices.ndim == 2:
        extra_indices_3d = extra_indices.unsqueeze(1)
    else:
        extra_indices_3d = extra_indices
    out, lse = ref_torch.flash_mla_decode_torch(
        q=q, k_cache=k_cache, indices=indices_3d,
        head_dim_v=D_V, softmax_scale=softmax_scale, attn_sink=attn_sink,
        extra_k_cache=extra_k_cache, extra_indices=extra_indices_3d,
        topk_length=topk_length, extra_topk_length=extra_topk_length,
    )
    return out, lse


# ═══════════════════════════════════════════════════════════════════════════════
# Method C: Original torch (dequantize all + gather)
# ═══════════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def method_torch_orig(q, k_cache, indices, topk_length, attn_sink, softmax_scale,
                      extra_k_cache=None, extra_indices=None, extra_topk_length=None):
    b, s_q, h_q, d_qk = q.shape
    topk = indices.shape[-1]

    if indices.ndim == 2:
        indices_3d = indices.unsqueeze(1)
    else:
        indices_3d = indices

    def gather_and_dequant(kc, idx, tl):
        kv_deq = dequantize_k_cache(kc, LAYOUT)
        kv_flat = kv_deq.view(-1, d_qk)
        tk = idx.shape[-1]
        gathered = kv_flat[idx.view(-1)].view(b, s_q, tk, d_qk).float()
        gathered[gathered != gathered] = 0.0
        invalid = idx < 0
        if tl is not None:
            invalid |= torch.arange(tk, device=idx.device).view(1, 1, -1) >= tl.view(b, 1, 1)
        return gathered, invalid

    gkv, inv = gather_and_dequant(k_cache, indices_3d, topk_length)
    if extra_k_cache is not None:
        if extra_indices.ndim == 2:
            extra_indices_3d = extra_indices.unsqueeze(1)
        else:
            extra_indices_3d = extra_indices
        egkv, einv = gather_and_dequant(extra_k_cache, extra_indices_3d, extra_topk_length)
        gkv = torch.cat([gkv, egkv], dim=2)
        inv = torch.cat([inv, einv], dim=2)
    total_topk = gkv.shape[2]

    q_flat = q.float().view(b * s_q, h_q, d_qk)
    gkv_flat = gkv.view(b * s_q, total_topk, d_qk)
    attn = q_flat @ gkv_flat.transpose(-1, -2)
    attn *= softmax_scale
    attn[inv.view(b * s_q, 1, total_topk).broadcast_to(b * s_q, h_q, total_topk)] = float("-inf")

    lse = attn.logsumexp(dim=-1)
    attn = torch.exp(attn - lse.unsqueeze(-1))
    out = attn @ gkv_flat[..., :D_V]
    out = out.view(b, s_q, h_q, D_V)
    lse = lse.view(b, s_q, h_q)

    if attn_sink is not None:
        out *= (1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - lse))).unsqueeze(-1)

    lonely = lse == float("-inf")
    out[lonely.unsqueeze(-1).broadcast_to(b, s_q, h_q, D_V)] = 0.0
    lse[lonely] = float("+inf")

    return out.to(torch.bfloat16), lse.transpose(1, 2)


# ═══════════════════════════════════════════════════════════════════════════════
# Test runner
# ═══════════════════════════════════════════════════════════════════════════════

def make_indices(b, total_padded, topk, device):
    indices = torch.full((b, topk), -1, dtype=torch.int32, device=device)
    for ib in range(b):
        n_valid = min(total_padded, topk)
        perm = torch.randperm(total_padded, device=device)[:n_valid]
        indices[ib, :n_valid] = perm.to(torch.int32)
    return indices


@torch.inference_mode()
def compare(desc, b, kv_tokens, topk_swa, extra_cfg,
            use_sink=True, use_topk_len=True, num_bench=100):
    """Run 3-way comparison for one config.

    Parameters
    ----------
    extra_cfg: None | ("c128", topk, kv_tokens, page_size) |
                     ("c4", topk, kv_tokens, page_size)
    """
    device = torch.device("cuda:0")
    softmax_scale = D_QK ** -0.5
    page_size_swa = 256

    # ── Q ────────────────────────────────────────────────────────────────
    q = torch.randn(b, 1, H_Q, D_QK, dtype=torch.bfloat16, device=device) / 10

    # ── Main SWA cache ──────────────────────────────────────────────────
    kv_bf16 = torch.randn(kv_tokens, D_QK, dtype=torch.bfloat16, device=device) / 10
    k_cache, kv_bf16_padded = build_fp8_kv_cache(kv_bf16, page_size_swa)
    total_padded = kv_bf16_padded.shape[0]

    # ── SWA indices ─────────────────────────────────────────────────────
    indices = make_indices(b, total_padded, topk_swa, device)

    # ── Topk length ─────────────────────────────────────────────────────
    topk_length = None
    if use_topk_len:
        topk_length = torch.randint(topk_swa // 2 + 1, topk_swa + 1, (b,), dtype=torch.int32, device=device)

    # ── Attn sink ───────────────────────────────────────────────────────
    attn_sink = torch.randn(H_Q, dtype=torch.float32, device=device) if use_sink else None

    # ── Extra cache ─────────────────────────────────────────────────────
    ek, ei, etl = None, None, None
    if extra_cfg is not None:
        emode, etopk, e_kv, epg = extra_cfg
        ekv_bf16 = torch.randn(e_kv, D_QK, dtype=torch.bfloat16, device=device) / 10
        ek, ekv_padded = build_fp8_kv_cache(ekv_bf16, epg)
        e_total = ekv_padded.shape[0]
        ei = make_indices(b, e_total, etopk, device)
        if use_topk_len:
            etl = torch.randint(max(1, etopk // 4), etopk + 1, (b,), dtype=torch.int32, device=device)

    print(f"\n{'='*70}")
    print(f"  {desc}")
    print(f"  q=[{b},1,{H_Q},{D_QK}]  k_cache=[{k_cache.shape[0]},{page_size_swa},1,584]"
          f"  indices=[{b},1,{topk_swa}]")
    if ek is not None:
        print(f"  extra_k_cache={list(ek.shape)}  extra_indices=[{b},1,{etopk}]"
              f"  extra_page_size={epg}")
    print(f"{'='*70}")

    results = {}
    for name, fn in [
        ("torch_orig", method_torch_orig),
        ("torch_opt",  method_torch_opt),
        ("triton_kernel", method_triton_kernel),
    ]:
        try:
            out, lse = fn(q, k_cache, indices, topk_length, attn_sink, softmax_scale,
                         ek, ei, etl)
            for _ in range(5):
                fn(q, k_cache, indices, topk_length, attn_sink, softmax_scale,
                   ek, ei, etl)
            torch.cuda.synchronize()
            t0 = time.perf_counter()
            for _ in range(num_bench):
                fn(q, k_cache, indices, topk_length, attn_sink, softmax_scale,
                   ek, ei, etl)
            torch.cuda.synchronize()
            elapsed = (time.perf_counter() - t0) * 1000 / num_bench
            results[name] = {"out": out, "lse": lse, "ms": elapsed}
            print(f"  {name:<18} {elapsed:>8.3f} ms")
        except Exception as e:
            print(f"  {name:<18} ERROR: {e}")
            import traceback; traceback.print_exc()

    # ── Error comparison ──────────────────────────────────────────────────
    if len(results) >= 2:
        print(f"\n  {'─'*50}")
        print(f"  Error comparison (vs torch_orig as reference)")
        print(f"  {'─'*50}")
        ref = results.get("torch_orig")
        if ref is not None:
            for name in ["torch_opt", "triton_kernel"]:
                r = results.get(name)
                if r is None:
                    continue
                out_ref = ref["out"].float()
                lse_ref = ref["lse"].float()
                out_cmp = r["out"].float()
                lse_cmp = r["lse"].float()
                if out_cmp.shape != out_ref.shape:
                    out_cmp = out_cmp.view_as(out_ref)
                if lse_cmp.shape != lse_ref.shape:
                    lse_cmp = lse_cmp.view_as(lse_ref)
                out_diff = (out_cmp - out_ref).abs()
                lse_diff = (lse_cmp - lse_ref).abs()
                out_diff = torch.nan_to_num(out_diff, nan=0.0, posinf=float("inf"), neginf=0.0)
                lse_diff = torch.nan_to_num(lse_diff, nan=0.0, posinf=float("inf"), neginf=0.0)
                print(f"  {name} vs torch_orig:")
                print(f"    out max_err={out_diff.max():.4e}  mean_err={out_diff.mean():.4e}")
                print(f"    lse max_err={lse_diff.max():.4e}  mean_err={lse_diff.mean():.4e}")

    # ── Speed comparison ──────────────────────────────────────────────────
    if len(results) >= 2:
        print(f"\n  {'─'*50}")
        print(f"  Speed comparison")
        print(f"  {'─'*50}")
        orig_ms = results.get("torch_orig", {}).get("ms", None)
        if orig_ms is not None:
            for name in ["torch_opt", "triton_kernel"]:
                r = results.get(name)
                if r is None:
                    continue
                speedup = orig_ms / r["ms"]
                print(f"  {name} vs torch_orig: {speedup:.2f}x "
                      f"({'faster' if speedup > 1 else 'slower'} "
                      f"({orig_ms:.3f} → {r['ms']:.3f} ms)")

    return results


def main():
    if not torch.cuda.is_available():
        print("CUDA not available.")
        return

    device = torch.device("cuda:0")
    torch.set_default_dtype(torch.bfloat16)
    torch.set_default_device(device)
    torch.cuda.set_device(device)
    torch.set_float32_matmul_precision("high")

    print("=" * 70)
    print("3-Way Comparison V2 — DSv4 Shapes")
    print(f"  d_qk={D_QK}  d_nope={D_NOPE}  d_rope={D_ROPE}  d_v={D_V}  h_q={H_Q}")
    print(f"  GPU: {torch.cuda.get_device_name(0)}")
    print("=" * 70)

    # (desc, b, kv_tokens, topk_swa, extra_cfg, use_sink, use_topk_len, num_bench)
    configs = [
        # ── SWA-only ──────────────────────────────────────────────────────
        ("SWA b=1  topk=128  kv=32K",  1, 32768, 128, None, True, False, 200),
        ("SWA b=4  topk=128  kv=32K",  4, 32768, 128, None, True, False, 100),
        ("SWA b=16 topk=128  kv=32K", 16, 32768, 128, None, True, False,  50),
        ("SWA b=32 topk=128  kv=32K", 32, 32768, 128, None, True, False,  30),

        # ── C128 extra ────────────────────────────────────────────────────
        ("C128 b=1  topk=128+8256  kv=32K+15K",
         1, 32768, 128, ("c128", 8256, 15000, 2), True, False, 100),
        ("C128 b=4  topk=128+8256  kv=32K+15K",
         4, 32768, 128, ("c128", 8256, 15000, 2), True, False,  50),
        ("C128 b=8  topk=128+8256  kv=32K+15K",
         8, 32768, 128, ("c128", 8256, 15000, 2), True, False,  30),
        ("C128 b=16 topk=128+8256  kv=32K+15K",
         16, 32768, 128, ("c128", 8256, 15000, 2), True, False,  20),

        # ── C4 extra ──────────────────────────────────────────────────────
        ("C4 b=1  topk=128+512  kv=32K+480K",
         1, 32768, 128, ("c4", 512, 480000, 64), True, False, 100),
        ("C4 b=4  topk=128+512  kv=32K+480K",
         4, 32768, 128, ("c4", 512, 480000, 64), True, False,  50),
        ("C4 b=8  topk=128+512  kv=32K+480K",
         8, 32768, 128, ("c4", 512, 480000, 64), True, False,  30),
        ("C4 b=16 topk=128+512  kv=32K+480K",
         16, 32768, 128, ("c4", 512, 480000, 64), True, False,  20),

        # ── C4 extra small topk ───────────────────────────────────────────
        ("C4 b=4  topk=128+64  kv=32K+480K",
         4, 32768, 128, ("c4", 64, 480000, 64), True, False,  50),

        # ── Both extra ────────────────────────────────────────────────────
        # This tests the interface shape variety — SWA indices + C128 extra
        ("SWA+C128 b=4  topk=128+8256",
         4, 32768, 128, ("c128", 8256, 15000, 2), True, True,  50),
    ]

    all_ok = True
    for cfg in configs:
        try:
            results = compare(*cfg)
            ref = results.get("torch_orig")
            opt = results.get("torch_opt")
            if ref and opt:
                diff = (opt["out"].float() - ref["out"].float()).abs().max()
                if diff > 0.5:
                    print(f"  ⚠ torch_opt large deviation: {diff:.4f}")
                    all_ok = False
        except Exception as e:
            print(f"  FAILED: {e}")
            all_ok = False

    print(f"\n{'='*70}")
    if all_ok:
        print("All comparisons completed successfully")
    else:
        print("Some comparisons had issues — check above")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
