"""
Benchmark: deep-merged dequant+gather vs separate dequantize + gather.
"""
import sys, types, time, os
sys.path.insert(0, '/home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA')

_mock_cuda = types.ModuleType('flash_mla.cuda')
sys.modules['flash_mla.cuda'] = _mock_cuda

import torch, importlib.util

_spec = importlib.util.spec_from_file_location(
    'ref_torch', os.path.join(os.path.dirname(__file__), '..', 'flash_mla', 'torch', 'ref.py'),
)
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)

from tests.quant import quantize_k_cache, dequantize_k_cache, FP8KVCacheLayout


@torch.inference_mode()
def bench(desc: str, fn, warmup=5, iters=100):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(iters):
        fn()
    torch.cuda.synchronize()
    elapsed_ms = (time.perf_counter() - t0) * 1000 / iters
    print(f"  {desc}: {elapsed_ms:.3f} ms")
    return elapsed_ms


def main():
    device = torch.device("cuda:0")

    for d_qk in [576, 512]:
        if d_qk == 576:
            layout = FP8KVCacheLayout.V32_FP8Sparse
            block_size, topk = 128, 2048
        else:
            layout = FP8KVCacheLayout.MODEL1_FP8Sparse
            block_size, topk = 64, 128

        b, s_q, h_q, d_v = 74, 2, 128, 512
        s_k = 32768 if d_qk == 576 else 16384
        num_blocks = s_k // block_size

        print(f"\n{'='*60}")
        print(f"d_qk={d_qk}, b={b}, s_q={s_q}, h_q={h_q}")
        print(f"s_k={s_k}, block_size={block_size}, num_blocks={num_blocks}")
        print(f"{'='*60}")

        kv_bf16 = torch.randn(num_blocks, block_size, 1, d_qk,
                              dtype=torch.bfloat16, device=device).clamp_(-1, 1)
        k_cache = quantize_k_cache(kv_bf16, layout)
        indices = torch.randint(0, num_blocks * block_size,
                                (b, s_q, topk), dtype=torch.int32, device=device)

        # ---- Old: dequantize ALL tokens ----
        bench(f"old: dequantize ALL ({num_blocks * block_size} tokens)",
              lambda: dequantize_k_cache(k_cache, layout), iters=20)

        # ---- New: get cache views ----
        bench("new: get cache views (overlapping views)",
              lambda: ref_torch._get_cache_views(k_cache), iters=100)

        # ---- Old: dequant + gather ----
        def old_full():
            kv_deq = dequantize_k_cache(k_cache, layout)
            kv_flat = kv_deq.view(-1, d_qk)
            return kv_flat[indices.view(-1)].view(b, s_q, topk, d_qk)

        bench(f"old: dequant + gather ({b * s_q * topk} tok)", old_full, iters=20)

        # ---- New: fused ----
        def new_full():
            kv_fp8, kv_bf16, k_u8, dn, dr, nt, ts, ro, pg_bytes, bs, bpt = ref_torch._get_cache_views(k_cache)
            return ref_torch._fused_gather_kv(
                kv_fp8, kv_bf16, k_u8, indices, None, dn, dr, nt, ts, ro,
                pg_bytes, bs, bpt,
            )

        bench(f"new: fused dequant+gather ({b * s_q * topk} tok)", new_full, iters=100)

        # ---- End-to-end ----
        q = torch.randn(b, s_q, h_q, d_qk, dtype=torch.bfloat16, device=device)
        ss = d_qk ** (-0.5)
        sink = torch.randn(h_q, dtype=torch.float32, device=device)

        bench("new: full decode", lambda: ref_torch.flash_mla_decode_torch(
            q=q, k_cache=k_cache, indices=indices, head_dim_v=d_v,
            softmax_scale=ss, attn_sink=sink,
        ), iters=50)


if __name__ == "__main__":
    main()
