"""
First C128 benchmark (B=32, topk=8256) — BEFORE BLOCK_TK cap fix.
This script exposed the BLOCK_TK=256 register-spill issue:
  gather_extra was 14-16ms for B=1,4,32 (but anomalously 0.28ms for B=8).

Root cause: BLOCK_TK=256 was too large, causing ~1792 tile-ops per program.
Fixed by capping BLOCK_TK at 128.
"""
import sys, types, time, os
sys.path.insert(0, '/home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA')
_mock_cuda = types.ModuleType('flash_mla.cuda')
sys.modules['flash_mla.cuda'] = _mock_cuda

import torch, importlib.util
_spec = importlib.util.spec_from_file_location(
    'ref_torch', os.path.join(os.path.dirname(__file__) if '__file__' in dir() else '.',
        'flash_mla', 'torch', 'ref.py'))
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)
from tests.quant import quantize_k_cache, FP8KVCacheLayout

device = torch.device('cuda:0')
layout = FP8KVCacheLayout.MODEL1_FP8Sparse
d_qk, d_v, h_q = 512, 512, 64
softmax_scale = d_qk ** (-0.5)

for b in [1, 4, 8, 32]:
    s_q = 1
    swa_tokens = 751 * 256  # 192,256
    c128_tokens = 7503 * 2  # 15,006
    main_topk, extra_topk = 128, 8256
    total_topk = main_topk + extra_topk  # 8384

    kv_swa = torch.randn(751, 256, 1, d_qk, dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    k_cache = quantize_k_cache(kv_swa, layout)
    kv_c128 = torch.randn(7503, 2, 1, d_qk, dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    extra_k_cache = quantize_k_cache(kv_c128, layout)

    q = torch.randn(b, s_q, h_q, d_qk, dtype=torch.bfloat16, device=device)
    indices = torch.randint(0, swa_tokens, (b, s_q, main_topk), dtype=torch.int32, device=device)
    extra_indices = torch.randint(0, c128_tokens, (b, s_q, extra_topk), dtype=torch.int32, device=device)
    attn_sink = torch.randn(h_q, dtype=torch.float32, device=device)

    views = ref_torch._get_cache_views(k_cache)
    eviews = ref_torch._get_cache_views(extra_k_cache)

    # Warmup (all B use same kernels, compiled on B=1)
    for _ in range(10):
        ref_torch.flash_mla_decode_torch(
            q=q, k_cache=k_cache, indices=indices, head_dim_v=d_v,
            softmax_scale=softmax_scale, attn_sink=attn_sink,
            extra_k_cache=extra_k_cache, extra_indices=extra_indices,
        )
    torch.cuda.synchronize()

    iters = 50

    # 1) Gather main only
    t0 = time.perf_counter()
    for _ in range(iters):
        ref_torch._fused_gather_kv(*views[:3], indices, None, *views[3:])
    torch.cuda.synchronize()
    t_gather_main = (time.perf_counter() - t0) * 1000 / iters

    # 2) Gather extra only
    t0 = time.perf_counter()
    for _ in range(iters):
        ref_torch._fused_gather_kv(*eviews[:3], extra_indices, None, *eviews[3:])
    torch.cuda.synchronize()
    t_gather_extra = (time.perf_counter() - t0) * 1000 / iters

    # 3) Full decode
    t0 = time.perf_counter()
    for _ in range(iters):
        ref_torch.flash_mla_decode_torch(
            q=q, k_cache=k_cache, indices=indices, head_dim_v=d_v,
            softmax_scale=softmax_scale, attn_sink=attn_sink,
            extra_k_cache=extra_k_cache, extra_indices=extra_indices,
        )
    torch.cuda.synchronize()
    t_full = (time.perf_counter() - t0) * 1000 / iters

    # 4) Attention only
    gathered_kv = torch.empty(b, s_q, total_topk, d_qk, dtype=torch.bfloat16, device=device)
    invalid_mask = torch.empty(b, s_q, total_topk, dtype=torch.bool, device=device)
    ref_torch._fused_gather_kv(*views[:3], indices, None, *views[3:],
        gathered_kv_out=gathered_kv, invalid_mask_out=invalid_mask, write_offset_tk=0)
    ref_torch._fused_gather_kv(*eviews[:3], extra_indices, None, *eviews[3:],
        gathered_kv_out=gathered_kv, invalid_mask_out=invalid_mask, write_offset_tk=main_topk)

    def attn_only():
        q_flat = q.reshape(b*s_q, h_q, d_qk)
        kv_flat = gathered_kv.reshape(b*s_q, total_topk, d_qk)
        aw = (q_flat @ kv_flat.transpose(-1, -2)) * softmax_scale
        aw[invalid_mask.reshape(b*s_q, 1, total_topk).broadcast_to(b*s_q, h_q, total_topk)] = float('-inf')
        lse = aw.logsumexp(dim=-1)
        aw = torch.exp(aw - lse.unsqueeze(-1))
        out = aw.to(torch.bfloat16) @ kv_flat[..., :d_v]
        out = out.reshape(b, s_q, h_q, d_v)
        lse = lse.reshape(b, s_q, h_q)
        if attn_sink is not None:
            out *= (1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - lse))).unsqueeze(-1)
        return out, lse

    for _ in range(10): attn_only()
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(iters): attn_only()
    torch.cuda.synchronize()
    t_attn = (time.perf_counter() - t0) * 1000 / iters

    print(f'B={b:2d} | gather_main={t_gather_main:.4f}  gather_extra={t_gather_extra:.4f}  '
          f'attn={t_attn:.4f}  full={t_full:.4f} ms  '
          f'| QK^T:[{b*s_q}, {h_q}, {d_qk}] @ [{b*s_q}, {d_qk}, {total_topk}]')

    del k_cache, extra_k_cache, kv_swa, kv_c128
    torch.cuda.empty_cache()

print()
print('Note: gather_extra >= 14ms for B=1,4,32 is a BLOCK_TK=256 register-spill bug.')
print('Fixed by capping BLOCK_TK at 128 in _fused_gather_kv.')
" 2>&1