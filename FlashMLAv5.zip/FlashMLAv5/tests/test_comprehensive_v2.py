"""
Comprehensive correctness test with edge cases — V2 (DSv4 shapes).

DSv4-specific shapes:
  q:          [b, 1, 64, 512]
  k_cache:    [751, 256, 1, 584]  — SWA, page_size=256
  indices:    [b, 1, 128]         — SWA window=128
  extra (C128): k_cache [7503, 2, 1, 584]   indices [b, 1, 8256]
  extra (C4):   k_cache [7503, 64, 1, 584]  indices [b, 1, 512] or [b, 1, 64]
"""
import sys, types, os
sys.path.insert(0, '/home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA')

_mock_cuda = types.ModuleType('flash_mla.cuda')
sys.modules['flash_mla.cuda'] = _mock_cuda

import torch, importlib.util

_spec = importlib.util.spec_from_file_location(
    'ref_torch', os.path.join(os.path.dirname(__file__), '..', 'flash_mla', 'torch', 'ref.py'),
)
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)

from tests.quant import quantize_k_cache, dequantize_k_cache, FP8KVCacheLayout

# ── DSv4 constants ─────────────────────────────────────────────────────────
D_QK = 512          # q head_dim = nope(448) + rope(64)
D_V = 512           # v head_dim
H_Q = 64            # num Q heads (MLA: 64 Q heads → 1 KV head)
LAYOUT = FP8KVCacheLayout.MODEL1_FP8Sparse  # d=512, d_nope=448, d_rope=64, tile=64, ntiles=7


def compute_ref_output(q, k_cache, indices, head_dim_v, softmax_scale,
                       attn_sink=None, topk_length=None,
                       extra_k_cache=None, extra_indices=None, extra_topk_length=None):
    """Reference: dequant + gather + PyTorch attention (unchanged from original)."""
    b, s_q, h_q, d_qk = q.shape
    d_v = head_dim_v

    def gather_and_dequant(kc, idx, tl):
        kv_deq = dequantize_k_cache(kc, LAYOUT)
        kv_flat = kv_deq.view(-1, d_qk)
        topk = idx.shape[-1]
        gathered = kv_flat[idx.view(-1)].view(b, s_q, topk, d_qk).float()
        invalid = idx < 0
        if tl is not None:
            invalid |= torch.arange(topk, device=idx.device).view(1, 1, -1) >= tl.view(b, 1, 1)
        gathered[gathered != gathered] = 0.0
        return gathered, invalid

    gkv, inv = gather_and_dequant(k_cache, indices, topk_length)
    if extra_k_cache is not None:
        egkv, einv = gather_and_dequant(extra_k_cache, extra_indices, extra_topk_length)
        gkv = torch.cat([gkv, egkv], dim=2)
        inv = torch.cat([inv, einv], dim=2)
    total_topk = gkv.shape[2]

    q_flat = q.float().view(b * s_q, h_q, d_qk)
    gkv_flat = gkv.view(b * s_q, total_topk, d_qk)
    attn = q_flat @ gkv_flat.transpose(-1, -2)
    attn *= softmax_scale
    attn[inv.view(b * s_q, 1, total_topk).broadcast_to(b * s_q, h_q, total_topk)] = float("-inf")
    lse = attn.logsumexp(dim=-1)
    attn = torch.exp(attn - lse.unsqueeze(-1))
    out = attn @ gkv_flat[..., :d_v]
    out = out.view(b, s_q, h_q, d_v)
    lse = lse.view(b, s_q, h_q)
    if attn_sink is not None:
        out *= (1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - lse))).unsqueeze(-1)
    lonely = lse == float("-inf")
    out[lonely.unsqueeze(-1).broadcast_to(b, s_q, h_q, d_v)] = 0.0
    lse[lonely] = float("+inf")
    return out.to(torch.bfloat16), lse.transpose(1, 2)


def build_dsv4_kv_cache(num_pages, page_size, device):
    """Build a DSv4-format FP8 KV cache: [num_pages, page_size, 1, 584]."""
    total_tokens = num_pages * page_size
    kv_bf16 = torch.randn(num_pages, page_size, 1, D_QK, dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    return quantize_k_cache(kv_bf16, LAYOUT)


def build_dsv4_indices(b, s_q, topk, num_pages, page_size, device, sparsity=0.1):
    """Build sparse indices [b, s_q, topk] valid in range [0, num_pages*page_size)."""
    N = num_pages * page_size
    indices = torch.randint(0, N, (b, s_q, topk), dtype=torch.int32, device=device)
    mask = torch.rand(b, s_q, topk, device=device) < sparsity
    indices[mask] = -1
    return indices


def build_topk_length(b, min_frac, max_topk, device):
    """Build topk_length [b] with random lengths in [min_frac*max_topk, max_topk]."""
    lo = max(int(min_frac * max_topk), 1)
    hi = max_topk + 1
    return torch.randint(lo, hi, (b,), dtype=torch.int32, device=device)


def build_attn_sink(h_q, device, dens=0.8):
    """Build attention sink [h_q] with some +inf/-inf edge cases."""
    sink = torch.randn(h_q, dtype=torch.float32, device=device)
    if torch.rand(1).item() < 1 - dens:
        sink[torch.rand(h_q, device=device) < 0.1] = float("-inf")
        sink[torch.rand(h_q, device=device) < 0.1] = float("+inf")
    return sink


@torch.inference_mode()
def test_case(desc, b, topk_swa, topk_len_frac,
              extra_mode,    # None, "c4", "c128"
              extra_topk, extra_len_frac,
              s_k=32768, page_size=256, has_sink=True):
    """Run one test case and report PASS/FAIL.

    Parameters
    ----------
    extra_mode: None (SWA-only), "c4" (extra page_size=64, topk=512),
               "c128" (extra page_size=2, topk=8256)
    """
    device = torch.device("cuda:0")
    s_q = 1
    softmax_scale = D_QK ** -0.5

    # ── Main (SWA) cache ───────────────────────────────────────────────────
    num_main_pages = (s_k + page_size - 1) // page_size
    main_tokens = num_main_pages * page_size
    q = torch.randn(b, s_q, H_Q, D_QK, dtype=torch.bfloat16, device=device)
    k_cache = build_dsv4_kv_cache(num_main_pages, page_size, device)
    indices = build_dsv4_indices(b, s_q, topk_swa, num_main_pages, page_size, device)

    # ── Topk length ─────────────────────────────────────────────────────────
    tl = build_topk_length(b, topk_len_frac, topk_swa, device)

    # ── Attn sink ───────────────────────────────────────────────────────────
    attn_sink = build_attn_sink(H_Q, device) if has_sink else None

    # ── Extra cache ─────────────────────────────────────────────────────────
    ek, ei, etl = None, None, None
    if extra_mode == "c128":
        extra_page_size = 2
        e_s_k = 15006  # 7503 pages × 2 tokens = 15006 tokens
        e_num_pages = (e_s_k + extra_page_size - 1) // extra_page_size
        ek = build_dsv4_kv_cache(e_num_pages, extra_page_size, device)
        ei = build_dsv4_indices(b, s_q, extra_topk, e_num_pages, extra_page_size, device)
        etl = build_topk_length(b, extra_len_frac, extra_topk, device) if extra_len_frac > 0 else None
    elif extra_mode == "c4":
        extra_page_size = 64
        e_s_k = 480192  # 7503 pages × 64 tokens ≈ 480K tokens
        e_num_pages = (e_s_k + extra_page_size - 1) // extra_page_size
        ek = build_dsv4_kv_cache(e_num_pages, extra_page_size, device)
        ei = build_dsv4_indices(b, s_q, extra_topk, e_num_pages, extra_page_size, device)
        etl = build_topk_length(b, extra_len_frac, extra_topk, device) if extra_len_frac > 0 else None

    # ── Reference ───────────────────────────────────────────────────────────
    out_ref, lse_ref = compute_ref_output(
        q, k_cache, indices, D_V, softmax_scale,
        attn_sink, tl, ek, ei, etl,
    )

    # ── Optimized torch ─────────────────────────────────────────────────────
    out_new, lse_new = ref_torch.flash_mla_decode_torch(
        q=q, k_cache=k_cache, indices=indices,
        head_dim_v=D_V, softmax_scale=softmax_scale, attn_sink=attn_sink,
        extra_k_cache=ek, extra_indices=ei,
        topk_length=tl, extra_topk_length=etl,
    )

    out_ok = torch.allclose(out_new.float(), out_ref.float(), atol=2e-2, rtol=1e-2)
    out_diff = (out_new.float() - out_ref.float()).abs()
    lse_diff = (lse_new.float() - lse_ref.float()).abs()
    status = "PASS" if out_ok else "FAIL"
    print(f"[{status}] {desc}: out_max={out_diff.max():.4e}  lse_max={lse_diff.max():.4e}")
    return out_ok


if __name__ == "__main__":
    all_pass = True

    # ── SWA-only cases (no extra cache) ─────────────────────────────────────
    print("=" * 70)
    print("SWA-only (no extra KV cache)")
    print("=" * 70)
    for b in [1, 4, 8]:
        all_pass &= test_case(
            f"SWA b={b} basic", b=b, topk_swa=128, topk_len_frac=0.5,
            extra_mode=None, extra_topk=0, extra_len_frac=0, has_sink=False,
        )
        all_pass &= test_case(
            f"SWA b={b} +sink", b=b, topk_swa=128, topk_len_frac=0.5,
            extra_mode=None, extra_topk=0, extra_len_frac=0, has_sink=True,
        )
        all_pass &= test_case(
            f"SWA b={b} +topk_len", b=b, topk_swa=128, topk_len_frac=0.3,
            extra_mode=None, extra_topk=0, extra_len_frac=0, has_sink=True,
        )

    # ── C128 extra cache cases ─────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("C128 extra cache (extra_k_cache=[7503, 2, 1, 584], extra_indices=[b,1,8256])")
    print("=" * 70)
    for b in [1, 4, 8]:
        all_pass &= test_case(
            f"C128 b={b} basic", b=b, topk_swa=128, topk_len_frac=0.5,
            extra_mode="c128", extra_topk=8256, extra_len_frac=0.3, has_sink=False,
        )
        all_pass &= test_case(
            f"C128 b={b} +sink", b=b, topk_swa=128, topk_len_frac=0.5,
            extra_mode="c128", extra_topk=8256, extra_len_frac=0.3, has_sink=True,
        )
        all_pass &= test_case(
            f"C128 b={b} +topk_len", b=b, topk_swa=128, topk_len_frac=0.3,
            extra_mode="c128", extra_topk=8256, extra_len_frac=0.2, has_sink=True,
        )

    # ── C4 extra cache cases ───────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("C4 extra cache (extra_k_cache=[7503, 64, 1, 584], extra_indices=[b,1,512])")
    print("=" * 70)
    for b in [1, 4, 8]:
        all_pass &= test_case(
            f"C4 b={b} basic", b=b, topk_swa=128, topk_len_frac=0.5,
            extra_mode="c4", extra_topk=512, extra_len_frac=0.3, has_sink=False,
        )
        all_pass &= test_case(
            f"C4 b={b} +sink", b=b, topk_swa=128, topk_len_frac=0.5,
            extra_mode="c4", extra_topk=512, extra_len_frac=0.3, has_sink=True,
        )
        all_pass &= test_case(
            f"C4 b={b} +topk_len", b=b, topk_swa=128, topk_len_frac=0.3,
            extra_mode="c4", extra_topk=512, extra_len_frac=0.2, has_sink=True,
        )
    # C4 with topk=64
    all_pass &= test_case(
        "C4 b=4 topk=64 +sink", b=4, topk_swa=128, topk_len_frac=0.5,
        extra_mode="c4", extra_topk=64, extra_len_frac=0.3, has_sink=True,
    )

    # ── Large batch stress ─────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("Large batch / stress")
    print("=" * 70)
    all_pass &= test_case(
        "C128 b=32 large", b=32, topk_swa=128, topk_len_frac=0.5,
        extra_mode="c128", extra_topk=8256, extra_len_frac=0.3, has_sink=True,
    )
    all_pass &= test_case(
        "C4 b=32 large", b=32, topk_swa=128, topk_len_frac=0.5,
        extra_mode="c4", extra_topk=512, extra_len_frac=0.3, has_sink=True,
    )

    if all_pass:
        print("\nAll comprehensive V2 tests PASSED")
    else:
        print("\nSome tests FAILED")
        sys.exit(1)
