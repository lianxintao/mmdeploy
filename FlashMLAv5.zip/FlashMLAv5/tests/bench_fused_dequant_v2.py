"""
Benchmark: fused dequant+gather — V2 (DSv4 shapes).

Compares dequant+gather performance across different page sizes and topk:
  - SWA:  page_size=256, topk=128
  - C128: page_size=2,   topk=8256
  - C4:   page_size=64,  topk=512, 64

Also benchmarks end-to-end flash_mla_decode_torch with extra caches.
"""
import sys, types, time, os
sys.path.insert(0, '/home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA')

_mock_cuda = types.ModuleType('flash_mla.cuda')
sys.modules['flash_mla.cuda'] = _mock_cuda

import torch, importlib.util

_spec = importlib.util.spec_from_file_location(
    'ref_torch', os.path.join(os.path.dirname(__file__), '..', 'flash_mla', 'torch', 'ref.py'),
)
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)

from tests.quant import quantize_k_cache, dequantize_k_cache, FP8KVCacheLayout

# ── DSv4 constants ──────────────────────────────────────────────────────────
D_QK = 512
D_NOPE = 448
D_ROPE = 64
D_V = 512
H_Q = 64
LAYOUT = FP8KVCacheLayout.MODEL1_FP8Sparse  # 584B/tok, ceil_div(ps*584,576)*576 per page


@torch.inference_mode()
def bench(desc: str, fn, warmup=5, iters=100):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(iters):
        fn()
    torch.cuda.synchronize()
    elapsed_ms = (time.perf_counter() - t0) * 1000 / iters
    print(f"  {desc}: {elapsed_ms:.3f} ms")
    return elapsed_ms


def main():
    device = torch.device("cuda:0")
    b, s_q = 4, 1

    # ══════════════════════════════════════════════════════════════════════
    # Section 1: SWA cache (page_size=256, topk=128)
    # ══════════════════════════════════════════════════════════════════════
    swa_page_size = 256
    swa_topk = 128
    swa_num_pages = 751
    swa_tokens = swa_num_pages * swa_page_size  # 192,256 tokens

    print(f"\n{'='*60}")
    print(f"DSv4 SWA: page_size={swa_page_size}, topk={swa_topk}, "
          f"pages={swa_num_pages}, tokens={swa_tokens}")
    print(f"{'='*60}")

    kv_bf16 = torch.randn(swa_num_pages, swa_page_size, 1, D_QK,
                          dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    k_cache = quantize_k_cache(kv_bf16, LAYOUT)
    print(f"  k_cache shape: {list(k_cache.shape)}  ({k_cache.numel() * k_cache.element_size() / 1e6:.1f} MB)")

    indices = torch.randint(0, swa_tokens, (b, s_q, swa_topk), dtype=torch.int32, device=device)

    # Old: dequantize ALL
    bench(f"old: dequantize ALL ({swa_tokens} tokens)",
          lambda: dequantize_k_cache(k_cache, LAYOUT), iters=20)

    # New: get cache views
    bench("new: get cache views (overlapping views)",
          lambda: ref_torch._get_cache_views(k_cache), iters=100)

    # Old: dequant + gather
    def old_full():
        kv_deq = dequantize_k_cache(k_cache, LAYOUT)
        kv_flat = kv_deq.view(-1, D_QK)
        return kv_flat[indices.view(-1)].view(b, s_q, swa_topk, D_QK)
    bench(f"old: dequant+gather ({b * s_q * swa_topk} tok)", old_full, iters=20)

    # New: fused dequant+gather
    def new_full():
        kv_fp8, kv_bf16, k_u8, dn, dr, nt, ts, ro, pg_bytes, bs, bpt = ref_torch._get_cache_views(k_cache)
        return ref_torch._fused_gather_kv(
            kv_fp8, kv_bf16, k_u8, indices, None, dn, dr, nt, ts, ro,
            pg_bytes, bs, bpt,
        )
    bench(f"new: fused dequant+gather ({b * s_q * swa_topk} tok)", new_full, iters=100)

    # End to end (SWA only)
    q = torch.randn(b, s_q, H_Q, D_QK, dtype=torch.bfloat16, device=device)
    ss = D_QK ** (-0.5)
    sink = torch.randn(H_Q, dtype=torch.float32, device=device)
    bench("new: full SWA decode", lambda: ref_torch.flash_mla_decode_torch(
        q=q, k_cache=k_cache, indices=indices, head_dim_v=D_V,
        softmax_scale=ss, attn_sink=sink,
    ), iters=50)

    # ══════════════════════════════════════════════════════════════════════
    # Section 2: C128 extra cache (page_size=2, topk=8256)
    # ══════════════════════════════════════════════════════════════════════
    c128_page_size = 2
    c128_topk = 8256
    c128_num_pages = 7503
    c128_tokens = c128_num_pages * c128_page_size  # 15,006 tokens

    print(f"\n{'='*60}")
    print(f"DSv4 C128: page_size={c128_page_size}, topk={c128_topk}, "
          f"pages={c128_num_pages}, tokens={c128_tokens}")
    print(f"{'='*60}")

    ekv_bf16 = torch.randn(c128_num_pages, c128_page_size, 1, D_QK,
                           dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    ek_cache128 = quantize_k_cache(ekv_bf16, LAYOUT)
    print(f"  extra_k_cache shape: {list(ek_cache128.shape)}  "
          f"({ek_cache128.numel() * ek_cache128.element_size() / 1e6:.1f} MB)")

    ei128 = torch.randint(0, c128_tokens, (b, s_q, c128_topk), dtype=torch.int32, device=device)

    # Old: dequantize ALL C128
    bench(f"old: dequantize ALL C128 ({c128_tokens} tokens)",
          lambda: dequantize_k_cache(ek_cache128, LAYOUT), iters=20)

    # New: get views + fused gather C128
    def new_c128():
        ek_fp8, ek_bf16, ek_u8, dn, dr, nt, ts, ro, epg, ebs, ebpt = ref_torch._get_cache_views(ek_cache128)
        return ref_torch._fused_gather_kv(
            ek_fp8, ek_bf16, ek_u8, ei128, None, dn, dr, nt, ts, ro,
            epg, ebs, ebpt,
        )
    bench(f"new: fused dequant+gather C128 ({b * s_q * c128_topk} tok)", new_c128, iters=100)

    # End to end SWA + C128
    etl128 = torch.randint(max(1, c128_topk // 4), c128_topk + 1, (b,), dtype=torch.int32, device=device)
    bench("new: full SWA+C128 decode", lambda: ref_torch.flash_mla_decode_torch(
        q=q, k_cache=k_cache, indices=indices, head_dim_v=D_V,
        softmax_scale=ss, attn_sink=sink,
        extra_k_cache=ek_cache128, extra_indices=ei128, extra_topk_length=etl128,
    ), iters=50)

    # ══════════════════════════════════════════════════════════════════════
    # Section 3: C4 extra cache (page_size=64, topk=512)
    # ══════════════════════════════════════════════════════════════════════
    c4_page_size = 64
    c4_topk = 512
    c4_num_pages = 7503
    c4_tokens = c4_num_pages * c4_page_size  # 480,192 tokens

    print(f"\n{'='*60}")
    print(f"DSv4 C4: page_size={c4_page_size}, topk={c4_topk}, "
          f"pages={c4_num_pages}, tokens={c4_tokens}")
    print(f"{'='*60}")

    ekv_c4 = torch.randn(c4_num_pages, c4_page_size, 1, D_QK,
                         dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    ek_cache4 = quantize_k_cache(ekv_c4, LAYOUT)
    print(f"  extra_k_cache shape: {list(ek_cache4.shape)}  "
          f"({ek_cache4.numel() * ek_cache4.element_size() / 1e6:.1f} MB)")

    ei4 = torch.randint(0, c4_tokens, (b, s_q, c4_topk), dtype=torch.int32, device=device)

    # Old: dequantize ALL C4
    bench(f"old: dequantize ALL C4 ({c4_tokens} tokens)",
          lambda: dequantize_k_cache(ek_cache4, LAYOUT), iters=20)

    # New: get views + fused gather C4
    def new_c4():
        ek_fp8, ek_bf16, ek_u8, dn, dr, nt, ts, ro, epg, ebs, ebpt = ref_torch._get_cache_views(ek_cache4)
        return ref_torch._fused_gather_kv(
            ek_fp8, ek_bf16, ek_u8, ei4, None, dn, dr, nt, ts, ro,
            epg, ebs, ebpt,
        )
    bench(f"new: fused dequant+gather C4 ({b * s_q * c4_topk} tok)", new_c4, iters=100)

    # End to end SWA + C4
    etl4 = torch.randint(max(1, c4_topk // 4), c4_topk + 1, (b,), dtype=torch.int32, device=device)
    bench("new: full SWA+C4 decode", lambda: ref_torch.flash_mla_decode_torch(
        q=q, k_cache=k_cache, indices=indices, head_dim_v=D_V,
        softmax_scale=ss, attn_sink=sink,
        extra_k_cache=ek_cache4, extra_indices=ei4, extra_topk_length=etl4,
    ), iters=50)

    # ══════════════════════════════════════════════════════════════════════
    # Section 4: C4 small topk (64)
    # ══════════════════════════════════════════════════════════════════════
    c4_small_topk = 64
    print(f"\n{'='*60}")
    print(f"DSv4 C4 small: page_size={c4_page_size}, topk={c4_small_topk}")
    print(f"{'='*60}")

    ei4s = torch.randint(0, c4_tokens, (b, s_q, c4_small_topk), dtype=torch.int32, device=device)
    etl4s = torch.randint(1, c4_small_topk + 1, (b,), dtype=torch.int32, device=device)
    bench("new: full SWA+C4(small) decode", lambda: ref_torch.flash_mla_decode_torch(
        q=q, k_cache=k_cache, indices=indices, head_dim_v=D_V,
        softmax_scale=ss, attn_sink=sink,
        extra_k_cache=ek_cache4, extra_indices=ei4s, extra_topk_length=etl4s,
    ), iters=100)

    print()


if __name__ == "__main__":
    main()
