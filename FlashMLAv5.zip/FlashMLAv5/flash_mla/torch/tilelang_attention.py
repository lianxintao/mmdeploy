"""
TileLang fused attention kernel for FlashMLA decode (MODEL1, d_qk=512, d_v=512).
Replaces PyTorch float32 attention to avoid OOM from gathered_kv.float().

Based on tilelang/examples/deepseek_v4/sparse_attn_fwd_sm90.py,
adapted for pre-gathered KV (no on-the-fly gather).
"""
import tilelang
import tilelang.language as T
import torch

_PASS_CONFIGS = {
    tilelang.PassConfigKey.TL_DISABLE_TMA_LOWER: True,
    tilelang.PassConfigKey.TL_DISABLE_WARP_SPECIALIZED: True,
    tilelang.PassConfigKey.TL_ENABLE_FAST_MATH: True,
}

LOG2E = 1.4426950408889634
_DEFAULT_H_PER_BLOCK = 32


def _build_attention_kernel(
    h_q: int,
    d_qk: int,
    d_v: int,
    block_N: int = 64,
    sm_scale: float = 1.0,
    threads: int = 256,
):
    """Build tilelang attention kernel for pre-gathered KV with dynamic batch."""
    if h_q < _DEFAULT_H_PER_BLOCK:
        hpb, rep_h = h_q, 1
    else:
        assert h_q % 32 == 0, f"h_q={h_q} must be multiple of 32"
        hpb, rep_h = _DEFAULT_H_PER_BLOCK, h_q // _DEFAULT_H_PER_BLOCK

    scale = sm_scale * LOG2E
    BI = block_N

    @tilelang.jit(out_idx=[3], pass_configs=_PASS_CONFIGS)
    def kernel(dtype: T.dtype = T.bfloat16):
        batch_sq = T.symbolic("batch_sq")
        topk = T.symbolic("topk")

        @T.prim_func
        def main(
            Q: T.Tensor([batch_sq, h_q, d_qk], dtype),
            KV: T.Tensor([batch_sq, topk, d_qk], dtype),
            Mask: T.Tensor([batch_sq, topk], "int8"),
            Output: T.Tensor([batch_sq, h_q, d_v], dtype),
            Sinks: T.Tensor([h_q], dtype),
        ):
            with T.Kernel(batch_sq, rep_h, threads=threads) as (bx, h_block):
                h_start = h_block * hpb

                Q_shared = T.alloc_shared([hpb, d_qk], dtype)
                KV_shared = T.alloc_shared([BI, d_qk], dtype)
                S_shared = T.alloc_shared([hpb, BI], dtype)
                Sinks_shared = T.alloc_shared([hpb], dtype)

                acc_s = T.alloc_fragment([hpb, BI], T.float32)
                acc_o = T.alloc_fragment([hpb, d_v], T.float32)
                scores_max = T.alloc_fragment([hpb], T.float32)
                scores_max_prev = T.alloc_fragment([hpb], T.float32)
                scores_scale = T.alloc_fragment([hpb], T.float32)
                scores_sum = T.alloc_fragment([hpb], T.float32)
                logsum = T.alloc_fragment([hpb], T.float32)
                mask = T.alloc_fragment([BI], T.bool)

                T.copy(Q[bx, h_start : h_start + hpb, :], Q_shared)
                T.copy(Sinks[h_start : h_start + hpb], Sinks_shared)
                T.fill(acc_o, 0)
                T.fill(logsum, 0)
                T.fill(scores_max, -(2 ** 30))

                N_blocks = T.ceildiv(topk, BI)
                for i_i in T.serial(N_blocks):
                    k_start = i_i * BI

                    # Mask: 0=invalid, 1=valid
                    for bi_i in T.Parallel(BI):
                        k_i = k_start + bi_i
                        mask[bi_i] = T.if_then_else(
                            k_i < topk, Mask[bx, k_i] != 0, False
                        )

                    # Load KV block (K=V in MLA)
                    for bi_i, d_i in T.Parallel(BI, d_qk):
                        k_i = k_start + bi_i
                        KV_shared[bi_i, d_i] = T.if_then_else(
                            k_i < topk, KV[bx, k_i, d_i], 0.0
                        )

                    # Init scores: valid → 0, invalid → -inf
                    for h_i, bi_i in T.Parallel(hpb, BI):
                        acc_s[h_i, bi_i] = T.if_then_else(
                            mask[bi_i], 0.0, -T.infinity(T.float32)
                        )

                    # QK^T
                    T.gemm(
                        Q_shared, KV_shared, acc_s,
                        transpose_B=True,
                        policy=T.GemmWarpPolicy.FullRow,
                    )

                    # Online softmax (base-2)
                    T.copy(scores_max, scores_max_prev)
                    T.reduce_max(acc_s, scores_max, dim=1, clear=False)
                    for h_i in T.Parallel(hpb):
                        scores_max[h_i] = T.max(scores_max[h_i], scores_max_prev[h_i])
                    for h_i in T.Parallel(hpb):
                        scores_scale[h_i] = T.exp2(
                            scores_max_prev[h_i] * scale - scores_max[h_i] * scale
                        )
                    for h_i, bi_i in T.Parallel(hpb, BI):
                        acc_s[h_i, bi_i] = T.exp2(
                            acc_s[h_i, bi_i] * scale - scores_max[h_i] * scale
                        )
                    T.reduce_sum(acc_s, scores_sum, dim=1)

                    # Rescale acc_o
                    for h_i, d_i in T.Parallel(hpb, d_v):
                        acc_o[h_i, d_i] *= scores_scale[h_i]

                    # PV (V=K in MLA)
                    T.copy(acc_s, S_shared)
                    T.gemm(
                        S_shared, KV_shared, acc_o,
                        policy=T.GemmWarpPolicy.FullRow,
                    )

                    # Update logsum
                    for h_i in T.Parallel(hpb):
                        logsum[h_i] = (
                            logsum[h_i] * scores_scale[h_i] + scores_sum[h_i]
                        )

                # Fused attention sink
                for h_i in T.Parallel(hpb):
                    logsum[h_i] += T.exp2(
                        Sinks_shared[h_i] * LOG2E - scores_max[h_i] * scale
                    )

                # Normalize output
                for h_i, d_i in T.Parallel(hpb, d_v):
                    acc_o[h_i, d_i] /= logsum[h_i]

                # Store output
                T.copy(acc_o, Q_shared)
                T.copy(Q_shared[:, :d_v], Output[bx, h_start : h_start + hpb, :d_v])

        return main

    return kernel(dtype="bfloat16")


def tilelang_attention(
    q: torch.Tensor,             # [b, s_q, h_q, d_qk] bf16
    gathered_kv: torch.Tensor,    # [b, s_q, topk, d_qk] bf16
    invalid_mask: torch.Tensor,   # [b, s_q, topk] bool (True=invalid)
    head_dim_v: int,
    softmax_scale: float,
    attn_sink: torch.Tensor = None,  # [h_q] float32, or None
) -> torch.Tensor:
    """
    Fused tilelang attention: QK^T + softmax + PV + attn_sink.
    Returns output [b, s_q, h_q, d_v] bf16. No large float32 intermediates.
    """
    b, s_q, h_q, d_qk = q.shape
    _, _, topk, d_kv = gathered_kv.shape
    d_v = head_dim_v

    # Flatten batch
    bs = b * s_q
    q_3d = q.reshape(bs, h_q, d_qk).contiguous()
    kv_3d = gathered_kv.reshape(bs, topk, d_kv).contiguous()
    # Mask: 1=valid, 0=invalid
    mask_2d = (~invalid_mask.reshape(bs, topk)).to(torch.int8).contiguous()

    # Pad topk to multiple of block_N
    block_N = 32
    rem = topk % block_N
    if rem != 0:
        pad = block_N - rem
        kv_3d = torch.nn.functional.pad(kv_3d, (0, 0, 0, pad))
        mask_2d = torch.nn.functional.pad(mask_2d, (0, pad))

    sink = attn_sink if attn_sink is not None else torch.zeros(
        h_q, dtype=torch.bfloat16, device=q.device
    )
    sink = sink.to(torch.bfloat16)

    kernel = _build_attention_kernel(h_q, d_qk, d_v, block_N, softmax_scale)
    out_3d = kernel(q_3d, kv_3d, mask_2d, sink)
    return out_3d[:, :, :d_v].reshape(b, s_q, h_q, d_v)
