#pragma once

#include <cutlass/numeric_types.h>
#include <cute/tensor.hpp>
#include <cute/atom/mma_atom.hpp>
#include <cute/atom/copy_atom.hpp>

#include "defines.h"
#include "params.h"

using namespace cute;

namespace sm89::decode::sparse_fp8 {

using fp8_e8m0 = __nv_fp8_e8m0;

template<ModelType MODEL_TYPE, int NUM_HEADS>
class KernelTemplate {
public:
    static_assert(NUM_HEADS == 64 || NUM_HEADS == 128);

    // ── Tile dimensions ────────────────────────────────────────────────────
    // BLOCK_M = 16: reduced from 64 so that Q (18KB) + K×2 (36KB) fits in SM89's 99KB SMEM.
    static constexpr int BLOCK_M         = 16;
    static constexpr int NUM_M_BLOCKS    = NUM_HEADS / BLOCK_M;   // 4 (h=64) or 8 (h=128)
    static constexpr int TOPK_BLOCK_SIZE = 16;   // reduced from 64; one K-iteration covers 16 KV tokens
    static constexpr int NUM_K_BUFS      = 2;    // software double-buffering via cp.async
    static constexpr int NUM_THREADS     = 128;  // 4 warps
    // Each CTA is split into two 64-thread "sub-groups" for independent QK/PV computation:
    //   sg0 = threadIdx.x in [0, 64)   → handles V columns [0, HEAD_DIM_V/2)
    //   sg1 = threadIdx.x in [64, 128) → handles V columns [HEAD_DIM_V/2, HEAD_DIM_V)
    static constexpr int THREADS_PER_SG  = 64;   // 2 warps per sub-group
    static constexpr int V_COLS_PER_SG   = 256;  // = HEAD_DIM_V / 2

    // ── Head dimensions ────────────────────────────────────────────────────
    static constexpr int HEAD_DIM_K    = MODEL_TYPE == ModelType::V32 ? 576 : 512;
    static constexpr int HEAD_DIM_V    = 512;
    static constexpr int HEAD_DIM_ROPE = 64;
    static constexpr int HEAD_DIM_NOPE = HEAD_DIM_K - HEAD_DIM_ROPE;

    static constexpr int QUANT_TILE_SIZE = MODEL_TYPE == ModelType::V32 ? 128 : 64;
    static constexpr int NUM_SCALES      = MODEL_TYPE == ModelType::V32 ? 4 : 8;

    // ── SMEM strides (row-major with padding for bank-conflict avoidance) ─
    // 128-bit (16-byte) row padding: pad to multiple of 8 bf16 elements (128 bits).
    // HEAD_DIM_K = 576 → already divisible by 8, no extra padding needed.
    // HEAD_DIM_K = 512 → divisible by 8, no extra padding needed.
    static constexpr int SMEM_STRIDE_Q = HEAD_DIM_K;   // in bf16 elements
    static constexpr int SMEM_STRIDE_K = HEAD_DIM_K;   // in bf16 elements

    // ── SM80 MMA atom (available on SM80, SM86, SM89) ─────────────────────
    // 16×8×16 BF16 multiply-accumulate: A[16,16]×B[16,8]→C[16,8] in f32
    // TN layout: A row-major (T), B column-major (N).
    using MMA_Atom_t = SM80_16x8x16_F32BF16BF16F32_TN;

    // 2-warp TiledMMA: Layout<_1,_2,_1> = 1 warp in M-dir, 2 warps in N-dir
    //   → collective tile: M=16, N=16, K=16 using 64 threads (2 warps)
    using TiledMMA_QK = decltype(make_tiled_mma(
        MMA_Atom_t{},
        Layout<Shape<_1, _2, _1>>{}
    ));

    // Same atom for PV; V partition size per sub-group is 256 columns.
    // The 256-column coverage is achieved by iterating N in the GEMM loop.
    using TiledMMA_PV = TiledMMA_QK;

    // ── SMEM layout types ─────────────────────────────────────────────────
    // Simple row-major layouts. Using Int<SMEM_STRIDE_*> as the inner stride
    // ensures the compiler knows the stride at compile time for optimal code gen.
    using SmemLayoutQ = Layout<
        Shape <Int<BLOCK_M>, Int<HEAD_DIM_K>>,
        Stride<Int<SMEM_STRIDE_Q>, _1>
    >;
    using SmemLayoutK = Layout<
        Shape <Int<TOPK_BLOCK_SIZE>, Int<HEAD_DIM_K>>,
        Stride<Int<SMEM_STRIDE_K>, _1>
    >;
    // V is the first HEAD_DIM_V columns of K's physical buffer (NoPE portion)
    using SmemLayoutV = Layout<
        Shape <Int<TOPK_BLOCK_SIZE>, Int<HEAD_DIM_V>>,
        Stride<Int<SMEM_STRIDE_K>, _1>
    >;
    using SmemLayoutS = Layout<
        Shape <Int<BLOCK_M>, Int<TOPK_BLOCK_SIZE>>,
        Stride<Int<TOPK_BLOCK_SIZE>, _1>
    >;

    // ── Copy atoms for ldmatrix (SMEM → registers) ────────────────────────
    // SM75_U32x4_LDSM_N: loads 4×32-bit values per thread (= 8 BF16) using ldmatrix.x4
    // Used for A operand (row-major).
    using CopyAtom_A = Copy_Atom<SM75_U32x4_LDSM_N, bf16>;
    // SM75_U32x4_LDSM_N for B operand loaded in transposed mode:
    using CopyAtom_B = Copy_Atom<SM75_U32x4_LDSM_N, bf16>;

    // ── Shared memory plan ────────────────────────────────────────────────
    // Total SMEM (V32 / MODEL1):
    //   Q:    18,432 / 16,384 bytes
    //   K×2:  36,864 / 32,768 bytes
    //   S:       512 /    512 bytes
    //   misc:   ~300 /   ~300 bytes
    //   ──────────────────────────
    //   Total: ~56KB / ~50KB   (SM89 limit: 99KB)
    struct SharedMemoryPlan {
        // Swizzled/padded bf16 arrays; cosize_v<Layout> = number of elements.
        array_aligned<bf16, cosize_v<SmemLayoutQ>> q;
        array_aligned<bf16, cosize_v<SmemLayoutK>> k[NUM_K_BUFS];
        array_aligned<bf16, cosize_v<SmemLayoutS>> s;   // softmax score matrix
        bool is_kv_valid[NUM_K_BUFS][TOPK_BLOCK_SIZE];
        float sM[BLOCK_M];    // per-row running max
        float sL[BLOCK_M];    // per-row running sum-of-exp
        float sOScale[BLOCK_M]; // output scale = 1/(L + attn_sink_exp)
    };

    // ── Forward declarations ───────────────────────────────────────────────
    static __device__ __forceinline__ void devfunc(const SparseAttnDecodeParams &params);
    static void run(const SparseAttnDecodeParams &params);
};

} // namespace sm89::decode::sparse_fp8
