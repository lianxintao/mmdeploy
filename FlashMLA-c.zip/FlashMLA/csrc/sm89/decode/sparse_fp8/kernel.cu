#pragma once

#include "kernel.h"

#include <cuda_fp8.h>
#include <cuda_bf16.h>
#include <math_constants.h>

#include <cute/tensor.hpp>
#include <cute/atom/mma_atom.hpp>
#include <cute/atom/copy_atom.hpp>

#include <kerutils/kerutils.cuh>

#include "config.h"
#include "components/dequant.h"

using namespace cute;

namespace sm89::decode::sparse_fp8 {

static constexpr float MAX_INIT_VAL = -1e30f;

// ── cp.async helpers ──────────────────────────────────────────────────────────

__device__ __forceinline__
void cp_async_16b(bf16* dst_smem, const bf16* src_global) {
    uint32_t dst_addr = __cvta_generic_to_shared(dst_smem);
    asm volatile("cp.async.cg.shared.global.L2::128B [%0], [%1], 16;\n"
                 :: "r"(dst_addr), "l"(src_global));
}

__device__ __forceinline__ void cp_async_commit()   { asm volatile("cp.async.commit_group;\n"); }
__device__ __forceinline__ void cp_async_wait_all() { asm volatile("cp.async.wait_all;\n"); }

template<int REMAIN>
__device__ __forceinline__ void cp_async_wait_group() {
    asm volatile("cp.async.wait_group %0;\n" :: "n"(REMAIN));
}

// ── SM80 m16n8 C-fragment row/col helpers ────────────────────────────────────
//
// From PTX ISA, the m16n8k16 accumulator per thread t (0..31):
//   row0 = t%4 + (t/16)*4       (values: 0,1,2,3, 4,5,6,7 interleaved with row offsets)
//   row1 = row0 + 8
//   col0 = (t/4 % 4) * 2        (within the n8-tile: 0,2,4,6)
//   col1 = col0 + 1
//   c[0] = C[row0][col0], c[1] = C[row0][col1]
//   c[2] = C[row1][col0], c[3] = C[row1][col1]
//
// For the 2-n8-tile layout (m16n16), each warp independently computes both tiles:
//   rP[0..3]: n8-tile 0 (cols 0..7  for QK; warp-local)
//   rP[4..7]: n8-tile 1 (cols 8..15 for QK; warp-local)
//   col0_global(tile t8) = t8*8 + (lane/4 % 4)*2

// ── load_q_to_smem ────────────────────────────────────────────────────────────
template<ModelType MODEL_TYPE, int NUM_HEADS>
__device__ __forceinline__
void load_q_to_smem(
    bf16* sQ,
    const SparseAttnDecodeParams &params,
    int batch_idx, int s_q_idx, int head_block_idx
) {
    using KT = KernelTemplate<MODEL_TYPE, NUM_HEADS>;
    const bf16* gQ = (const bf16*)params.q
        + (int64_t)batch_idx          * params.stride_q_b
        + (int64_t)s_q_idx            * params.stride_q_s_q
        + (int64_t)(head_block_idx * KT::BLOCK_M) * params.stride_q_h_q;

    const int total_chunks = KT::BLOCK_M * KT::HEAD_DIM_K / 8;
    for (int idx = threadIdx.x; idx < total_chunks; idx += KT::NUM_THREADS) {
        int row = idx / (KT::HEAD_DIM_K / 8);
        int col = (idx % (KT::HEAD_DIM_K / 8)) * 8;
        cp_async_16b(sQ + row * KT::SMEM_STRIDE_Q + col,
                     gQ + (int64_t)row * params.stride_q_h_q + col);
    }
}

// ── load_kv_block ─────────────────────────────────────────────────────────────
// 8 threads per token (128 threads / 16 tokens per block).
// V32: sub_threads 0..7 load NoPE (8×64 FP8); sub_thread 0 also loads RoPE.
// MODEL1: sub_threads 0..6 load NoPE (7×64 FP8); sub_thread 7 loads RoPE.
template<ModelType MODEL_TYPE, int NUM_HEADS>
__device__ __forceinline__
void load_kv_block(
    const SparseAttnDecodeParams &params,
    typename KernelTemplate<MODEL_TYPE, NUM_HEADS>::SharedMemoryPlan &plan,
    int batch_idx, int s_q_idx, int block_idx, int buf_idx,
    int topk_length, int extra_topk_length, int num_orig_kv_blocks
) {
    using KT = KernelTemplate<MODEL_TYPE, NUM_HEADS>;
    static_assert(KT::TOPK_BLOCK_SIZE == 16 && KT::NUM_THREADS == 128);
    const int token_idx  = threadIdx.x / 8;
    const int sub_thread = threadIdx.x % 8;

    if (token_idx >= KT::TOPK_BLOCK_SIZE) return;

    const bool is_orig_block = (MODEL_TYPE == ModelType::V32) ||
                                (block_idx < num_orig_kv_blocks);
    const fp8*  kv_ptr;
    const int*  indices_base;
    int         page_block_size;
    int64_t     k_block_stride, k_row_stride;

    if (is_orig_block) {
        const int* gIndices = params.indices
            + batch_idx * params.stride_indices_b
            + s_q_idx   * params.stride_indices_s_q;
        indices_base    = gIndices + block_idx * KT::TOPK_BLOCK_SIZE;
        kv_ptr          = (const fp8*)params.kv;
        page_block_size = params.page_block_size;
        k_block_stride  = params.stride_kv_block;
        k_row_stride    = params.stride_kv_row;
    } else {
        int rel_extra = block_idx - num_orig_kv_blocks;
        const int* gExtraIndices = params.extra_indices
            + batch_idx * params.stride_extra_indices_b
            + s_q_idx   * params.stride_extra_indices_s_q;
        indices_base    = gExtraIndices + rel_extra * KT::TOPK_BLOCK_SIZE;
        kv_ptr          = (const fp8*)params.extra_kv;
        page_block_size = params.extra_page_block_size;
        k_block_stride  = params.stride_extra_kv_block;
        k_row_stride    = params.stride_extra_kv_row;
    }

    int token_index = __ldg(indices_base + token_idx);

    if constexpr (MODEL_TYPE == ModelType::MODEL1) {
        int rel_block = is_orig_block ? block_idx : (block_idx - num_orig_kv_blocks);
        int eff_topk  = is_orig_block ? topk_length : extra_topk_length;
        if (rel_block * KT::TOPK_BLOCK_SIZE + token_idx >= eff_topk) token_index = -1;
    }

    if (sub_thread == 0) {
        plan.is_kv_valid[buf_idx][token_idx] = (token_index != -1);
    }

    uint32_t ui = (uint32_t)token_index;
    int blk     = (token_index == -1) ? 0 : (int)(ui / (uint32_t)page_block_size);
    int rel     = (int)(ui % (uint32_t)page_block_size);

    const fp8*    gK_base;
    __nv_bfloat16 scales[KT::NUM_SCALES] = {};

    // Within-warp lane of sub_thread 0 for this token (for shfl broadcast)
    const int base_lane = (threadIdx.x % 32 / 8) * 8;

    if constexpr (MODEL_TYPE == ModelType::V32) {
        // V32 layout: [512 fp8 NoPE][16 bytes float scales×4][128 bf16 RoPE] = 656B/token
        gK_base = kv_ptr + blk * k_block_stride + rel * k_row_stride;
        if (sub_thread == 0) {
            float4 sc4 = load_128b_from_gmem<float4,
                L1CacheHint::EVICT_LAST, L2PrefetchHint::B128>(
                    gK_base + KT::HEAD_DIM_NOPE);
            scales[0] = (__nv_bfloat16)sc4.x;
            scales[1] = (__nv_bfloat16)sc4.y;
            scales[2] = (__nv_bfloat16)sc4.z;
            scales[3] = (__nv_bfloat16)sc4.w;
        }
        uint32_t s01 = (sub_thread == 0) ? *(const uint32_t*)&scales[0] : 0u;
        uint32_t s23 = (sub_thread == 0) ? *(const uint32_t*)&scales[2] : 0u;
        s01 = __shfl_sync(0xffffffff, s01, base_lane);
        s23 = __shfl_sync(0xffffffff, s23, base_lane);
        *(uint32_t*)&scales[0] = s01;
        *(uint32_t*)&scales[2] = s23;
    } else {
        // MODEL1 layout within block: [pbs × 576B token data] [pbs × 8B scales]
        //   token data = [448 fp8 NoPE][128 bf16 RoPE] = 576B per token
        //   scales = [8 fp8_e8m0] per token, after all token data
        static constexpr int TOKEN_DATA_SIZE =
            KT::HEAD_DIM_NOPE + KT::HEAD_DIM_ROPE * (int)sizeof(bf16);  // 448 + 128 = 576
        gK_base = kv_ptr + blk * k_block_stride + rel * TOKEN_DATA_SIZE;
        if (sub_thread == 0) {
            const fp8_e8m0* gK_scales = (const fp8_e8m0*)(
                kv_ptr + blk * k_block_stride
                + (int64_t)page_block_size * TOKEN_DATA_SIZE
                + rel * KT::NUM_SCALES * sizeof(fp8_e8m0));
            fp8_e8m0 scales_e8m0[KT::NUM_SCALES];
            *(int64_t*)scales_e8m0 = __ldg((const int64_t*)gK_scales);
            CUTE_UNROLL
            for (int si = 0; si < KT::NUM_SCALES; si += 2) {
                *(__nv_bfloat162_raw*)(scales + si) =
                    __nv_cvt_e8m0x2_to_bf162raw(*(__nv_fp8x2_storage_t*)(scales_e8m0 + si));
            }
        }
        CUTE_UNROLL
        for (int si = 0; si < KT::NUM_SCALES / 2; ++si) {
            uint32_t sv = (sub_thread == 0) ? *(const uint32_t*)&scales[si * 2] : 0u;
            sv = __shfl_sync(0xffffffff, sv, base_lane);
            *(uint32_t*)&scales[si * 2] = sv;
        }
    }

    if (token_index == -1) {
        CUTE_UNROLL
        for (int si = 0; si < KT::NUM_SCALES; ++si) scales[si] = (__nv_bfloat16)0.f;
    }

    bf16* sK_row = plan.k[buf_idx].data() + token_idx * KT::SMEM_STRIDE_K;

    // NoPE: each sub_thread handles 64 FP8 → 64 BF16
    static constexpr int NOPE_GROUPS = KT::HEAD_DIM_NOPE / 64;
    if (sub_thread < NOPE_GROUPS) {
        const fp8*  gNope   = gK_base + sub_thread * 64;
        bf16*       sNope   = sK_row  + sub_thread * 64;
        __nv_bfloat16 scale_val = scales[MODEL_TYPE == ModelType::V32 ?
                                          sub_thread / 2 : sub_thread];
        __nv_bfloat162 scale2 = __bfloat162bfloat162(scale_val);
        CUTE_UNROLL
        for (int chunk = 0; chunk < 4; ++chunk) {
            fp8x16 fp8data = load_128b_from_gmem<fp8x16,
                L1CacheHint::EVICT_LAST, L2PrefetchHint::B256>(gNope + chunk * 16);
            if (token_index == -1) *(uint128_t*)&fp8data = 0;
            bf16x8 lo = cvt_fp8x8_bf16x8(fp8data.lo, scale2);
            bf16x8 hi = cvt_fp8x8_bf16x8(fp8data.hi, scale2);
            *(__int128_t*)( sNope + chunk * 16 + 0) = *(__int128_t*)&lo;
            *(__int128_t*)( sNope + chunk * 16 + 8) = *(__int128_t*)&hi;
        }
    }

    // RoPE: MODEL1 uses sub_thread 7 (= NOPE_GROUPS); V32 uses sub_thread 0 in a second pass
    if constexpr (MODEL_TYPE == ModelType::MODEL1) {
        if (sub_thread == 7) {  // == NOPE_GROUPS for MODEL1
            const bf16* gRope = (const bf16*)(gK_base + KT::HEAD_DIM_NOPE);
            bf16*       sRope = sK_row + KT::HEAD_DIM_NOPE;
            CUTE_UNROLL
            for (int chunk = 0; chunk < KT::HEAD_DIM_ROPE / 8; ++chunk) {
                bf16x8 rope8 = load_128b_from_gmem<bf16x8,
                    L1CacheHint::EVICT_LAST, L2PrefetchHint::B128>(gRope + chunk * 8);
                if (token_index == -1) *(uint128_t*)&rope8 = 0;
                *(__int128_t*)(sRope + chunk * 8) = *(__int128_t*)&rope8;
            }
        }
    } else {  // V32: sub_thread 0 loads RoPE (all 8 sub_threads already used for NoPE)
        if (sub_thread == 0) {
            const bf16* gRope = (const bf16*)(gK_base + KT::HEAD_DIM_NOPE
                                              + KT::NUM_SCALES * sizeof(float));
            bf16* sRope = sK_row + KT::HEAD_DIM_NOPE;
            CUTE_UNROLL
            for (int chunk = 0; chunk < KT::HEAD_DIM_ROPE / 8; ++chunk) {
                bf16x8 rope8 = load_128b_from_gmem<bf16x8,
                    L1CacheHint::EVICT_LAST, L2PrefetchHint::B128>(gRope + chunk * 8);
                *(__int128_t*)(sRope + chunk * 8) = *(__int128_t*)&rope8;
            }
        }
    }
}

// ── mma_qk_sync ──────────────────────────────────────────────────────────────
// Each warp independently computes the full m16×n16 output (both n8-tiles).
// rP[8]: [tile0_c0..c3, tile1_c0..c3]
//
// A ldmatrix.x4 (m16k16, row-major sQ):
//   a_row = (lane/16)*8 + lane%8
//   a_col = kt*16 + (lane/8 % 2)*8
//
// B ldmatrix.x2.trans (n8k16, from sK):
//   b_kv_row = n8_tile*8 + lane%8   (KV token / n-dim)
//   b_k_col  = kt*16 + (lane/8)*8   (k starting position)
template<ModelType MODEL_TYPE, int NUM_HEADS>
__device__ __forceinline__
void mma_qk_sync(
    float rP[8],
    const typename KernelTemplate<MODEL_TYPE, NUM_HEADS>::SharedMemoryPlan &plan,
    int buf_idx,
    int lane_in_warp
) {
    using KT = KernelTemplate<MODEL_TYPE, NUM_HEADS>;
    static constexpr int K_TILES = KT::HEAD_DIM_K / 16;

    const bf16* sQ = plan.q.data();
    const bf16* sK = plan.k[buf_idx].data();

    float c[8] = {};

    CUTE_UNROLL
    for (int kt = 0; kt < K_TILES; ++kt) {
        // Load A (m16k16 from sQ)
        uint32_t a0, a1, a2, a3;
        {
            int a_row = (lane_in_warp / 16) * 8 + (lane_in_warp % 8);
            int a_col = kt * 16 + (lane_in_warp / 8 % 2) * 8;
            uint32_t addr = __cvta_generic_to_shared(sQ + a_row * KT::SMEM_STRIDE_Q + a_col);
            asm volatile("ldmatrix.sync.aligned.m8n8.x4.shared.b16 {%0,%1,%2,%3}, [%4];\n"
                         : "=r"(a0), "=r"(a1), "=r"(a2), "=r"(a3) : "r"(addr));
        }

        // Load B tile 0 (n8k16 for KV rows 0..7)
        uint32_t b0, b1;
        {
            int kv_row = 0 * 8 + (lane_in_warp % 8);
            int k_col  = kt * 16 + (lane_in_warp / 8) * 8;
            uint32_t addr = __cvta_generic_to_shared(sK + kv_row * KT::SMEM_STRIDE_K + k_col);
            asm volatile("ldmatrix.sync.aligned.m8n8.x2.trans.shared.b16 {%0,%1}, [%2];\n"
                         : "=r"(b0), "=r"(b1) : "r"(addr));
        }
        asm volatile(
            "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 "
            "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
            : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3])
            : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));

        // Load B tile 1 (n8k16 for KV rows 8..15)
        uint32_t b2, b3;
        {
            int kv_row = 1 * 8 + (lane_in_warp % 8);
            int k_col  = kt * 16 + (lane_in_warp / 8) * 8;
            uint32_t addr = __cvta_generic_to_shared(sK + kv_row * KT::SMEM_STRIDE_K + k_col);
            asm volatile("ldmatrix.sync.aligned.m8n8.x2.trans.shared.b16 {%0,%1}, [%2];\n"
                         : "=r"(b2), "=r"(b3) : "r"(addr));
        }
        asm volatile(
            "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 "
            "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
            : "+f"(c[4]), "+f"(c[5]), "+f"(c[6]), "+f"(c[7])
            : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b2), "r"(b3));
    }

    CUTE_UNROLL
    for (int i = 0; i < 8; ++i) rP[i] = c[i];
}

// ── scale_softmax ─────────────────────────────────────────────────────────────
// rP[8]: scores from both n8-tiles (computed by a single warp).
// C-fragment layout for thread t (lane_in_warp):
//   row0 = t%4 + (t/16)*4,   row1 = row0 + 8
//   tile0 col_base = (t/4 % 4)*2,   tile1 col_base = 8 + (t/4 % 4)*2
//
// Intra-warp reduction for row-max (4 threads share each row):
//   shfl_xor(x,4) then shfl_xor(x,8) covers all 8 threads per row across both tiles.
__device__ __forceinline__
void scale_softmax(
    float          rP[8],         // [in/out] scores → softmax probs
    __nv_bfloat16  rS[8],         // [out]    bf16 for sS write
    float          rO[64],        // [in/out] output accumulator
    float          scale_log2,    // sm_scale * log2(e)
    float          rM[2],         // [in/out] per-row running max
    float          rL[2],         // [in/out] per-row running sum
    const bool     kv_valid[16],  // validity per KV slot
    int            lane_in_warp,
    const float    attn_sink[2]   // log2-scaled sink bias (or {-inf,-inf})
) {
    const int row0 = lane_in_warp % 4 + (lane_in_warp / 16) * 4;
    // row1 = row0 + 8

    // Tile0 col_base and tile1 col_base for this thread
    const int cb0 = (lane_in_warp / 4 % 4) * 2;   // 0,2,4,6
    const int cb1 = 8 + cb0;

    // Mask invalid KV slots
    CUTE_UNROLL
    for (int i = 0; i < 4; ++i) {
        int col = cb0 + (i % 2);
        if (!kv_valid[col]) rP[i] = -INFINITY;
    }
    CUTE_UNROLL
    for (int i = 0; i < 4; ++i) {
        int col = cb1 + (i % 2);
        if (!kv_valid[col]) rP[4 + i] = -INFINITY;
    }

    // Per-row max: each thread sees 4 values for row0 and 4 for row1
    // (2 from tile0 + 2 from tile1 per row)
    float max_r0 = max(max(rP[0], rP[1]), max(rP[4], rP[5]));
    float max_r1 = max(max(rP[2], rP[3]), max(rP[6], rP[7]));

    // Intra-warp reduction: threads sharing same row are at strides 4 and 8
    // (4 threads per row, strides 4 within first 16 lanes)
    max_r0 = max(max_r0, __shfl_xor_sync(0xffffffff, max_r0, 4));
    max_r1 = max(max_r1, __shfl_xor_sync(0xffffffff, max_r1, 4));
    max_r0 = max(max_r0, __shfl_xor_sync(0xffffffff, max_r0, 8));
    max_r1 = max(max_r1, __shfl_xor_sync(0xffffffff, max_r1, 8));

    max_r0 *= scale_log2;
    max_r1 *= scale_log2;

    const float old_M0 = rM[0], old_M1 = rM[1];
    rM[0] = max(max_r0, old_M0);
    rM[1] = max(max_r1, old_M1);

    const float scale0 = exp2f(old_M0 - rM[0]);
    const float scale1 = exp2f(old_M1 - rM[1]);

    // Rescale rO: in mma_pv_sync rO[t*4+{0,1}] → row0, rO[t*4+{2,3}] → row1
    CUTE_UNROLL
    for (int t = 0; t < 16; ++t) {
        rO[t * 4 + 0] *= scale0;
        rO[t * 4 + 1] *= scale0;
        rO[t * 4 + 2] *= scale1;
        rO[t * 4 + 3] *= scale1;
    }

    // Compute softmax probs and running sum
    float sum_r0 = 0.f, sum_r1 = 0.f;
    CUTE_UNROLL
    for (int i = 0; i < 4; ++i) {
        float p = exp2f(rP[i]     * scale_log2 - rM[0]);
        rP[i]   = p; rS[i]   = (__nv_bfloat16)p;
        sum_r0 += p;
    }
    CUTE_UNROLL
    for (int i = 0; i < 4; ++i) {
        float p = exp2f(rP[4 + i] * scale_log2 - rM[1]);
        rP[4+i] = p; rS[4+i] = (__nv_bfloat16)p;
        sum_r1 += p;
    }

    sum_r0 += __shfl_xor_sync(0xffffffff, sum_r0, 4);
    sum_r1 += __shfl_xor_sync(0xffffffff, sum_r1, 4);
    sum_r0 += __shfl_xor_sync(0xffffffff, sum_r0, 8);
    sum_r1 += __shfl_xor_sync(0xffffffff, sum_r1, 8);

    rL[0] = rL[0] * scale0 + sum_r0;
    rL[1] = rL[1] * scale1 + sum_r1;
}

// ── write_s_to_smem ───────────────────────────────────────────────────────────
// Write rS[8] to sS[BLOCK_M=16, TOPK_BLOCK_SIZE=16].
// Each thread writes 8 elements covering its 2 output rows × 4 cols (2 from each n8-tile).
// row0 = lane%4 + (lane/16)*4,  row1 = row0+8
// tile0 col_base = (lane/4%4)*2,  tile1 col_base = 8 + (lane/4%4)*2
template<int BLOCK_M, int TOPK>
__device__ __forceinline__
void write_s_to_smem(
    const __nv_bfloat16 rS[8],
    bf16* sS,
    int lane_in_warp
) {
    const int row0 = lane_in_warp % 4 + (lane_in_warp / 16) * 4;
    const int row1 = row0 + 8;
    const int cb0  = (lane_in_warp / 4 % 4) * 2;
    const int cb1  = 8 + cb0;

    sS[row0 * TOPK + cb0]     = rS[0];
    sS[row0 * TOPK + cb0 + 1] = rS[1];
    sS[row1 * TOPK + cb0]     = rS[2];
    sS[row1 * TOPK + cb0 + 1] = rS[3];
    sS[row0 * TOPK + cb1]     = rS[4];
    sS[row0 * TOPK + cb1 + 1] = rS[5];
    sS[row1 * TOPK + cb1]     = rS[6];
    sS[row1 * TOPK + cb1 + 1] = rS[7];
}

// ── mma_pv_sync ───────────────────────────────────────────────────────────────
// S @ V → rO using SM80 mma.sync.
//   S: [16, 16] bf16 in sS  (A operand, m16k16, row-major)
//   V: [16, V_COLS_PER_SG] bf16 in sK[0..15, v_col_offset..) (B operand, n8k16 transposed)
//
// Each warp handles n8-tiles for its V column range via round-robin:
//   warp_in_sg=0: n8-tiles {0, 2, 4, ..., 30}  → V cols {v_offset+0, v_offset+16, ...}
//   warp_in_sg=1: n8-tiles {1, 3, 5, ..., 31}  → V cols {v_offset+8, v_offset+24, ...}
// 16 tiles per warp × 4 floats = 64 = rO size ✓
//
// A ldmatrix.x4 (m16k16 from sS, K_TILES=1):
//   a_row = (lane/16)*8 + lane%8
//   a_col = (lane/8 % 2)*8
//
// B ldmatrix.x2.trans (n8k16 from sV):
//   addr = sK[(lane/8)*8 * SMEM_STRIDE_K + v_col_offset + n8_tile*8 + lane%8]
template<ModelType MODEL_TYPE, int NUM_HEADS>
__device__ __forceinline__
void mma_pv_sync(
    float rO[64],
    const typename KernelTemplate<MODEL_TYPE, NUM_HEADS>::SharedMemoryPlan &plan,
    int buf_idx,
    int v_col_offset,
    int lane_in_sg
) {
    using KT = KernelTemplate<MODEL_TYPE, NUM_HEADS>;
    static constexpr int N = KT::V_COLS_PER_SG;   // 256

    const int warp_in_sg   = lane_in_sg / 32;
    const int lane_in_warp = lane_in_sg % 32;

    const bf16* sS = plan.s.data();

    // Load A (m16k16 from sS, K_TILES=1)
    uint32_t a0, a1, a2, a3;
    {
        int a_row = (lane_in_warp / 16) * 8 + (lane_in_warp % 8);
        int a_col = (lane_in_warp / 8 % 2) * 8;
        uint32_t addr = __cvta_generic_to_shared(sS + a_row * KT::TOPK_BLOCK_SIZE + a_col);
        asm volatile("ldmatrix.sync.aligned.m8n8.x4.shared.b16 {%0,%1,%2,%3}, [%4];\n"
                     : "=r"(a0), "=r"(a1), "=r"(a2), "=r"(a3) : "r"(addr));
    }

    CUTE_UNROLL
    for (int n8 = warp_in_sg; n8 < N / 8; n8 += 2) {
        int tile_idx = n8 / 2;   // [0..15]
        float& c0 = rO[tile_idx * 4 + 0];
        float& c1 = rO[tile_idx * 4 + 1];
        float& c2 = rO[tile_idx * 4 + 2];
        float& c3 = rO[tile_idx * 4 + 3];

        uint32_t b0, b1;
        {
            // B = V[k=0..15, n8-tile cols]  stored as sK row-major
            // ldmatrix.x2.trans: thread t → sK[(t/8)*8 * STRIDE + v_col + n8*8 + t%8]
            int k_start = (lane_in_warp / 8) * 8;
            int v_col   = v_col_offset + n8 * 8 + (lane_in_warp % 8);
            uint32_t addr = __cvta_generic_to_shared(
                plan.k[buf_idx].data() + k_start * KT::SMEM_STRIDE_K + v_col);
            asm volatile("ldmatrix.sync.aligned.m8n8.x2.trans.shared.b16 {%0,%1}, [%2];\n"
                         : "=r"(b0), "=r"(b1) : "r"(addr));
        }
        asm volatile(
            "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 "
            "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
            : "+f"(c0), "+f"(c1), "+f"(c2), "+f"(c3)
            : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
    }
}

// ── store_o ───────────────────────────────────────────────────────────────────
// rO[t*4+{0,1}] → row0 output,  rO[t*4+{2,3}] → row1 output
// n8_global = warp_in_sg + t*2  (round-robin tile assignment from mma_pv_sync)
// col = v_col_offset + n8_global*8 + (lane/4 % 4)*2 + e%2
template<bool IS_NO_SPLIT, ModelType MODEL_TYPE, int NUM_HEADS>
__device__ __forceinline__
void store_o(
    const float  rO[64],
    const float  o_scales[2],    // [row0_scale, row1_scale]
    int          v_col_offset,
    int          batch_idx,
    int          s_q_idx,
    int          head_block_idx,
    int          num_valid_heads,
    int          split_idx,
    const SparseAttnDecodeParams &params,
    int          lane_in_sg
) {
    using KT = KernelTemplate<MODEL_TYPE, NUM_HEADS>;

    const int warp_in_sg   = lane_in_sg / 32;
    const int lane_in_warp = lane_in_sg % 32;
    const int row0         = lane_in_warp % 4 + (lane_in_warp / 16) * 4;
    const int row1         = row0 + 8;
    const int col_w        = (lane_in_warp / 4 % 4) * 2;  // within-tile column offset
    const int start_head   = head_block_idx * KT::BLOCK_M;

    CUTE_UNROLL
    for (int t = 0; t < 16; ++t) {
        int n8_global  = warp_in_sg + t * 2;
        int col_base   = v_col_offset + n8_global * 8 + col_w;

        CUTE_UNROLL
        for (int e = 0; e < 4; ++e) {
            int row      = (e < 2) ? row0 : row1;
            int col      = col_base + (e % 2);
            int head_idx = start_head + row;
            if (head_idx >= params.h_q) continue;
            if (row >= num_valid_heads) continue;

            float val = rO[t * 4 + e] * o_scales[e / 2];

            if constexpr (IS_NO_SPLIT) {
                bf16* dst = (bf16*)params.out
                    + (int64_t)batch_idx * params.stride_o_b
                    + (int64_t)s_q_idx   * params.stride_o_s_q
                    + (int64_t)head_idx  * params.stride_o_h_q
                    + col;
                *dst = (__nv_bfloat16)val;
            } else {
                float* dst = params.o_accum
                    + (int64_t)split_idx * params.stride_o_accum_split
                    + (int64_t)s_q_idx   * params.stride_o_accum_s_q
                    + (int64_t)head_idx  * params.stride_o_accum_h_q
                    + col;
                *dst = val;
            }
        }
    }
}

// ── devfunc ───────────────────────────────────────────────────────────────────
template<ModelType MODEL_TYPE, int NUM_HEADS>
__device__ __forceinline__
void KernelTemplate<MODEL_TYPE, NUM_HEADS>::devfunc(const SparseAttnDecodeParams &params) {
#if defined(__CUDA_ARCH__) && (__CUDA_ARCH__ >= 800)

    const int head_block_idx = blockIdx.x;   // [0, NUM_M_BLOCKS)
    const int s_q_idx        = blockIdx.y;
    const int partition_idx  = blockIdx.z;

    // Sub-group: sg0 (warps 0-1, threadIdx.x 0..63) and sg1 (warps 2-3, 64..127)
    const int sg_id       = threadIdx.x / THREADS_PER_SG;
    const int lane_in_sg  = threadIdx.x % THREADS_PER_SG;
    const int lane_in_warp = lane_in_sg % 32;
    const int v_col_offset = sg_id * V_COLS_PER_SG;

    extern __shared__ char wksp_buf[];
    SharedMemoryPlan &plan = *reinterpret_cast<SharedMemoryPlan*>(wksp_buf);

    DecodingSchedMeta sched_meta = params.tile_scheduler_metadata_ptr[partition_idx];
    if (sched_meta.begin_req_idx >= params.b) return;

    struct MainloopArgs {
        int  start_block_idx, end_block_idx;
        bool is_no_split;
        int  topk_length, extra_topk_length, num_orig_kv_blocks;
    };

    auto get_cur_req_info = [&](int batch_idx) -> MainloopArgs {
        MainloopArgs args;
        int total_topk_padded;
        if constexpr (MODEL_TYPE == ModelType::V32) {
            total_topk_padded = params.topk;
            args.topk_length = 0; args.extra_topk_length = 0; args.num_orig_kv_blocks = 0;
        } else {
            int tkl  = params.topk_length  ? __ldg(params.topk_length  + batch_idx) : params.topk;
            int orig = max(ku::ceil(tkl, (int)TOPK_BLOCK_SIZE), (int)TOPK_BLOCK_SIZE);
            int etkl = params.extra_topk_length ? __ldg(params.extra_topk_length + batch_idx) : params.extra_topk;
            total_topk_padded       = orig + ku::ceil(etkl, (int)TOPK_BLOCK_SIZE);
            args.topk_length        = tkl;
            args.extra_topk_length  = etkl;
            args.num_orig_kv_blocks = orig / TOPK_BLOCK_SIZE;
        }
        int end_b = total_topk_padded / TOPK_BLOCK_SIZE;
        args.start_block_idx = (batch_idx == sched_meta.begin_req_idx) ? sched_meta.begin_block_idx : 0;
        args.end_block_idx   = (batch_idx == sched_meta.end_req_idx)   ? sched_meta.end_block_idx   : end_b;
        args.is_no_split     = (batch_idx == sched_meta.begin_req_idx) ? !sched_meta.is_first_req_splitted
                             : (batch_idx == sched_meta.end_req_idx)   ? !sched_meta.is_last_req_splitted : true;
        return args;
    };

    #pragma unroll 1
    for (int batch_idx = sched_meta.begin_req_idx; batch_idx <= sched_meta.end_req_idx; ++batch_idx) {
        MainloopArgs args = get_cur_req_info(batch_idx);

        // Load Q into SMEM
        load_q_to_smem<MODEL_TYPE, NUM_HEADS>(plan.q.data(), params, batch_idx, s_q_idx, head_block_idx);
        cp_async_commit();
        cp_async_wait_all();
        __syncthreads();

        // Accumulators
        float rL[2] = {0.f, 0.f};
        float rM[2] = {MAX_INIT_VAL, MAX_INIT_VAL};
        float rO[64];
        CUTE_UNROLL for (int i = 0; i < 64; ++i) rO[i] = 0.f;

        // Attention sink (log2-scaled, per owned row)
        float attn_sink[2] = {-CUDART_INF_F, -CUDART_INF_F};
        if (params.attn_sink) {
            const int row0 = lane_in_warp % 4 + (lane_in_warp / 16) * 4;
            const int h0   = head_block_idx * BLOCK_M;
            attn_sink[0] = __ldg((const float*)params.attn_sink + h0 + row0)     * CUDART_L2E_F;
            attn_sink[1] = __ldg((const float*)params.attn_sink + h0 + row0 + 8) * CUDART_L2E_F;
        }

        // Prefetch first K block
        if (args.start_block_idx < args.end_block_idx) {
            load_kv_block<MODEL_TYPE, NUM_HEADS>(params, plan,
                batch_idx, s_q_idx, args.start_block_idx, 0,
                args.topk_length, args.extra_topk_length, args.num_orig_kv_blocks);
            cp_async_commit();
        }

        #pragma unroll 1
        for (int block_idx = args.start_block_idx; block_idx < args.end_block_idx; ++block_idx) {
            int buf_idx  = (block_idx - args.start_block_idx) % NUM_K_BUFS;
            int next_blk = block_idx + 1;

            if (next_blk < args.end_block_idx) {
                int next_buf = 1 - buf_idx;
                load_kv_block<MODEL_TYPE, NUM_HEADS>(params, plan,
                    batch_idx, s_q_idx, next_blk, next_buf,
                    args.topk_length, args.extra_topk_length, args.num_orig_kv_blocks);
                cp_async_commit();
            }

            cp_async_wait_group<1>();
            __syncthreads();

            // Q @ K → rP[8]  (each warp independently computes m16×n16)
            float rP[8];
            mma_qk_sync<MODEL_TYPE, NUM_HEADS>(rP, plan, buf_idx, lane_in_warp);

            // Online softmax (intra-warp reduction only; both sub-groups redundantly update)
            __nv_bfloat16 rS[8];
            scale_softmax(rP, rS, rO,
                          params.sm_scale_div_log2,
                          rM, rL,
                          plan.is_kv_valid[buf_idx],
                          lane_in_warp, attn_sink);

            // Only sg0 writes sS (sg1 reads it for PV; sg0 and sg1 have identical rS)
            if (sg_id == 0) {
                write_s_to_smem<BLOCK_M, TOPK_BLOCK_SIZE>(rS, plan.s.data(), lane_in_warp);
            }
            __syncthreads();

            // S @ V → rO (each sub-group handles its V column range)
            mma_pv_sync<MODEL_TYPE, NUM_HEADS>(rO, plan, buf_idx, v_col_offset, lane_in_sg);

            __syncthreads();
        }  // end K-block loop

        // Epilogue: per-row normalization scale
        float o_scales[2];
        CUTE_UNROLL
        for (int i = 0; i < 2; ++i) {
            float L = rL[i], M = rM[i];
            float sink = (params.attn_sink && args.is_no_split) ? exp2f(attn_sink[i] - M) : 0.f;
            o_scales[i] = (L == 0.f) ? 0.f : (args.is_no_split ? 1.f / (L + sink) : 1.f / L);
        }

        const int start_head      = head_block_idx * BLOCK_M;
        const int num_valid_heads = min(params.h_q - start_head, BLOCK_M);

        if (args.is_no_split) {
            store_o<true, MODEL_TYPE, NUM_HEADS>(
                rO, o_scales, v_col_offset,
                batch_idx, s_q_idx, head_block_idx, num_valid_heads,
                0, params, lane_in_sg);

            // LSE written by one thread per output head
            // Use the thread whose row0 = row within the head block
            // (lane_in_warp%4 + (lane_in_warp/16)*4 covers rows 0..7)
            // For BLOCK_M=16: we have 8 unique row0 values; same for row1
            // sg0 writes rows 0..7 (via row0 mapping) and rows 8..15 (via row1)
            if (sg_id == 0) {
                const int row0_lse = lane_in_warp % 4 + (lane_in_warp / 16) * 4;
                // Write LSE for row0 and row1
                CUTE_UNROLL
                for (int ri = 0; ri < 2; ++ri) {
                    int row = row0_lse + ri * 8;
                    int head_idx = start_head + row;
                    if (head_idx < params.h_q && (lane_in_warp / 4 % 4) == 0) {
                        float L = rL[ri], M = rM[ri];
                        float* lse_ptr = params.lse
                            + batch_idx * params.stride_lse_b
                            + s_q_idx   * params.stride_lse_s_q
                            + head_idx;
                        *lse_ptr = (L == 0.f) ? CUDART_INF_F : logf(L) + M / (float)M_LOG2E;
                    }
                }
            }
        } else {
            int n_split_idx = (batch_idx == sched_meta.begin_req_idx) ? sched_meta.begin_split_idx : 0;
            int split_idx   = __ldg(params.num_splits_ptr + batch_idx) + n_split_idx;

            store_o<false, MODEL_TYPE, NUM_HEADS>(
                rO, o_scales, v_col_offset,
                batch_idx, s_q_idx, head_block_idx, num_valid_heads,
                split_idx, params, lane_in_sg);

            if (sg_id == 0) {
                const int row0_lse = lane_in_warp % 4 + (lane_in_warp / 16) * 4;
                CUTE_UNROLL
                for (int ri = 0; ri < 2; ++ri) {
                    int row = row0_lse + ri * 8;
                    int head_idx = start_head + row;
                    if (head_idx < params.h_q && (lane_in_warp / 4 % 4) == 0) {
                        float L = rL[ri], M = rM[ri];
                        float* lse_acc = params.lse_accum
                            + (int64_t)split_idx * params.stride_lse_accum_split
                            + (int64_t)s_q_idx   * params.stride_lse_accum_s_q
                            + head_idx;
                        *lse_acc = (L == 0.f) ? -CUDART_INF_F : log2f(L) + M;
                    }
                }
            }
        }

        __syncthreads();
    }  // end batch loop

#else
    if (threadIdx.x == 0) {
        printf("[FlashMLA/sm89] kernel requires SM80+\n");
    }
#endif
}

// ── Global kernel wrapper ─────────────────────────────────────────────────────
template<ModelType MODEL_TYPE, int NUM_HEADS>
__global__
__launch_bounds__(KernelTemplate<MODEL_TYPE, NUM_HEADS>::NUM_THREADS)
void flash_fwd_splitkv_mla_fp8_sparse_sm89_kernel(
    const SparseAttnDecodeParams params
) {
    KernelTemplate<MODEL_TYPE, NUM_HEADS>::devfunc(params);
}

// ── run() ─────────────────────────────────────────────────────────────────────
template<ModelType MODEL_TYPE, int NUM_HEADS>
void KernelTemplate<MODEL_TYPE, NUM_HEADS>::run(const SparseAttnDecodeParams &params) {
    KU_ASSERT(params.h_kv == 1);
    KU_ASSERT(params.topk % TOPK_BLOCK_SIZE == 0);
    KU_ASSERT(params.d_qk == HEAD_DIM_K);
    KU_ASSERT(params.d_v  == HEAD_DIM_V);
    KU_ASSERT(params.h_q  % BLOCK_M == 0);

    if constexpr (MODEL_TYPE == ModelType::V32) {
        KU_ASSERT(params.extra_kv == nullptr);
        KU_ASSERT(params.topk_length == nullptr);
        KU_ASSERT(params.stride_kv_row == 656);
    }

    constexpr size_t smem_size = sizeof(SharedMemoryPlan);
    auto kernel_fn = &flash_fwd_splitkv_mla_fp8_sparse_sm89_kernel<MODEL_TYPE, NUM_HEADS>;
    KU_CUDA_CHECK(cudaFuncSetAttribute(
        kernel_fn, cudaFuncAttributeMaxDynamicSharedMemorySize, smem_size));

    dim3 grid(NUM_M_BLOCKS, params.s_q, params.num_sm_parts);
    dim3 block(NUM_THREADS);
    kernel_fn<<<grid, block, smem_size, params.stream>>>(params);
    KU_CHECK_KERNEL_LAUNCH();
}

template<ModelType MODEL_TYPE, int NUM_HEADS>
void run_flash_splitkv_mla_fp8_sparse_sm89_kernel(const SparseAttnDecodeParams &params) {
    KernelTemplate<MODEL_TYPE, NUM_HEADS>::run(params);
}

}  // namespace sm89::decode::sparse_fp8
