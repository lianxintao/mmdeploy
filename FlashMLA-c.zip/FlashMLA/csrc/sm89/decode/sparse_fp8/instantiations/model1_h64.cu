#include "../kernel.cu"

namespace sm89::decode::sparse_fp8 {

template void run_flash_splitkv_mla_fp8_sparse_sm89_kernel<ModelType::MODEL1, 64>(
    const SparseAttnDecodeParams &params);

} // namespace sm89::decode::sparse_fp8
