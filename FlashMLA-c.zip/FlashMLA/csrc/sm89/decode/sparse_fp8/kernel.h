#pragma once

#include "config.h"

namespace sm89::decode::sparse_fp8 {

template<ModelType MODEL_TYPE, int NUM_HEADS>
void run_flash_splitkv_mla_fp8_sparse_sm89_kernel(const SparseAttnDecodeParams &params);

} // namespace sm89::decode::sparse_fp8
