# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Install

```bash
git submodule update --init --recursive
pip install -v .
```

This compiles CUDA kernels via `torch.utils.cpp_extension` into the `flash_mla.cuda` extension module. The build automatically detects NVCC version and enables SM90/SM100 architectures accordingly.

**Environment variables controlling the build:**
- `FLASH_MLA_DISABLE_SM100=1` — skip SM100 (Blackwell) kernels (required if NVCC < 12.9)
- `FLASH_MLA_DISABLE_SM90=1` — skip SM90 (Hopper) kernels
- `FLASH_MLA_DISABLE_FP16=1` — disable FP16 support
- `NVCC_THREADS` — NVCC parallel threads (default 32)
- `CUDA_HOME` — CUDA installation path (use the one PyTorch was compiled with)

## Testing

```bash
python tests/test_flash_mla_dense_decoding.py     # Dense MLA decoding (SM90)
python tests/test_flash_mla_sparse_decoding.py     # Sparse MLA decoding (SM90/SM100)
python tests/test_flash_mla_sparse_prefill.py      # Sparse MLA prefill (SM90/SM100)
python tests/test_fmha_sm100.py                    # Dense MHA prefill fwd/bwd (SM100)
```

Tests verify correctness against reference PyTorch implementations (`tests/ref.py`). SM100 tests require CUDA 12.9+ and a Blackwell GPU.

## Architecture

FlashMLA provides optimized GPU attention kernels for two GPU generations (SM90 Hopper / SM100 Blackwell) across four kernel categories: dense decode, sparse decode, sparse prefill, and dense prefill.

### Python layer (`flash_mla/`)

The `flash_mla` package is a thin Python wrapper over the compiled CUDA extension (`flash_mla.cuda`). It exports 6 public functions:

- **`get_mla_metadata()`** — returns a `FlashMLASchedMeta` dataclass. Call once before the decoding loop; the actual tile scheduler metadata is computed lazily on the first `flash_mla_with_kvcache` call.
- **`flash_mla_with_kvcache()`** — the main decoding entry point. Automatically dispatches between sparse (FP8 KV cache, MQA mode) and dense (BF16 KV cache) paths, and between the native CUDA extension and the SM89 TileLang fallback based on GPU capability and `FLASH_MLA_USE_TILELANG_SM89` env var.
- **`flash_mla_sparse_fwd()`** — sparse prefill forward (MQA mode, no batch dimension).
- **`flash_attn_varlen_func()`** / **`flash_attn_varlen_qkvpacked_func()`** / **`flash_attn_varlen_kvpacked_func()`** — dense MHA prefill forward+backward (SM100 only, `flash_attn`-compatible API).

`FlashMLASchedMeta` is a dataclass that holds tile scheduler metadata and validates that tensor shapes/configs are consistent across repeated calls with the same metadata instance.

**SM89 fallback** (`tilelang_sm89_backend.py`): When running on Ada (SM89) GPUs or when `FLASH_MLA_USE_TILELANG_SM89=1` is set, the decode paths use a pure PyTorch + optional TileLang backend that reproduces the scheduler, split-KV, and combine semantics at a functional level.

### C++/CUDA layer (`csrc/`)

The CUDA source follows a two-level architecture split:

1. **`csrc/api/`** — C++ entry points (`api.cpp`) that bridge Python tensor arguments to CUDA kernel launches. Each kernel family has its own header (`dense_decode.h`, `sparse_decode.h`, `dense_fwd.h`, `sparse_fwd.h`).

2. **Architecture-specific directories:**
   - **`csrc/sm90/`** — Hopper kernels using TMA/WGMMA (requires SM90+ hardware).
     - `decode/dense/` — dense BF16 MLA decoding
     - `decode/sparse_fp8/` — sparse FP8 decoding with FP8 cache dequantization (two model variants: V32 and MODEL1, with h64/h128 head dimension instantiations)
     - `prefill/sparse/` — sparse prefill with phase1 kernel (k512/k576 instantiations, with/without topk_length support)
   - **`csrc/sm100/`** — Blackwell kernels.
     - `prefill/dense/` — dense MHA forward+backward using CUTLASS (requires CUTLASS submodule)
     - `prefill/sparse/` — sparse prefill (head64/head128, k512/k576 instantiations, plus small-topk variant)
     - `decode/` — sparse FP8 decode (V32 and MODEL1 instantiations)
   - **`csrc/smxx/`** — architecture-agnostic kernels: `get_decoding_sched_meta` (tile scheduler) and `combine` (split-KV partial reduction).

3. **`csrc/kerutils/`** — utility headers for tensor handling and host-side helpers.
4. **`csrc/cutlass/`** — git submodule; the CUTLASS library used for SM100 dense prefill kernels.

### Key constraints

- `head_dim_v` must always be 512.
- Sparse attention (decode and prefill) requires MQA mode: `h_kv` = 1, `head_dim_k` = 576.
- Dense MHA prefill (SM100) requires MHA mode: `head_dim_k` = 192 or 128, `head_dim_v` = 128. GQA backward is not yet supported.
- Sparse attention uses an FP8 KV cache format (656 bytes/token: 512×fp8_e4m3 NoPE + 16 bytes scales + 128 bytes RoPE bf16), dequantized to bfloat16 during computation.
- Sparse decode on SM100 requires the KV cache tensor to be contiguously valid in memory (no IMA across the entire tensor).
- The `indices` tensor for sparse attention encodes physical page-block offsets: `block_index * page_block_size + offset_within_block`. Invalid entries set to `-1`.
- `FlashMLASchedMeta` reuses cached tile scheduling metadata across calls and validates consistency — shape/config changes require a fresh metadata instance.

### Test architecture

Tests follow a common pattern: `tests/lib.py` defines shared test parameter dataclasses (`TestParam`, `Testcase`, `TestcaseForDecode`, `KVScope`). Each test generates random inputs, runs the FlashMLA kernel, and compares against a reference PyTorch implementation from `tests/ref.py`. `tests/quant.py` handles FP8 quantization/dequantization for sparse attention tests.
