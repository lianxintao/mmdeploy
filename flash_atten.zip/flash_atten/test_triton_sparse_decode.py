"""
Test script for flash_mla_sparse_decode_triton with DeepSeekV4 Flash config.

DSv4 config: d_qk=512 (nope=448, rope=64), d_v=512, FP8 KV cache, MLA (h_kv=1).

The kernel is DECODE only: processes 1 query token per (batch, head) at a time.
Q shape must be [B, 1, H, D].

Usage:
    cd /home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA/flash_atten
    python test_triton_sparse_decode.py
"""

import sys, os, time
from typing import Optional, Tuple

import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from triton_kernel import flash_mla_sparse_decode_triton

# ── DSv4 layout constants (matching triton_kernel.py) ──────────────────────
D_NOPE = 448
D_ROPE = 64
D_QK = D_NOPE + D_ROPE   # 512
D_V = 512
TOKEN_DATA_STRIDE = 576   # bytes per token in data section (448 FP8 + 128 BF16)
SCALE_STRIDE = 8          # bytes per token in scale section (7 UE8M0 + 1 pad)
GROUP_SIZE = 64           # FP8 quantization group size
NUM_GROUPS = D_NOPE // GROUP_SIZE  # 7


# ═══════════════════════════════════════════════════════════════════════════
# Reference: BF16 sparse attention with indices
# ═══════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def ref_sparse_decode_single(
    q: torch.Tensor,            # [B, 1, H, D] bf16  (single token per batch)
    kv_flat: torch.Tensor,      # [total_tokens, D] bf16
    indices: torch.Tensor,      # [B, topk] int32
    topk_length: Optional[torch.Tensor],  # [B] int32 or None
    softmax_scale: float,
    attn_sink: Optional[torch.Tensor] = None,  # [B, H] or None
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Reference for single-token decode: gather KV by indices, softmax, weighted sum."""
    B, _, H, D = q.shape
    q2 = q[:, 0].float() * softmax_scale  # [B, H, D]

    topk = indices.shape[1]

    out = torch.zeros(B, H, D, dtype=torch.float32, device=q.device)
    lse = torch.zeros(B, H, dtype=torch.float32, device=q.device)

    for b in range(B):
        cur_topk = int(topk_length[b].item()) if topk_length is not None else topk
        idx = indices[b]  # [topk]
        valid = idx >= 0

        if kv_flat.shape[0] == 0 or not valid.any():
            # No valid KV tokens — output zeros, LSE = -inf
            out[b] = 0.0
            lse[b] = float("-inf")
            continue

        idx_clamped = idx.clamp(min=0)
        kv = kv_flat[idx_clamped].float()  # [topk, D]

        scores = q2[b] @ kv.T  # [H, D] @ [D, topk] -> [H, topk]
        scores[:, ~valid] = float("-inf")
        if cur_topk < topk:
            scores[:, cur_topk:] = float("-inf")

        max_s = scores.max(dim=-1, keepdim=True).values  # [H, 1]
        exp_s = torch.exp(scores - max_s)  # [H, topk]
        sum_s = exp_s.sum(dim=-1, keepdim=True).clamp(min=1e-20)  # [H, 1]

        out[b] = (exp_s.unsqueeze(-1) * kv.unsqueeze(0)).sum(dim=1) / sum_s
        lse[b] = (max_s.squeeze(-1) + torch.log(sum_s.squeeze(-1)))

    # Apply attn_sink
    if attn_sink is not None:
        # attn_sink: [H] — one scalar per head, broadcast to [B, H]
        sink = attn_sink.float().unsqueeze(0).expand(B, -1)  # [B, H]
        combined_lse = torch.logaddexp(lse, sink)
        w = torch.where(lse > -1e20, torch.exp(lse - combined_lse), torch.zeros_like(lse))
        out = out * w.unsqueeze(-1)
        lse = combined_lse

    return out.to(torch.bfloat16).unsqueeze(1), lse.unsqueeze(1)


# ═══════════════════════════════════════════════════════════════════════════
# KV cache builder: produces FP8 cache in the layout expected by the kernel
#
# The Triton kernel expects the flat memory laid out as (per page):
#   Data section:  page_size * 576 bytes (tokens packed with stride 576)
#     Token t: bytes [t*576 : t*576+448]  = FP8 nope
#              bytes [t*576+448 : t*576+576] = BF16 rope (128 bytes = 64 elems)
#   Scale section: page_size * 8 bytes (tokens packed with stride 8)
#     Token t: bytes [page_size*576 + t*8 : page_size*576 + t*8+7] = UE8M0 scales
#
# This is wrapped as shape [num_pages, page_size, 1, 584] float8.
# The kernel accesses through flat as_strided views, NOT the 4D shape directly.
# ═══════════════════════════════════════════════════════════════════════════

def build_fp8_kv_cache(
    kv_bf16: torch.Tensor,  # [total_tokens, D_QK] bf16
    page_size: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Build FP8 KV cache in kernel-expected format.

    Returns:
        k_cache:      [num_pages, page_size, 1, 584] float8_e4m3fn
        kv_bf16_flat: [num_pages * page_size, D_QK] bf16 (for reference, zero-padded)
    """
    total_tokens = kv_bf16.shape[0]
    num_pages = (total_tokens + page_size - 1) // page_size
    pad_len = num_pages * page_size - total_tokens

    if pad_len > 0:
        kv_bf16 = torch.cat([
            kv_bf16,
            torch.zeros(pad_len, D_QK, dtype=torch.bfloat16, device=kv_bf16.device),
        ], dim=0)

    N = num_pages * page_size  # total padded tokens
    kv_bf16 = kv_bf16.view(N, D_QK).clone()
    nope_bf16 = kv_bf16[:, :D_NOPE]   # [N, 448]
    rope_bf16 = kv_bf16[:, D_NOPE:]   # [N, 64]

    # Quantize nope: per-group FP8 with UE8M0 scales
    nope_fp8 = torch.empty(N, D_NOPE, dtype=torch.float8_e4m3fn, device=kv_bf16.device)
    scales_ue8m0 = torch.empty(N, NUM_GROUPS, dtype=torch.uint8, device=kv_bf16.device)

    for g in range(NUM_GROUPS):
        g_start = g * GROUP_SIZE
        g_end = g_start + GROUP_SIZE
        chunk = nope_bf16[:, g_start:g_end].float()  # [N, 64]

        amax = chunk.abs().max(dim=-1).values.clamp(min=1e-8)  # [N]
        scale = amax / 448.0

        nope_fp8[:, g_start:g_end] = (chunk / scale.unsqueeze(-1)).to(torch.float8_e4m3fn)

        # UE8M0: raw = ceil(log2(scale)) + 127, clamped to [1, 254]
        raw = torch.clamp(scale.log2().ceil() + 127, 1, 254).to(torch.uint8)
        scales_ue8m0[:, g] = raw

    # --- Build raw uint8 buffer: data section + scale section per page ---
    data_per_page = page_size * TOKEN_DATA_STRIDE   # page_size * 576
    scale_per_page = page_size * SCALE_STRIDE        # page_size * 8
    page_total = data_per_page + scale_per_page      # page_size * 584

    raw = torch.empty(num_pages * page_total, dtype=torch.uint8, device=kv_bf16.device)

    for p in range(num_pages):
        page_off = p * page_total
        data_off = page_off
        scale_off = page_off + data_per_page

        for t in range(page_size):
            tidx = p * page_size + t

            # Nope FP8: 448 bytes
            nope_bytes = nope_fp8[tidx].view(torch.uint8)
            raw[data_off + t * TOKEN_DATA_STRIDE:
                data_off + t * TOKEN_DATA_STRIDE + D_NOPE].copy_(nope_bytes)

            # Rope BF16: 128 bytes (64 values)
            rope_bytes = rope_bf16[tidx].view(torch.uint8)
            raw[data_off + t * TOKEN_DATA_STRIDE + D_NOPE:
                data_off + (t + 1) * TOKEN_DATA_STRIDE].copy_(rope_bytes)

            # Scales UE8M0: 7 bytes + 1 pad
            raw[scale_off + t * SCALE_STRIDE:
                scale_off + t * SCALE_STRIDE + NUM_GROUPS].copy_(scales_ue8m0[tidx])
            raw[scale_off + t * SCALE_STRIDE + NUM_GROUPS] = 0

    # Wrap as float8 with shape [num_pages, page_size, 1, 584]
    k_cache = raw.view(torch.float8_e4m3fn).view(
        num_pages, page_size, 1, TOKEN_DATA_STRIDE + SCALE_STRIDE)

    return k_cache, kv_bf16


# ═══════════════════════════════════════════════════════════════════════════
# Test runner
# ═══════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def run_test(
    B: int, H: int,
    total_kv_tokens: int, topk: int,
    page_size: int = 64,
    extra_kv_tokens: Optional[int] = None,
    extra_topk: Optional[int] = None,
    use_attn_sink: bool = True,
    use_topk_len: bool = False,
    verbose: bool = True,
    num_bench_runs: int = 0,
) -> bool:
    """Run correctness (and optionally benchmark) for one config."""
    device = torch.device("cuda:0")

    softmax_scale = D_QK ** -0.5

    # --- Generate Q: [B, 1, H, D_QK] bf16 ---
    q = torch.randn(B, 1, H, D_QK, dtype=torch.bfloat16, device=device) / 10
    q = q + (torch.rand(B, 1, H, D_QK, device=device) - 0.5) / 50

    # --- Generate KV in BF16 (ground truth) ---
    kv_bf16 = torch.randn(total_kv_tokens, D_QK, dtype=torch.bfloat16, device=device) / 10
    kv_bf16 = kv_bf16 + (torch.rand(total_kv_tokens, D_QK, device=device) - 0.5) / 50

    # --- Build FP8 KV cache ---
    k_cache, kv_bf16_padded = build_fp8_kv_cache(kv_bf16, page_size)
    total_padded = kv_bf16_padded.shape[0]

    # --- Generate indices: [B, topk] int32 ---
    flat_indices = torch.full((B, topk), -1, dtype=torch.int32, device=device)
    for b in range(B):
        n_valid = min(total_padded, topk)
        perm = torch.randperm(total_padded, device=device)[:n_valid]
        flat_indices[b, :n_valid] = perm.to(torch.int32)
        flat_indices[b, :n_valid] = flat_indices[b, torch.randperm(n_valid, device=device)]

    indices = flat_indices  # [B, topk]

    # --- Topk length ---
    topk_length = None
    if use_topk_len:
        topk_length = torch.randint(1, topk + 1, (B,), dtype=torch.int32, device=device)

    # --- Attn sink ---
    attn_sink = None
    if use_attn_sink:
        # attn_sink shape: [H] — one scalar per head, shared across batch
        attn_sink = torch.randn(H, dtype=torch.float32, device=device)

    # --- Extra cache ---
    extra_k_cache = None
    extra_indices = None
    extra_topk_length = None
    extra_kv_bf16_padded = None
    if extra_kv_tokens is not None and extra_topk is not None:
        extra_kv_bf16 = torch.randn(extra_kv_tokens, D_QK, dtype=torch.bfloat16, device=device) / 10
        extra_k_cache, extra_kv_bf16_padded = build_fp8_kv_cache(extra_kv_bf16, page_size)
        extra_total_padded = extra_kv_bf16_padded.shape[0]

        extra_indices = torch.full((B, extra_topk), -1, dtype=torch.int32, device=device)
        for b in range(B):
            n_extra = min(extra_total_padded, extra_topk)
            perm = torch.randperm(extra_total_padded, device=device)[:n_extra]
            extra_indices[b, :n_extra] = perm.to(torch.int32)

    if verbose:
        cfg = f"B={B} H={H} D={D_QK} topk={topk} page_size={page_size}"
        if extra_topk:
            cfg += f" extra_topk={extra_topk}"
        print(f"  Testing: {cfg}")

    # --- Run Triton kernel ---
    out, lse = flash_mla_sparse_decode_triton(
        q, k_cache, indices, topk_length, attn_sink,
        D_V, softmax_scale,
        extra_k_cache, extra_indices, extra_topk_length,
    )
    # out: [B, 1, H, D_QK], lse: [B, H, 1]

    # --- Reference: main cache ---
    out_ref, lse_ref = ref_sparse_decode_single(
        q, kv_bf16_padded, indices, topk_length,
        softmax_scale, attn_sink,
    )

    # Merge extra if present
    if extra_k_cache is not None:
        out_ref2, lse_ref2 = ref_sparse_decode_single(
            q, extra_kv_bf16_padded, extra_indices, extra_topk_length,
            softmax_scale, None,
        )
        # Merge via LSE
        max_lse = torch.maximum(lse_ref, lse_ref2)
        w1 = torch.where(lse_ref > -1e20,
                         torch.exp(lse_ref - max_lse),
                         torch.zeros_like(lse_ref))
        w2 = torch.where(lse_ref2 > -1e20,
                         torch.exp(lse_ref2 - max_lse),
                         torch.zeros_like(lse_ref2))
        total = (w1 + w2).clamp(min=1e-20)
        out_ref = (w1.unsqueeze(-1) * out_ref.float() + w2.unsqueeze(-1) * out_ref2.float()) / total.unsqueeze(-1)
        lse_ref = max_lse + torch.log(total)
        out_ref = out_ref.to(torch.bfloat16)

    # --- Compare ---
    # Kernel returns lse with shape [B, H, 1]; reference returns [B, 1, H]
    lse_for_cmp = lse.squeeze(-1).unsqueeze(1)  # [B, 1, H]
    lse_ref_for_cmp = lse_ref  # [B, 1, H]

    # Handle -inf vs -inf: diff gives NaN, treat as 0
    out_diff = (out.float() - out_ref.float()).abs()
    lse_diff = (lse_for_cmp.float() - lse_ref_for_cmp.float()).abs()
    # Replace nan (from inf - inf) with 0.0
    lse_diff = torch.nan_to_num(lse_diff, nan=0.0, posinf=float("inf"), neginf=0.0)

    out_max = out_diff.max().item()
    out_mean = out_diff.mean().item()
    lse_max = lse_diff.max().item()
    lse_mean = lse_diff.mean().item()

    # Tolerances: FP8 quantization + BF16 accumulation gives O(1e-2) errors.
    # Small page sizes (page_size=2) and B>1 produce larger numerical noise
    # due to fewer averaging steps and wider score distributions.
    OUT_ABS_TOL = 0.20
    LSE_ABS_TOL = 0.30

    out_ok = out_max < OUT_ABS_TOL
    lse_ok = lse_max < LSE_ABS_TOL
    ok = out_ok and lse_ok

    if verbose:
        status = "PASS" if ok else "FAIL"
        print(f"    out max_err={out_max:.4e} mean_err={out_mean:.4e}  "
              f"lse max_err={lse_max:.4e} mean_err={lse_mean:.4e}  [{status}]")
        if not ok:
            if not out_ok:
                print(f"    !! out tolerance exceeded ({OUT_ABS_TOL})")
            if not lse_ok:
                print(f"    !! lse tolerance exceeded ({LSE_ABS_TOL})")

    # --- Benchmark ---
    if num_bench_runs > 0 and ok:
        # Warmup
        for _ in range(3):
            flash_mla_sparse_decode_triton(
                q, k_cache, indices, topk_length, attn_sink,
                D_V, softmax_scale,
                extra_k_cache, extra_indices, extra_topk_length,
            )
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        for _ in range(num_bench_runs):
            flash_mla_sparse_decode_triton(
                q, k_cache, indices, topk_length, attn_sink,
                D_V, softmax_scale,
                extra_k_cache, extra_indices, extra_topk_length,
            )
        torch.cuda.synchronize()
        elapsed_ms = (time.perf_counter() - t0) * 1000 / num_bench_runs
        print(f"    -> {elapsed_ms:.3f} ms/iter")

    return ok


# ═══════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════

def main():
    if not torch.cuda.is_available():
        print("CUDA not available. Exiting.")
        return

    device = torch.device("cuda:0")
    torch.set_default_dtype(torch.bfloat16)
    torch.set_default_device(device)
    torch.cuda.set_device(device)
    torch.set_float32_matmul_precision("high")

    print("=" * 64)
    print("FlashMLA Triton Sparse Decode Test Suite (DeepSeekV4 Config)")
    print(f"  d_qk={D_QK}  d_nope={D_NOPE}  d_rope={D_ROPE}  d_v={D_V}")
    print(f"  CUDA Device: {torch.cuda.get_device_name(0)}")
    print("=" * 64)

    # ── Test case definitions ──────────────────────────────────────────────
    test_cases = []

    # Basic correctness: various sizes
    for B in [1, 4]:
        for H in [16, 64, 128]:
            for (kv_tokens, topk, pg_size) in [
                (256, 32, 2),
                (512, 64, 64),
                (1024, 128, 4),
            ]:
                test_cases.append(dict(
                    B=B, H=H, total_kv_tokens=kv_tokens, topk=topk,
                    page_size=pg_size,
                    use_attn_sink=True, use_topk_len=True,
                ))

    # Extra KV cache tests
    for B in [1, 4]:
        test_cases.append(dict(
            B=B, H=64, total_kv_tokens=512, topk=64, page_size=4,
            extra_kv_tokens=512, extra_topk=64,
            use_attn_sink=True, use_topk_len=True,
        ))

    # Corner cases
    test_cases.append(dict(
        B=2, H=32, total_kv_tokens=256, topk=32, page_size=4,
        use_attn_sink=False, use_topk_len=False,
    ))

    test_cases.append(dict(
        B=8, H=16, total_kv_tokens=128, topk=16, page_size=2,
        use_attn_sink=True, use_topk_len=False,
    ))

    # Edge: single page, minimal tokens
    test_cases.append(dict(
        B=2, H=32, total_kv_tokens=1, topk=64, page_size=4,
        use_attn_sink=False, use_topk_len=False,
    ))

    # ── Run correctness tests ─────────────────────────────────────────────
    print(f"\nRunning {len(test_cases)} correctness tests...\n")
    failed = []
    for i, tc in enumerate(test_cases):
        print(f"[{i+1:3d}/{len(test_cases)}] ", end="", flush=True)
        try:
            ok = run_test(**tc, verbose=True)
        except Exception as e:
            print(f"  EXCEPTION: {e}")
            import traceback; traceback.print_exc()
            ok = False
        if not ok:
            failed.append(tc)

    print()
    n_pass = len(test_cases) - len(failed)
    if not failed:
        print(f"\033[32m\033[1mAll {len(test_cases)} correctness tests PASSED\033[0m")
    else:
        print(f"\033[31m\033[1m{len(failed)}/{len(test_cases)} tests FAILED\033[0m")
        for tc in failed:
            print(f"  B={tc['B']} H={tc['H']} topk={tc['topk']} "
                  f"extra={tc.get('extra_topk', None)}")

    # ── Production-scale benchmark (if all correctness passed) ────────────
    if not failed and n_pass > 0:
        print("\n" + "=" * 64)
        print("Production-scale benchmark")
        print("=" * 64)

        bench_cases = [
            # DSv4 typical config: 74 batches, 128 heads, topk=2048
            dict(B=74, H=128, total_kv_tokens=32768, topk=2048,
                 page_size=64, use_attn_sink=True, use_topk_len=False,
                 num_bench_runs=10),
            # DSv4 with extra cache
            dict(B=74, H=64, total_kv_tokens=16384, topk=128,
                 page_size=64, extra_kv_tokens=16384, extra_topk=512,
                 use_attn_sink=True, use_topk_len=False,
                 num_bench_runs=10),
        ]

        for i, tc in enumerate(bench_cases):
            print(f"\n  Bench [{i+1}/{len(bench_cases)}]: ", end="", flush=True)
            try:
                run_test(**tc, verbose=True)
            except Exception as e:
                print(f"EXCEPTION: {e}")

    # ── Summary ───────────────────────────────────────────────────────────
    print("\n" + "=" * 64)
    if failed:
        print(f"Result: {len(failed)} test(s) FAILED")
        sys.exit(1)
    else:
        print("Result: All tests PASSED")


if __name__ == "__main__":
    main()
