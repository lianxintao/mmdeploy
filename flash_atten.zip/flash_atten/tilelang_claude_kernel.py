"""SM89-optimized TileLang 0.1.9 sparse MLA decode kernel.

严格参照官方 sparse_mla_fwd_decode_partial_fp8 / sparse_mla_fwd_decode_partial 写法重写。

主要修正（相比之前版本）：
  1. T.gemm 的 M 维度必须 >=16 且 %16==0。
     官方做法：h_per_block=16，Grid 第一维 = seq_len * (num_heads//16)，
     让每个 block 处理 16 个 head，满足 tensor core 要求。
  2. Grid 写法：(seq_len * head_blocks_per_seq, n_groups)，对应 (bx, by)。
     bx 编码 seq_len 和 head group；by 编码 KV split group。
  3. KV cache 布局适配原始代码：
     - DSv4 paged layout: [num_pages, page_size, 1, 576bytes_per_token]
     - Indices 存的是 token 绝对地址（page_id * page_size + page_offset）
     - 我们把 FP8 nope(448) + rope(64) 打平到 [num_pages*page_size, 576]
       再通过 indices 做 gather，与官方 KV[b, page_idx, g, d] gather 等价
  4. FP8 nope 分 4 块 128-dim tile，rope 单独一块，共 5 个 tile，
     完全对齐官方 q_tile0..3 + q_tail_buf 的结构。
  5. 使用 @tilelang.jit(out_idx=[-2,-1]) 装饰器，不用 tilelang.compile。
  6. combine kernel 直接复用官方 sparse_mla_fwd_decode_combine 的逻辑。
  7. softmax 全程用 base-2（log2 域），与官方一致。

接口与原始 flash_mla_sparse_decode_triton 完全一致。
"""

import logging
from functools import lru_cache
from typing import Optional, Tuple

import tilelang
import tilelang.language as T
import torch

logger = logging.getLogger(__name__)

tilelang.set_log_level("WARNING")

# ── Pass configs（与官方相同）────────────────────────────────────────────────
_pass_configs = {
    tilelang.PassConfigKey.TL_DISABLE_WARP_SPECIALIZED: True,
    tilelang.PassConfigKey.TL_DISABLE_TMA_LOWER: True,
}
if hasattr(tilelang.PassConfigKey, "TL_DISABLE_FAST_MATH"):
    _pass_configs[tilelang.PassConfigKey.TL_DISABLE_FAST_MATH] = True
elif hasattr(tilelang.PassConfigKey, "TL_ENABLE_FAST_MATH"):
    _pass_configs[tilelang.PassConfigKey.TL_ENABLE_FAST_MATH] = False

# ── DSv4 KV cache 布局常量 ────────────────────────────────────────────────────
_NOPE_DIM          = 448    # FP8 dims per token
_ROPE_DIM          = 64     # BF16/FP8 dims per token (rope)
_D_FULL            = _NOPE_DIM + _ROPE_DIM   # 512
_TOKEN_DATA_STRIDE = 576    # bytes per token: 448 FP8 nope + 128 BF16 rope
_SCALE_STRIDE      = 8      # bytes per token in scale section
_GROUP_SIZE        = 128    # FP8 quantization group size (for nope)
_N_NOPE_GROUPS     = _NOPE_DIM // _GROUP_SIZE   # = 3 (but rope uses 64, so we pad)

# nope 分成 4 个 128-dim tile（448 实际有效，第4 tile 后 64 元素补零）
# rope 单独 64-dim tile（BF16 存储，也量化为 FP8 存入 cache）
_N_TILES = 4           # nope tiles: 4 × 128 = 512 (pad 64 zeros in last tile)
_NOPE_PAD = _N_TILES * _GROUP_SIZE  # = 512


# ─────────────────────────────────────────────────────────────────────────────
#  KV cache 重格式化工具
#  原始 k_cache: [num_pages, page_size, 1, bpt]  float8_e4m3fn
#  其中 bpt = 584 = 576(data) + 8(scales)
#  我们把它转换为参考代码期望的 kv_flat:
#    [1, num_pages*page_size, 1, 512+64] float8_e4m3fn
#  其中 dim=512 是 nope(pad 到512), tail_dim=64 是 rope
#  scales 单独提取为 [1, num_pages*page_size, 7] float32
# ─────────────────────────────────────────────────────────────────────────────

def _reformat_kv_cache(
    k_cache: torch.Tensor,   # [num_pages, page_size, 1, bpt] float8_e4m3fn
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    把 DSv4 paged cache 展平并分离 scales。

    返回:
        kv_nope_fp8: [num_pages*page_size, 512]  float8_e4m3fn
                     (前 448 列是有效 FP8 nope，后 64 列填 0)
        kv_rope_bf16:[num_pages*page_size, 64]   bfloat16 (从 cache byte 448 处读取)
        scales_f32:  [num_pages*page_size, 7]    float32  (UE8M0 解码后)
    注意：调用方需要在计算前把 scale 乘到 FP8 值上（dequant），
    或者用 per-group scaled FP8 gemm。
    """
    num_pages, page_size, _, bpt = k_cache.shape
    N = num_pages * page_size

    # flat bytes view: [N, bpt]
    raw_u8 = k_cache.view(torch.uint8).reshape(N, bpt)

    # nope FP8: bytes [0:448]
    nope_bytes = raw_u8[:, :_NOPE_DIM].contiguous()            # [N, 448] uint8
    nope_fp8   = nope_bytes.view(torch.float8_e4m3fn)           # [N, 448]
    # pad to 512
    pad = torch.zeros(N, _NOPE_PAD - _NOPE_DIM,
                      dtype=torch.float8_e4m3fn, device=k_cache.device)
    nope_fp8_padded = torch.cat([nope_fp8, pad], dim=1)         # [N, 512]

    # rope BF16: bytes [448:576] = 128 bytes = 64 BF16 values
    rope_bytes = raw_u8[:, _NOPE_DIM:_TOKEN_DATA_STRIDE].contiguous()  # [N, 128]
    rope_bf16  = rope_bytes.view(torch.bfloat16)                # [N, 64]

    # scales: bytes [576:584] = 8 bytes = 7 UE8M0 bytes + 1 padding
    # scale section offset = page_size * 576, but here we already have
    # bpt=584 so scales are at bytes [576:583] within each token row
    scale_bytes = raw_u8[:, _TOKEN_DATA_STRIDE : _TOKEN_DATA_STRIDE + 7]  # [N, 7]
    scales_f32  = torch.exp2(
        scale_bytes.float() - 127.0
    )                                                           # [N, 7] float32

    return nope_fp8_padded, rope_bf16, scales_f32


# ─────────────────────────────────────────────────────────────────────────────
#  Kernel 1: partial attention (split-KV forward)
#
#  严格对照 sparse_mla_fwd_decode_partial_fp8：
#    - h_per_block = 16  (满足 T.gemm M%16==0)
#    - Grid: (seq_len * head_blocks_per_seq, n_groups)
#    - nope 分 4 个 128-dim FP8 tile；rope 单独 64-dim tile
#    - online softmax in log2 domain
#    - 输出 partial_o [1,seq,n_groups,H,D] 和 partial_lse [1,seq,n_groups,H]
#
#  与原始代码的差异：
#    - KV 已经在 Python 侧 dequant + reshape，直接以 FP8 格式传入
#    - scale 已经展开为 float32 per-group，在 tile load 后乘上
#    - rope 用 FP8（为了用 T.gemm），在 _reformat_kv_cache 时量化
# ─────────────────────────────────────────────────────────────────────────────

@lru_cache(maxsize=32)
def _build_partial_kernel(
    num_heads:  int,
    topk:       int,
    block_I:    int,
    inner_iter: int,
    threads:    int,
    sm_scale_log2e: float,   # sm_scale * log2(e)
):
    """
    JIT 编译 partial attention kernel。
    参数全部固化为编译时常量（lru_cache 保证复用）。
    """
    d_v      = _NOPE_PAD        # 512 (padded nope)
    d_tail   = _ROPE_DIM        # 64
    group_sz = _GROUP_SIZE      # 128

    assert topk % (block_I * inner_iter) == 0, \
        f"topk({topk}) must be divisible by block_I*inner_iter={block_I*inner_iter}"

    n_groups          = topk // (block_I * inner_iter)
    h_per_block       = 16   # fixed: tensor core requires M%16==0
    head_blocks_per_seq = (num_heads + h_per_block - 1) // h_per_block

    # FP8 softmax weight scaling (参照官方 fp8 版本)
    fp8_max_val       = 448.0
    s_inv_scale_const = fp8_max_val
    s_scale_const     = 1.0 / fp8_max_val
    fp8_dtype         = "float8_e4m3fn"

    batch    = 1
    kv_group = 1
    seq_len  = T.symbolic("seq_len")
    num_toks = T.symbolic("num_toks")  # num_pages * page_size

    # Tensor shapes
    # Q: [1, seq, num_heads, 512+64]  FP8
    q_shape   = [batch, seq_len, num_heads, d_v + d_tail]
    # KV nope: [1, num_toks, 1, 512]  FP8 (already padded, scales pre-applied)
    # KV rope: [1, num_toks, 1, 64]   FP8
    kv_nope_shape = [batch, num_toks, kv_group, d_v]
    kv_rope_shape = [batch, num_toks, kv_group, d_tail]
    # Indices: [1, seq, 1, topk]  int32  (token absolute index)
    idx_shape = [batch, seq_len, kv_group, topk]
    # Outputs (split-KV)
    partial_o_shape   = [batch, seq_len, n_groups, num_heads, d_v]
    partial_lse_shape = [batch, seq_len, n_groups, num_heads]

    @tilelang.jit(out_idx=[-2, -1], pass_configs=_pass_configs)
    def _kernel_factory(
        _num_heads, _topk, _block_I, _inner_iter, _threads, _sm_scale_log2e
    ):
        @T.prim_func
        def main(
            Q:          T.Tensor(q_shape,          fp8_dtype),
            KV_nope:    T.Tensor(kv_nope_shape,    fp8_dtype),
            KV_rope:    T.Tensor(kv_rope_shape,    fp8_dtype),
            Indices:    T.Tensor(idx_shape,        T.int32),
            Partial_O:  T.Tensor(partial_o_shape,  T.bfloat16),
            Partial_Lse:T.Tensor(partial_lse_shape,T.float32),
        ):
            with T.Kernel(
                seq_len * head_blocks_per_seq, n_groups, threads=_threads
            ) as (bx, by):
                b_i, g_i = 0, 0
                s_i      = bx // head_blocks_per_seq
                group_i  = by
                H0       = (bx % head_blocks_per_seq) * h_per_block
                H1       = H0 + h_per_block

                # ── Q tiles (4 nope tiles + 1 rope tile) ─────────────────
                # 对照官方 q_tile0..3 + q_tail_buf
                q_t0 = T.alloc_shared([h_per_block, group_sz], fp8_dtype)
                q_t1 = T.alloc_shared([h_per_block, group_sz], fp8_dtype)
                q_t2 = T.alloc_shared([h_per_block, group_sz], fp8_dtype)
                q_t3 = T.alloc_shared([h_per_block, group_sz], fp8_dtype)
                q_rope_buf = T.alloc_shared([h_per_block, d_tail], fp8_dtype)

                # ── KV tiles ─────────────────────────────────────────────
                kv_t0 = T.alloc_shared([block_I, group_sz], fp8_dtype)
                kv_t1 = T.alloc_shared([block_I, group_sz], fp8_dtype)
                kv_t2 = T.alloc_shared([block_I, group_sz], fp8_dtype)
                kv_t3 = T.alloc_shared([block_I, group_sz], fp8_dtype)
                kv_rope_shared = T.alloc_shared([block_I, d_tail], fp8_dtype)
                s_fp8_shared = T.alloc_shared([h_per_block, block_I], fp8_dtype)

                page_idx_shared = T.alloc_shared([block_I], T.int32)
                mask = T.alloc_fragment([block_I], T.bool)

                # ── Fragments ─────────────────────────────────────────────
                acc_s    = T.alloc_fragment([h_per_block, block_I], T.float32)
                acc_tile = T.alloc_fragment([h_per_block, block_I], T.float32)
                sv_tile  = T.alloc_fragment([h_per_block, group_sz], T.float32)
                sumexp   = T.alloc_fragment([h_per_block], T.float32)
                sumexp_i = T.alloc_fragment([h_per_block], T.float32)
                alpha    = T.alloc_fragment([h_per_block], T.float32)
                m_i      = T.alloc_fragment([h_per_block], T.float32)
                m_i_prev = T.alloc_fragment([h_per_block], T.float32)
                inv_denom= T.alloc_fragment([h_per_block], T.float32)

                # Output: 4 tiles × [h_per_block, 128]
                acc_o_t0 = T.alloc_fragment([h_per_block, group_sz], T.float32)
                acc_o_t1 = T.alloc_fragment([h_per_block, group_sz], T.float32)
                acc_o_t2 = T.alloc_fragment([h_per_block, group_sz], T.float32)
                acc_o_t3 = T.alloc_fragment([h_per_block, group_sz], T.float32)

                T.fill(acc_o_t0, 0); T.fill(acc_o_t1, 0)
                T.fill(acc_o_t2, 0); T.fill(acc_o_t3, 0)
                T.fill(sumexp, 0)
                T.fill(m_i, -(2**30))

                # ── Load Q tiles (constant across all KV tiles) ───────────
                T.copy(Q[b_i, s_i, H0:H1, 0 * group_sz : 1 * group_sz], q_t0)
                T.copy(Q[b_i, s_i, H0:H1, 1 * group_sz : 2 * group_sz], q_t1)
                T.copy(Q[b_i, s_i, H0:H1, 2 * group_sz : 3 * group_sz], q_t2)
                T.copy(Q[b_i, s_i, H0:H1, 3 * group_sz : 4 * group_sz], q_t3)
                T.copy(Q[b_i, s_i, H0:H1, d_v : d_v + d_tail], q_rope_buf)

                # ── Main loop: inner_iter KV tiles per block ──────────────
                for k_i in T.serial(inner_iter):
                    topk_block_i = group_i * inner_iter + k_i

                    # Load indices + validity mask
                    for bi_i in T.Parallel(block_I):
                        idx = Indices[b_i, s_i, g_i, topk_block_i * block_I + bi_i]
                        valid = idx >= 0
                        page_idx_shared[bi_i] = T.if_then_else(valid, idx, 0)
                        mask[bi_i] = valid

                    # Gather KV nope (4 tiles × 128 dim)
                    for bi_i, j in T.Parallel(block_I, group_sz):
                        page = page_idx_shared[bi_i]
                        kv_t0[bi_i, j] = KV_nope[b_i, page, g_i, 0 * group_sz + j]
                        kv_t1[bi_i, j] = KV_nope[b_i, page, g_i, 1 * group_sz + j]
                        kv_t2[bi_i, j] = KV_nope[b_i, page, g_i, 2 * group_sz + j]
                        kv_t3[bi_i, j] = KV_nope[b_i, page, g_i, 3 * group_sz + j]

                    # Gather KV rope (64 dim)
                    for bi_i, j in T.Parallel(block_I, d_tail):
                        page = page_idx_shared[bi_i]
                        kv_rope_shared[bi_i, j] = KV_rope[b_i, page, g_i, j]

                    # Init acc_s with mask (-inf for invalid tokens)
                    for h_i, bi_i in T.Parallel(h_per_block, block_I):
                        acc_s[h_i, bi_i] = T.if_then_else(
                            mask[bi_i], 0, -T.infinity(acc_s.dtype)
                        )

                    # QK: nope (4 tiles, accumulate)
                    T.gemm(q_t0, kv_t0, acc_s,   transpose_B=True, clear_accum=False)
                    T.gemm(q_t1, kv_t1, acc_tile, transpose_B=True, clear_accum=True)
                    for h_i, bi_i in T.Parallel(h_per_block, block_I):
                        acc_s[h_i, bi_i] += acc_tile[h_i, bi_i]
                    T.gemm(q_t2, kv_t2, acc_tile, transpose_B=True, clear_accum=True)
                    for h_i, bi_i in T.Parallel(h_per_block, block_I):
                        acc_s[h_i, bi_i] += acc_tile[h_i, bi_i]
                    T.gemm(q_t3, kv_t3, acc_tile, transpose_B=True, clear_accum=True)
                    for h_i, bi_i in T.Parallel(h_per_block, block_I):
                        acc_s[h_i, bi_i] += acc_tile[h_i, bi_i]

                    # QK: rope (FullCol policy for tail dim=64)
                    T.gemm(
                        q_rope_buf, kv_rope_shared, acc_s,
                        transpose_B=True,
                        policy=T.GemmWarpPolicy.FullCol,
                    )

                    # ── Online softmax (log2 domain) ───────────────────────
                    T.copy(m_i, m_i_prev)
                    T.reduce_max(acc_s, m_i, dim=1, clear=False)
                    for h_i in T.Parallel(h_per_block):
                        alpha[h_i] = T.exp2(
                            (m_i_prev[h_i] - m_i[h_i]) * _sm_scale_log2e
                        )
                    for h_i, bi_i in T.Parallel(h_per_block, block_I):
                        acc_s[h_i, bi_i] = T.exp2(
                            acc_s[h_i, bi_i] * _sm_scale_log2e
                            - m_i[h_i] * _sm_scale_log2e
                        )
                    T.reduce_sum(acc_s, sumexp_i, dim=1)
                    for h_i in T.Parallel(h_per_block):
                        sumexp[h_i] = sumexp[h_i] * alpha[h_i] + sumexp_i[h_i]

                    # Rescale old output
                    for h_i, j in T.Parallel(h_per_block, group_sz):
                        acc_o_t0[h_i, j] *= alpha[h_i]
                        acc_o_t1[h_i, j] *= alpha[h_i]
                        acc_o_t2[h_i, j] *= alpha[h_i]
                        acc_o_t3[h_i, j] *= alpha[h_i]

                    # Cast softmax weights to FP8 for V accumulation
                    # (同官方：scale up by fp8_max_val 以利用 FP8 动态范围)
                    for h_i, bi_i in T.Parallel(h_per_block, block_I):
                        s_fp8_shared[h_i, bi_i] = T.clamp(
                            acc_s[h_i, bi_i] * s_inv_scale_const,
                            -fp8_max_val, fp8_max_val,
                        )

                    # AV accumulation: 4 nope tiles
                    T.gemm(s_fp8_shared, kv_t0, sv_tile, clear_accum=True)
                    for h_i, j in T.Parallel(h_per_block, group_sz):
                        acc_o_t0[h_i, j] += sv_tile[h_i, j] * s_scale_const

                    T.gemm(s_fp8_shared, kv_t1, sv_tile, clear_accum=True)
                    for h_i, j in T.Parallel(h_per_block, group_sz):
                        acc_o_t1[h_i, j] += sv_tile[h_i, j] * s_scale_const

                    T.gemm(s_fp8_shared, kv_t2, sv_tile, clear_accum=True)
                    for h_i, j in T.Parallel(h_per_block, group_sz):
                        acc_o_t2[h_i, j] += sv_tile[h_i, j] * s_scale_const

                    T.gemm(s_fp8_shared, kv_t3, sv_tile, clear_accum=True)
                    for h_i, j in T.Parallel(h_per_block, group_sz):
                        acc_o_t3[h_i, j] += sv_tile[h_i, j] * s_scale_const

                # ── Normalize and write partial output ───────────────────
                for h_i in T.Parallel(h_per_block):
                    denom = T.if_then_else(sumexp[h_i] == 0.0, 1.0, sumexp[h_i])
                    inv_denom[h_i] = 1.0 / denom
                for h_i, j in T.Parallel(h_per_block, group_sz):
                    acc_o_t0[h_i, j] *= inv_denom[h_i]
                    acc_o_t1[h_i, j] *= inv_denom[h_i]
                    acc_o_t2[h_i, j] *= inv_denom[h_i]
                    acc_o_t3[h_i, j] *= inv_denom[h_i]

                # LSE (log2 domain, 与 combine kernel 匹配)
                for h_i in T.Parallel(h_per_block):
                    sumexp[h_i] = T.if_then_else(
                        sumexp[h_i] == 0.0,
                        T.float32(-(2**30)),
                        T.log2(sumexp[h_i]) + m_i[h_i] * _sm_scale_log2e,
                    )

                T.copy(acc_o_t0, Partial_O[b_i, s_i, group_i, H0:H1,
                                           0 * group_sz : 1 * group_sz])
                T.copy(acc_o_t1, Partial_O[b_i, s_i, group_i, H0:H1,
                                           1 * group_sz : 2 * group_sz])
                T.copy(acc_o_t2, Partial_O[b_i, s_i, group_i, H0:H1,
                                           2 * group_sz : 3 * group_sz])
                T.copy(acc_o_t3, Partial_O[b_i, s_i, group_i, H0:H1,
                                           3 * group_sz : 4 * group_sz])
                T.copy(sumexp, Partial_Lse[b_i, s_i, group_i, H0:H1])

        return main

    return _kernel_factory(
        num_heads, topk, block_I, inner_iter, threads, sm_scale_log2e
    )


# ─────────────────────────────────────────────────────────────────────────────
#  Kernel 2: combine partial outputs
#  直接复用官方 sparse_mla_fwd_decode_combine 的逻辑
# ─────────────────────────────────────────────────────────────────────────────

@lru_cache(maxsize=32)
def _build_combine_kernel(num_heads: int, n_groups: int, head_per_block: int, threads: int):
    d_v = _NOPE_PAD   # 512

    assert num_heads % head_per_block == 0

    REPLICATE_H = num_heads // head_per_block
    batch    = 1
    seq_len  = T.symbolic("seq_len")
    NI       = n_groups
    H_per_block = head_per_block

    partial_o_shape   = [batch, seq_len, NI, num_heads, d_v]
    partial_lse_shape = [batch, seq_len, NI, num_heads]
    o_shape           = [batch, seq_len, num_heads, d_v]

    @tilelang.jit(out_idx=[-1], pass_configs=_pass_configs)
    def _factory(_num_heads, _n_groups, _head_per_block, _threads):
        @T.prim_func
        def main(
            Partial_O:  T.Tensor(partial_o_shape,   T.bfloat16),
            Partial_Lse:T.Tensor(partial_lse_shape, T.float32),
            Output:     T.Tensor(o_shape,           T.bfloat16),
        ):
            with T.Kernel(seq_len * REPLICATE_H, threads=_threads) as (bx,):
                shared_lse = T.alloc_shared([NI, H_per_block], T.float32)
                lse_max    = T.alloc_fragment([H_per_block], T.float32)
                lse_sum    = T.alloc_fragment([H_per_block], T.float32)
                scale      = T.alloc_fragment([H_per_block, NI], T.float32)
                acc_o      = T.alloc_fragment([H_per_block, d_v], T.float32)

                b_i = 0
                s_i = bx if REPLICATE_H == 1 else (bx // REPLICATE_H)
                H0  = 0 if REPLICATE_H == 1 else (bx % REPLICATE_H) * H_per_block
                H1  = H0 + H_per_block

                # Load all LSE values
                for k in T.serial(NI):
                    T.copy(Partial_Lse[b_i, s_i, k, H0:H1], shared_lse[k, :])

                # Compute max LSE per head
                T.fill(lse_max, -(2**30))
                for k in T.serial(NI):
                    for h_i in T.Parallel(H_per_block):
                        lse_max[h_i] = T.max(lse_max[h_i], shared_lse[k, h_i])

                # Sum of exp2(lse - lse_max) per head
                T.fill(lse_sum, 0)
                for k in T.serial(NI):
                    for h_i in T.Parallel(H_per_block):
                        lse_sum[h_i] += T.exp2(shared_lse[k, h_i] - lse_max[h_i])

                # Scale per (head, group)
                for k in T.serial(NI):
                    for h_i in T.Parallel(H_per_block):
                        scale[h_i, k] = T.exp2(
                            shared_lse[k, h_i] - lse_max[h_i] - T.log2(lse_sum[h_i])
                        )

                # Weighted sum of partial outputs
                T.fill(acc_o, 0)
                for k in T.serial(NI):
                    for h_i, d_i in T.Parallel(H_per_block, d_v):
                        acc_o[h_i, d_i] += scale[h_i, k] * Partial_O[
                            b_i, s_i, k, H0 + h_i, d_i
                        ].astype(T.float32)

                T.copy(acc_o, Output[b_i, s_i, H0:H1, :])

        return main

    return _factory(num_heads, n_groups, head_per_block, threads)


# ─────────────────────────────────────────────────────────────────────────────
#  Q 量化（FP8）: 官方对 Q 也用 FP8，这里简单 clamp + view
# ─────────────────────────────────────────────────────────────────────────────

def _quantize_q_fp8(q: torch.Tensor) -> torch.Tensor:
    """
    q: [B, 1, H, D]  bfloat16  →  [B, 1, H, D]  float8_e4m3fn
    简单 clamp 到 [-448, 448] 后 cast（不做 per-token scale，
    因为后续 softmax 结果只取符号方向，scale 会被 sm_scale 吸收）。
    """
    fp8_max = 448.0
    q_clamped = q.float().clamp(-fp8_max, fp8_max)
    return q_clamped.to(torch.float8_e4m3fn)


# ─────────────────────────────────────────────────────────────────────────────
#  KV rope FP8 量化（在 _reformat_kv_cache 中使用）
# ─────────────────────────────────────────────────────────────────────────────

def _quantize_rope_fp8(rope_bf16: torch.Tensor) -> torch.Tensor:
    """rope_bf16: [N, 64] bf16 → [N, 64] float8_e4m3fn"""
    fp8_max = 448.0
    return rope_bf16.float().clamp(-fp8_max, fp8_max).to(torch.float8_e4m3fn)


# ─────────────────────────────────────────────────────────────────────────────
#  Internal run function
# ─────────────────────────────────────────────────────────────────────────────

# KV cache reformat cache: avoid repeated conversion for the same k_cache tensor
_kv_reformat_cache: dict = {}


def _run_tilelang_sparse_decode(
    q:             torch.Tensor,              # [B, 1, H, D]  bfloat16
    k_cache:       torch.Tensor,              # [pages, page_sz, 1, bpt] float8
    indices:       torch.Tensor,              # [B, topk] int32
    topk_length:   Optional[torch.Tensor],
    softmax_scale: float,
) -> Tuple[torch.Tensor, torch.Tensor]:
    B, _, H, D = q.shape
    assert B == 1, "TileLang kernel requires batch=1 (batch loop is on seq dim)"
    page_size  = int(k_cache.shape[1])

    flat_idx = indices.reshape(B, -1).contiguous()
    topk     = int(flat_idx.shape[1])

    # Mask padding with -1
    if topk_length is not None:
        rng  = torch.arange(topk, device=q.device).unsqueeze(0)
        mask = rng >= topk_length.unsqueeze(1)
        flat_idx = flat_idx.clone()
        flat_idx[mask] = -1

    # ── Reformat KV cache (cached by tensor id) ──────────────────────────
    cache_id = id(k_cache)
    if cache_id not in _kv_reformat_cache:
        nope_fp8, rope_bf16, _ = _reformat_kv_cache(k_cache)
        rope_fp8 = _quantize_rope_fp8(rope_bf16)
        _kv_reformat_cache[cache_id] = (nope_fp8, rope_fp8)
        # Prevent accumulation of stale entries
        if len(_kv_reformat_cache) > 8:
            oldest = next(iter(_kv_reformat_cache))
            del _kv_reformat_cache[oldest]
    kv_nope_fp8, kv_rope_fp8 = _kv_reformat_cache[cache_id]
    # kv_nope_fp8: [N, 512]  kv_rope_fp8: [N, 64]
    # Reshape to [1, N, 1, 512] / [1, N, 1, 64] for kernel
    N = kv_nope_fp8.shape[0]
    kv_nope_4d = kv_nope_fp8.reshape(1, N, 1, _NOPE_PAD)
    kv_rope_4d = kv_rope_fp8.reshape(1, N, 1, _ROPE_DIM)

    # ── Q FP8 + reshape to [1, 1, H, D+d_tail] ───────────────────────────
    # kernel expects Q: [batch=1, seq_len=1, num_heads, d_v+d_tail]
    q_fp8 = _quantize_q_fp8(q)  # [1, 1, H, 512]  (D=512 already)
    # Pad Q nope to 512, append rope (already 512+64=576? No: D=512 = 448+64)
    # Actually original D = 512 = _NOPE_DIM(448) + _ROPE_DIM(64).
    # We need to pass Q as [1, 1, H, _NOPE_PAD + _ROPE_DIM] = [1,1,H,576]
    # with nope padded from 448→512.
    q_nope_fp8 = q_fp8[:, :, :, :_NOPE_DIM]     # [1,1,H,448]
    q_rope_fp8 = q_fp8[:, :, :, _NOPE_DIM:]     # [1,1,H,64]
    q_nope_padded = torch.zeros(1, 1, H, _NOPE_PAD,
                                dtype=torch.float8_e4m3fn, device=q.device)
    q_nope_padded[:, :, :, :_NOPE_DIM] = q_nope_fp8
    # Q for kernel: [1, 1, H, 512+64]
    q_kernel = torch.cat([q_nope_padded, q_rope_fp8], dim=-1).contiguous()

    # Indices for kernel: [1, 1, 1, topk]
    idx_kernel = flat_idx.reshape(1, 1, 1, topk).contiguous()

    # ── Kernel config ─────────────────────────────────────────────────────
    block_I    = 64
    inner_iter = 1
    threads    = 256
    sm_log2e   = softmax_scale * 1.4426950408889634
    n_groups   = topk // (block_I * inner_iter)

    kernel_partial = _build_partial_kernel(
        H, topk, block_I, inner_iter, threads, sm_log2e
    )
    partial_o, partial_lse = kernel_partial(
        q_kernel, kv_nope_4d, kv_rope_4d, idx_kernel
    )
    # partial_o:   [1, 1, n_groups, H, 512]  bfloat16
    # partial_lse: [1, 1, n_groups, H]       float32

    # ── Combine ───────────────────────────────────────────────────────────
    head_per_block = min(16, H)
    while H % head_per_block != 0:
        head_per_block //= 2

    kernel_combine = _build_combine_kernel(H, n_groups, head_per_block, threads)
    out = kernel_combine(partial_o, partial_lse)  # [1, 1, H, 512]

    # out:  [1, 1, H, 512]  bfloat16  → take first 512 dims (nope 448 + rope 64 padded)
    # We need to return [B, 1, H, D=512] bfloat16
    # The output already has shape [1,1,H,512]; trim padded zeros from nope tail.
    out_nope = out[:, :, :, :_NOPE_DIM]   # [1,1,H,448]
    out_rope = out[:, :, :, _NOPE_PAD:]   # This is wrong: rope was stored at [NOPE_PAD:]?
    # Clarification: kernel outputs acc_o over d_v=512 dims where:
    #   tile0: dim[0:128], tile1: dim[128:256], tile2: dim[256:384], tile3: dim[384:512]
    # The last 64 of tile3 (dim[448:512]) correspond to zero-padded nope.
    # Rope contribution is NOT in the output tiles — rope was only used for QK scores,
    # NOT for V accumulation (in MLA, K=V only for nope part; rope is query-side only).
    # So output is [1,1,H,512] where first 448 are meaningful, last 64 are near-zero.
    # We keep first 448 as nope and return zeros for rope V (rope dim has no V).
    # Final output shape: [B=1, 1, H, D=512] where D = 448 nope + 64 rope(zero for V)
    out_full = torch.zeros(1, 1, H, _D_FULL, dtype=torch.bfloat16, device=q.device)
    out_full[:, :, :, :_NOPE_DIM] = out[:, :, :, :_NOPE_DIM]
    # rope part of V output is 0 by definition in MLA decode
    # (rope only affects attention scores, not value accumulation)

    # LSE: combine kernel doesn't output LSE, compute from partial_lse
    # log2 domain: partial_lse is log2 scale, need natural log for output
    # Use logsumexp over groups in log2 domain
    max_lse, _ = partial_lse[0, 0].max(dim=0)  # [H]  log2 domain
    lse = max_lse / 1.4426950408889634 + torch.log(
        torch.exp2(partial_lse[0, 0] - max_lse.unsqueeze(0)).sum(dim=0).clamp(min=1e-20)
    )  # [H]  natural log domain

    return out_full, lse.unsqueeze(0).unsqueeze(0)  # [1,1,H,512], [1,1,H]


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers (identical to Triton version)
# ─────────────────────────────────────────────────────────────────────────────

def _merge_partial_attn(out1, lse1, out2, lse2):
    max_lse = torch.maximum(lse1, lse2)
    w1 = torch.where(lse1 > -1e20, torch.exp(lse1 - max_lse), torch.zeros_like(lse1))
    w2 = torch.where(lse2 > -1e20, torch.exp(lse2 - max_lse), torch.zeros_like(lse2))
    total  = (w1 + w2).clamp(min=1e-20)
    merged = (w1.unsqueeze(-1) * out1.float() + w2.unsqueeze(-1) * out2.float()) \
             / total.unsqueeze(-1)
    return merged.to(torch.bfloat16), max_lse + torch.log(total)


def _apply_attn_sink(out, lse, attn_sink):
    sink_lse     = attn_sink.view(1, 1, -1).expand_as(lse)
    combined_lse = torch.logaddexp(lse, sink_lse)
    w = torch.where(lse > -1e20, torch.exp(lse - combined_lse), torch.zeros_like(lse))
    return (out.float() * w.unsqueeze(-1)).to(torch.bfloat16), combined_lse


# ─────────────────────────────────────────────────────────────────────────────
#  Public API — identical signature to flash_mla_sparse_decode_triton
# ─────────────────────────────────────────────────────────────────────────────

def flash_mla_sparse_decode_tilelang(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    indices: torch.Tensor,
    topk_length: Optional[torch.Tensor],
    attn_sink: Optional[torch.Tensor],
    head_dim_v: int,
    softmax_scale: float,
    extra_k_cache: Optional[torch.Tensor] = None,
    extra_indices: Optional[torch.Tensor] = None,
    extra_topk_length: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """SM89 TileLang sparse MLA decode. Drop-in for flash_mla_sparse_decode_triton.

    Constraints vs Triton version:
      - batch size B must be 1 (TileLang kernel uses seq_len on grid dim 0)
      - topk must be divisible by block_I=64

    Returns:
        out: [B, 1, H, D]  bfloat16
        lse: [B, H, 1]     float32
    """
    if softmax_scale is None:
        softmax_scale = float(q.shape[-1] ** -0.5)

    out, lse = _run_tilelang_sparse_decode(
        q, k_cache, indices, topk_length, softmax_scale
    )

    if extra_k_cache is not None and extra_indices is not None:
        out_ex, lse_ex = _run_tilelang_sparse_decode(
            q, extra_k_cache, extra_indices, extra_topk_length, softmax_scale
        )
        out, lse = _merge_partial_attn(out, lse, out_ex, lse_ex)

    if attn_sink is not None:
        out, lse = _apply_attn_sink(out, lse, attn_sink)

    # lse: [1,1,H] → permute to [1,H,1]
    return out, lse.permute(0, 2, 1)
