"""
SM89-compatible FlashMLA decode backend.

This module mirrors the public C++ extension entry points used by
flash_mla_with_kvcache:

    dense_decode_fwd(...)
    sparse_decode_fwd(...)

The original SM90 kernels depend on Hopper-only TMA/WGMMA features. SM89 cannot
execute those kernels, so this backend keeps the same tensor contract and
reproduces the scheduler, split-KV, combine, dense decode, and sparse FP8 decode
semantics with PyTorch operations. TileLang is imported lazily when available so
the module can host TileLang kernels without changing the external interface.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import torch


BLOCK_M = 64
BLOCK_N = 64
FIXED_OVERHEAD_NUM_BLOCKS = 5


@dataclass(frozen=True)
class _SchedMeta:
    begin_req_idx: int
    end_req_idx: int
    begin_block_idx: int
    end_block_idx: int
    begin_split_idx: int
    is_first_req_splitted: int
    is_last_req_splitted: int

    def to_list(self) -> list[int]:
        return [
            self.begin_req_idx,
            self.end_req_idx,
            self.begin_block_idx,
            self.end_block_idx,
            self.begin_split_idx,
            self.is_first_req_splitted,
            self.is_last_req_splitted,
            0,
        ]


def _ceil_div(a: int, b: int) -> int:
    return (a + b - 1) // b


def _maybe_import_tilelang():
    try:
        import tilelang  # type: ignore
        import tilelang.language as T  # type: ignore
    except Exception:
        return None, None
    return tilelang, T


def _sm89_num_sms(device: torch.device) -> int:
    props = torch.cuda.get_device_properties(device)
    return int(props.multi_processor_count)


def _get_num_sm_parts_dense(b: int, s_q: int, h_q: int, h_k: int, device: torch.device) -> int:
    num_sms = _sm89_num_sms(device) if device.type == "cuda" else 1
    num_m_blocks = _ceil_div(s_q * (h_q // h_k), BLOCK_M)
    return max(num_sms // h_k // max(num_m_blocks, 1), 1)


def _get_num_sm_parts_sparse(b: int, s_q: int, h_q: int, device: torch.device) -> int:
    num_sms = _sm89_num_sms(device) if device.type == "cuda" else 1
    return max(num_sms // s_q // max(h_q // BLOCK_M, 1), 1)


def _build_decode_sched_meta(
    *,
    b: int,
    block_size_n: int,
    fixed_overhead_num_blocks: int,
    num_sm_parts: int,
    seqlens_k: Optional[torch.Tensor],
    topk: int = -1,
    extra_topk: int = -1,
    topk_length: Optional[torch.Tensor] = None,
    extra_topk_length: Optional[torch.Tensor] = None,
    device: torch.device,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Python reproduction of get_mla_metadata_kernel.

    Returns:
        tile_scheduler_metadata: [num_sm_parts, 8], int32
        num_splits: [b + 1], int32
    """
    num_blocks_per_req: list[int] = []
    seqlens_or_topk: list[int] = []
    first_block_idx: list[int] = []
    last_block_idx: list[int] = []

    topk_len_cpu = topk_length.detach().cpu() if topk_length is not None else None
    extra_topk_len_cpu = extra_topk_length.detach().cpu() if extra_topk_length is not None else None
    seqlens_cpu = seqlens_k.detach().cpu() if seqlens_k is not None else None

    total_num_blocks = 0
    for i in range(b):
        if topk == -1:
            assert seqlens_cpu is not None
            cur_s_k = int(seqlens_cpu[i].item())
        else:
            cur_s_k = int(topk_len_cpu[i].item()) if topk_len_cpu is not None else topk
            if cur_s_k == 0:
                cur_s_k = 1
            if extra_topk and extra_topk > 0:
                cur_s_k = _ceil_div(cur_s_k, block_size_n) * block_size_n
                cur_s_k += int(extra_topk_len_cpu[i].item()) if extra_topk_len_cpu is not None else extra_topk

        first = 0
        last_token = max(cur_s_k - 1, 0)
        last = last_token // block_size_n
        num_blocks = last - first + 1

        seqlens_or_topk.append(cur_s_k)
        first_block_idx.append(first)
        last_block_idx.append(last)
        num_blocks_per_req.append(num_blocks)
        total_num_blocks += num_blocks + fixed_overhead_num_blocks

    payload = _ceil_div(total_num_blocks, num_sm_parts) + fixed_overhead_num_blocks
    metas: list[_SchedMeta] = []
    num_splits = [0] * (b + 1)
    now_req_idx = 0
    now_block = 0
    now_n_split_idx = 0
    cum_num_splits = 0

    for _ in range(num_sm_parts):
        if now_req_idx >= b:
            metas.append(_SchedMeta(b, b - 1, 0, 0, 0, 0, 0))
            continue

        begin_req_idx = now_req_idx
        begin_block_idx = now_block + first_block_idx[now_req_idx]
        begin_split_idx = now_n_split_idx
        is_first_req_splitted = int(now_block != 0)
        remain_payload = payload

        while now_req_idx < b:
            num_blocks = num_blocks_per_req[now_req_idx]
            now_remain_blocks = num_blocks - now_block
            if remain_payload >= now_remain_blocks + fixed_overhead_num_blocks:
                cum_num_splits += now_n_split_idx + 1
                num_splits[now_req_idx + 1] = cum_num_splits
                remain_payload -= now_remain_blocks + fixed_overhead_num_blocks
                now_req_idx += 1
                now_block = 0
                now_n_split_idx = 0
            else:
                if remain_payload - fixed_overhead_num_blocks > 0:
                    now_block += remain_payload - fixed_overhead_num_blocks
                    now_n_split_idx += 1
                break

        if now_block > 0:
            end_req_idx = now_req_idx
            end_block_idx = now_block + first_block_idx[now_req_idx]
        else:
            end_req_idx = now_req_idx - 1
            end_block_idx = 0 if seqlens_or_topk[end_req_idx] == 0 else last_block_idx[end_req_idx] + 1

        is_last_req_splitted = int(
            end_block_idx != last_block_idx[end_req_idx] + 1 and seqlens_or_topk[end_req_idx] != 0
        )
        if begin_req_idx == end_req_idx:
            both = int(is_first_req_splitted or is_last_req_splitted)
            is_first_req_splitted = both
            is_last_req_splitted = both

        metas.append(
            _SchedMeta(
                begin_req_idx,
                end_req_idx,
                begin_block_idx,
                end_block_idx,
                begin_split_idx,
                is_first_req_splitted,
                is_last_req_splitted,
            )
        )

    meta_tensor = torch.tensor([m.to_list() for m in metas], dtype=torch.int32, device=device)
    split_tensor = torch.tensor(num_splits, dtype=torch.int32, device=device)
    return meta_tensor, split_tensor


def _ensure_sched_meta_dense(
    q: torch.Tensor,
    cache_seqlens: torch.Tensor,
    num_heads_k: int,
    tile_scheduler_metadata: Optional[torch.Tensor],
    num_splits: Optional[torch.Tensor],
) -> Tuple[torch.Tensor, torch.Tensor]:
    b, s_q, h_q, _ = q.shape
    num_sm_parts = _get_num_sm_parts_dense(b, s_q, h_q, num_heads_k, q.device)
    expected_meta_shape = (num_sm_parts, 8)
    expected_splits_shape = (b + 1,)
    if tile_scheduler_metadata is not None and num_splits is not None:
        if tuple(tile_scheduler_metadata.shape) == expected_meta_shape and tuple(num_splits.shape) == expected_splits_shape:
            return tile_scheduler_metadata, num_splits
    return _build_decode_sched_meta(
        b=b,
        block_size_n=BLOCK_N,
        fixed_overhead_num_blocks=FIXED_OVERHEAD_NUM_BLOCKS,
        num_sm_parts=num_sm_parts,
        seqlens_k=cache_seqlens,
        device=q.device,
    )


def _ensure_sched_meta_sparse(
    q: torch.Tensor,
    topk: int,
    extra_topk: int,
    topk_length: Optional[torch.Tensor],
    extra_topk_length: Optional[torch.Tensor],
    tile_scheduler_metadata: Optional[torch.Tensor],
    num_splits: Optional[torch.Tensor],
) -> Tuple[torch.Tensor, torch.Tensor]:
    b, s_q, h_q, _ = q.shape
    num_sm_parts = _get_num_sm_parts_sparse(b, s_q, h_q, q.device)
    expected_meta_shape = (num_sm_parts, 8)
    expected_splits_shape = (b + 1,)
    if tile_scheduler_metadata is not None and num_splits is not None:
        if tuple(tile_scheduler_metadata.shape) == expected_meta_shape and tuple(num_splits.shape) == expected_splits_shape:
            return tile_scheduler_metadata, num_splits
    return _build_decode_sched_meta(
        b=b,
        block_size_n=BLOCK_N,
        fixed_overhead_num_blocks=FIXED_OVERHEAD_NUM_BLOCKS,
        num_sm_parts=num_sm_parts,
        seqlens_k=None,
        topk=topk,
        extra_topk=extra_topk,
        topk_length=topk_length,
        extra_topk_length=extra_topk_length,
        device=q.device,
    )


def combine_split_partials(
    lse_accum: torch.Tensor,
    o_accum: torch.Tensor,
    num_splits: torch.Tensor,
    *,
    b: int,
    s_q: int,
    h_q: int,
    d_v: int,
    attn_sink: Optional[torch.Tensor] = None,
    out_dtype: torch.dtype = torch.bfloat16,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Functional equivalent of smxx::decode::run_flash_mla_combine_kernel.

    Args:
        lse_accum: [num_splits_total, s_q, h_q], log2-domain local lse.
        o_accum: [num_splits_total, s_q, h_q, d_v], local normalized output.
        num_splits: [b + 1], prefix sum of split counts per request.

    Returns:
        out: [b, s_q, h_q, d_v]
        lse: [b, s_q, h_q], natural-log lse without attn_sink contribution.
    """
    out = torch.empty((b, s_q, h_q, d_v), dtype=out_dtype, device=o_accum.device)
    lse = torch.empty((b, s_q, h_q), dtype=torch.float32, device=o_accum.device)

    log2e = torch.tensor(1.4426950408889634, dtype=torch.float32, device=o_accum.device)
    for batch_idx in range(b):
        start = int(num_splits[batch_idx].item())
        end = int(num_splits[batch_idx + 1].item())
        local_lse = lse_accum[start:end]
        local_o = o_accum[start:end]
        max_lse = torch.max(local_lse, dim=0).values
        sum_lse = torch.sum(torch.exp2(local_lse - max_lse.unsqueeze(0)), dim=0)
        global_lse_log2 = torch.log2(sum_lse) + max_lse
        global_lse_log2 = torch.where(
            torch.isfinite(max_lse),
            global_lse_log2,
            torch.full_like(global_lse_log2, float("+inf")),
        )
        scale_lse_log2 = global_lse_log2

        lse[batch_idx] = global_lse_log2 / log2e
        if attn_sink is not None:
            sink_log2 = attn_sink.view(1, h_q) * log2e
            scale_lse_log2 = torch.log2(1.0 + torch.exp2(sink_log2 - global_lse_log2)) + global_lse_log2

        weights = torch.exp2(local_lse - scale_lse_log2.unsqueeze(0))
        cur_out = torch.sum(weights.unsqueeze(-1) * local_o, dim=0)
        out[batch_idx] = cur_out.to(out_dtype)

    return out, lse


def dense_decode_fwd(
    q: torch.Tensor,
    kcache: torch.Tensor,
    head_size_v: int,
    seqlens_k: torch.Tensor,
    block_table: torch.Tensor,
    softmax_scale: float,
    is_causal: bool,
    tile_scheduler_metadata: Optional[torch.Tensor],
    num_splits: Optional[torch.Tensor],
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    b, s_q, h_q, d = q.shape
    num_blocks, page_block_size, h_k, d_k = kcache.shape
    if d != d_k:
        raise ValueError(f"q dim {d} must equal kcache dim {d_k}")
    if head_size_v != 512:
        raise ValueError("FlashMLA decode supports head_dim_v == 512")
    if h_q % h_k != 0:
        raise ValueError("num_heads_q must be divisible by num_heads_k")

    meta, splits = _ensure_sched_meta_dense(q, seqlens_k, h_k, tile_scheduler_metadata, num_splits)

    out = torch.empty((b, s_q, h_q, head_size_v), dtype=q.dtype, device=q.device)
    lse = torch.empty((b, h_q, s_q), dtype=torch.float32, device=q.device)

    for batch_idx in range(b):
        cur_len = int(seqlens_k[batch_idx].item())
        if cur_len > 0:
            cur_num_blocks = _ceil_div(cur_len, page_block_size)
            cur_block_indices = block_table[batch_idx, :cur_num_blocks].to(torch.long)
            kv = kcache.index_select(0, cur_block_indices).reshape(-1, h_k, d)[:cur_len]
            kv = kv.transpose(0, 1).float()
            kv = torch.nan_to_num(kv, nan=0.0)
        else:
            kv = torch.empty((h_k, 0, d), dtype=torch.float32, device=q.device)

        query = q[batch_idx].transpose(0, 1).float()
        if h_k != h_q:
            kv_for_heads = kv.repeat_interleave(h_q // h_k, dim=0)
        else:
            kv_for_heads = kv

        attn = torch.matmul(query, kv_for_heads.transpose(-2, -1)) * softmax_scale
        if is_causal and s_q > 1 and cur_len > 0:
            mask = torch.ones((s_q, cur_len), dtype=torch.bool, device=q.device).tril(diagonal=cur_len - s_q)
            attn = attn.masked_fill(~mask.view(1, s_q, cur_len), float("-inf"))

        cur_lse = torch.logsumexp(attn, dim=-1)
        probs = torch.exp(attn - cur_lse.unsqueeze(-1))
        cur_out = torch.matmul(probs, kv_for_heads[..., :head_size_v])

        lonely = cur_lse == float("-inf")
        if lonely.any():
            cur_out = cur_out.masked_fill(lonely.unsqueeze(-1), 0.0)
            cur_lse = cur_lse.masked_fill(lonely, float("+inf"))

        out[batch_idx] = cur_out.transpose(0, 1).to(q.dtype)
        lse[batch_idx] = cur_lse

    return out, lse, meta, splits


def _as_fp8_e4m3(tensor: torch.Tensor) -> torch.Tensor:
    if tensor.dtype == torch.float8_e4m3fn:
        return tensor
    if tensor.dtype in (torch.int8, torch.uint8):
        return tensor.view(torch.float8_e4m3fn)
    return tensor


def _dequantize_sparse_kv(kv: torch.Tensor, d_qk: int) -> torch.Tensor:
    """
    Dequantize SM90 sparse FP8 cache layouts to [num_blocks, block, 1, d_qk].
    """
    num_blocks, block_size, h_kv, bytes_per_token = kv.shape
    if h_kv != 1:
        raise ValueError("sparse decode currently supports h_kv == 1")

    kv_fp8 = _as_fp8_e4m3(kv).reshape(num_blocks, block_size, bytes_per_token)
    out = torch.empty((num_blocks, block_size, d_qk), dtype=torch.bfloat16, device=kv.device)

    if d_qk == 576:
        d_nope, d_rope, tile, num_scales = 512, 64, 128, 4
        if bytes_per_token != 656:
            raise ValueError(f"V32 sparse FP8 cache expects 656 bytes per token, got {bytes_per_token}")
        nope = kv_fp8[..., :d_nope]
        scales = kv_fp8[..., d_nope : d_nope + num_scales * 4].view(torch.float32)
        rope = kv_fp8[..., d_nope + num_scales * 4 :].view(torch.bfloat16)
        for scale_idx in range(num_scales):
            start = scale_idx * tile
            end = start + tile
            out[..., start:end] = (nope[..., start:end].float() * scales[..., scale_idx : scale_idx + 1]).to(torch.bfloat16)
        out[..., d_nope:] = rope
    elif d_qk == 512:
        d_nope, d_rope, tile, num_scales = 448, 64, 64, 7
        bytes_per_token_expected = d_nope + 2 * d_rope + 8
        if bytes_per_token != bytes_per_token_expected:
            raise ValueError(
                f"MODEL1 sparse FP8 cache expects {bytes_per_token_expected} bytes per token, got {bytes_per_token}"
            )
        flat = kv_fp8.reshape(num_blocks, block_size * bytes_per_token)
        nope_rope = flat[:, : block_size * (d_nope + 2 * d_rope)].reshape(
            num_blocks, block_size, d_nope + 2 * d_rope
        )
        nope = nope_rope[..., :d_nope]
        rope = nope_rope[..., d_nope:].view(torch.bfloat16)
        scales = flat[:, block_size * (d_nope + 2 * d_rope) :].reshape(num_blocks, block_size, 8)[
            ..., :num_scales
        ].view(torch.float8_e8m0fnu)
        for scale_idx in range(num_scales):
            start = scale_idx * tile
            end = start + tile
            out[..., start:end] = (
                nope[..., start:end].to(torch.bfloat16) * scales[..., scale_idx : scale_idx + 1].to(torch.bfloat16)
            )
        out[..., d_nope:] = rope
    else:
        raise ValueError(f"unsupported sparse d_qk: {d_qk}")

    return out.reshape(num_blocks, block_size, 1, d_qk)


def _gather_sparse_scope(
    kv: torch.Tensor,
    indices: torch.Tensor,
    topk_length: Optional[torch.Tensor],
    d_qk: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    b, s_q, topk = indices.shape
    dequant = _dequantize_sparse_kv(kv, d_qk).reshape(-1, d_qk)
    fixed = torch.clamp_min(indices, 0).to(torch.long)
    gathered = dequant.index_select(0, fixed.reshape(-1)).reshape(b, s_q, topk, d_qk)
    invalid = indices == -1
    if topk_length is not None:
        invalid = invalid | (
            torch.arange(topk, device=indices.device, dtype=torch.int32).view(1, 1, topk)
            >= topk_length.view(b, 1, 1)
        )
    gathered = torch.nan_to_num(gathered.float(), nan=0.0)
    return gathered, invalid


def sparse_decode_fwd(
    q: torch.Tensor,
    kv: torch.Tensor,
    indices: torch.Tensor,
    topk_length: Optional[torch.Tensor],
    attn_sink: Optional[torch.Tensor],
    tile_scheduler_metadata: Optional[torch.Tensor],
    num_splits: Optional[torch.Tensor],
    extra_kv: Optional[torch.Tensor],
    extra_indices: Optional[torch.Tensor],
    extra_topk_length: Optional[torch.Tensor],
    d_v: int,
    sm_scale: float,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    b, s_q, h_q, d_qk = q.shape
    if d_v != 512:
        raise ValueError("FlashMLA sparse decode supports d_v == 512")
    if kv.shape[2] != 1:
        raise ValueError("FlashMLA sparse decode supports h_kv == 1")

    extra_topk = int(extra_indices.shape[-1]) if extra_indices is not None else -1
    meta, splits = _ensure_sched_meta_sparse(
        q,
        int(indices.shape[-1]),
        extra_topk,
        topk_length,
        extra_topk_length,
        tile_scheduler_metadata,
        num_splits,
    )

    gathered, invalid = _gather_sparse_scope(kv, indices, topk_length, d_qk)
    if extra_kv is not None:
        if extra_indices is None:
            raise ValueError("extra_indices must be provided with extra_kv")
        gathered_extra, invalid_extra = _gather_sparse_scope(extra_kv, extra_indices, extra_topk_length, d_qk)
        gathered = torch.cat([gathered, gathered_extra], dim=2)
        invalid = torch.cat([invalid, invalid_extra], dim=2)

    total_topk = gathered.shape[2]
    q2 = q.float().reshape(b * s_q, h_q, d_qk)
    kv2 = gathered.reshape(b * s_q, total_topk, d_qk)
    invalid2 = invalid.reshape(b * s_q, total_topk)

    attn = torch.matmul(q2, kv2.transpose(-1, -2)) * sm_scale
    attn = attn.masked_fill(invalid2.view(b * s_q, 1, total_topk), float("-inf"))

    lse = torch.logsumexp(attn, dim=-1)
    probs = torch.exp(attn - lse.unsqueeze(-1))
    out = torch.matmul(probs, kv2[..., :d_v]).reshape(b, s_q, h_q, d_v)
    lse = lse.reshape(b, s_q, h_q)

    if attn_sink is not None:
        out = out * (1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - lse))).unsqueeze(-1)

    lonely = lse == float("-inf")
    if lonely.any():
        out = out.masked_fill(lonely.unsqueeze(-1), 0.0)
        lse = lse.masked_fill(lonely, float("+inf"))

    return out.to(torch.bfloat16), lse.transpose(1, 2), meta, splits
