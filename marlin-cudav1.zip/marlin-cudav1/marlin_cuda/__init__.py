"""
marlin-cuda: Standalone CUDA Marlin quantization GEMM kernels.

Provides fast matrix multiplication for quantized models (INT4/INT8/FP4/FP8)
using NVIDIA TensorCore MMA instructions with on-the-fly dequantization.

Usage:
    import marlin_cuda
    output = marlin_cuda.marlin_gemm(a, c, b_q_weight, b_bias, b_scales, ...)
"""

import os
from pathlib import Path

import torch

from .scalar_type import ScalarType  # noqa: ensure type constants are initialized


# Register torch library schemas before loading the .so
# The .so registers CUDA implementations via TORCH_LIBRARY_IMPL
_SCHEMAS = [
    ("marlin_gemm",
     "(Tensor a, Tensor? c_or_none, Tensor b_q_weight, "
     "Tensor? b_bias_or_none, Tensor b_scales, Tensor? a_scales_or_none, "
     "Tensor? global_scale_or_none, Tensor? b_zeros_or_none, "
     "Tensor? g_idx_or_none, Tensor? perm_or_none, Tensor workspace, "
     "int b_type_id, SymInt size_m, SymInt size_n, SymInt size_k, "
     "bool is_k_full, bool use_atomic_add, bool use_fp32_reduce, "
     "bool is_zp_float) -> Tensor"),
    ("gptq_marlin_repack",
     "(Tensor b_q_weight, Tensor perm, SymInt size_k, SymInt size_n, "
     "int num_bits, bool is_a_8bit) -> Tensor"),
    ("awq_marlin_repack",
     "(Tensor b_q_weight, SymInt size_k, SymInt size_n, "
     "int num_bits, bool is_a_8bit) -> Tensor"),
    ("marlin_int4_fp8_preprocess",
     "(Tensor qweight, Tensor? qzeros_or_none, bool inplace) -> Tensor"),
    ("moe_wna16_marlin_gemm",
     "(Tensor a, Tensor? c_or_none, Tensor b_q_weight, "
     "Tensor? b_bias_or_none, Tensor b_scales, Tensor? a_scales, "
     "Tensor? global_scale, Tensor? b_zeros_or_none, "
     "Tensor? g_idx_or_none, Tensor? perm_or_none, Tensor workspace, "
     "Tensor sorted_token_ids, Tensor expert_ids, "
     "Tensor num_tokens_past_padded, Tensor topk_weights, "
     "int moe_block_size, int top_k, bool mul_topk_weights, "
     "int b_type_id, int size_m, int size_n, int size_k, "
     "bool is_full_k, bool use_atomic_add, bool use_fp32_reduce, "
     "bool is_zp_float, int thread_k, int thread_n, "
     "int blocks_per_sm) -> Tensor"),
]


def _register_schemas():
    for name, schema in _SCHEMAS:
        try:
            torch.library.define(f"marlin_cuda::{name}", schema)
        except RuntimeError:
            pass  # already registered


# Load the compiled shared library
def _load_library():
    lib_dir = Path(__file__).parent
    candidates = [
        lib_dir / "_marlin_cuda.so",
        lib_dir / "marlin_cuda.so",
    ]
    for path in candidates:
        if path.exists():
            torch.ops.load_library(str(path))
            return
    # Try loading by name (if installed system-wide)
    try:
        torch.ops.load_library("marlin_cuda")
    except Exception:
        pass


_register_schemas()
_load_library()

from ._ops import (  # noqa: E402, F401
    marlin_gemm,
    gptq_marlin_repack,
    awq_marlin_repack,
    marlin_int4_fp8_preprocess,
    moe_wna16_marlin_gemm,
)
