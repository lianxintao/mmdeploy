"""
ScalarType implementation for marlin-cuda, mirroring the C++ scalar_type.hpp.

Stripped down from vLLM's scalar_type.py to contain only what marlin kernels need.
"""

import functools
import struct
from dataclasses import dataclass
from enum import Enum

_SCALAR_TYPES_ID_MAP = {}


class NanRepr(Enum):
    NONE = 0
    IEEE_754 = 1
    EXTD_RANGE_MAX_MIN = 2


@dataclass(frozen=True)
class ScalarType:
    """
    Represents floating point and integer types including sub-byte data types
    and types with bias (e.g. quantized types).

    Mirrors the C++ ScalarType in csrc/scalar_type.hpp.
    """

    exponent: int
    mantissa: int
    signed: bool
    bias: int
    _finite_values_only: bool = False
    nan_repr: NanRepr = NanRepr.IEEE_754

    def _floating_point_max_int(self) -> int:
        assert self.mantissa <= 52 and self.exponent <= 11
        max_mantissa = (1 << self.mantissa) - 1
        if self.nan_repr == NanRepr.EXTD_RANGE_MAX_MIN:
            max_mantissa = max_mantissa - 1
        max_exponent = (1 << self.exponent) - 2
        if self.nan_repr in (NanRepr.EXTD_RANGE_MAX_MIN, NanRepr.NONE):
            assert self.exponent < 11
            max_exponent = max_exponent + 1
        exponent_bias = (1 << (self.exponent - 1)) - 1
        exponent_bias_double = (1 << 10) - 1
        max_exponent_double = max_exponent - exponent_bias + exponent_bias_double
        return (max_mantissa << (52 - self.mantissa)) | (max_exponent_double << 52)

    def _floating_point_max(self) -> float:
        double_raw = self._floating_point_max_int()
        return struct.unpack("!d", struct.pack("!Q", double_raw))[0]

    def _raw_max(self) -> int | float:
        if self.is_floating_point():
            return self._floating_point_max()
        else:
            assert self.size_bits < 64 or (self.size_bits == 64 and self.is_signed())
            return (1 << self.mantissa) - 1

    def _raw_min(self) -> int | float:
        if self.is_floating_point():
            assert self.is_signed()
            sign_bit_double = 1 << 63
            max_raw = self._floating_point_max_int()
            min_raw = max_raw | sign_bit_double
            return struct.unpack("!d", struct.pack("!Q", min_raw))[0]
        else:
            assert not self.is_signed() or self.size_bits <= 64
            if self.is_signed():
                return -(1 << (self.size_bits - 1))
            else:
                return 0

    @functools.cached_property
    def id(self) -> int:
        """Convert to int for passing to pytorch custom ops.
        Layout must match C++ ScalarType::from_id in scalar_type.hpp.
        """
        val = 0
        offset = 0

        def or_and_advance(member, bit_width):
            nonlocal val, offset
            bit_mask = (1 << bit_width) - 1
            val = val | (int(member) & bit_mask) << offset
            offset = offset + bit_width

        or_and_advance(self.exponent, 8)
        or_and_advance(self.mantissa, 8)
        or_and_advance(self.signed, 1)
        or_and_advance(self.bias, 32)
        or_and_advance(self._finite_values_only, 1)
        or_and_advance(self.nan_repr.value, 8)

        assert offset <= 64
        _SCALAR_TYPES_ID_MAP[val] = self
        return val

    @property
    def size_bits(self) -> int:
        return self.exponent + self.mantissa + int(self.signed)

    def min(self) -> int | float:
        return self._raw_min() - self.bias

    def max(self) -> int | float:
        return self._raw_max() - self.bias

    def is_signed(self) -> bool:
        return self.signed

    def is_floating_point(self) -> bool:
        return self.exponent != 0

    def is_integer(self) -> bool:
        return self.exponent == 0

    def has_bias(self) -> bool:
        return self.bias != 0

    def has_infs(self) -> bool:
        return not self._finite_values_only

    def has_nans(self) -> bool:
        return self.nan_repr != NanRepr.NONE.value

    def is_ieee_754(self) -> bool:
        return self.nan_repr == NanRepr.IEEE_754.value and not self._finite_values_only

    def str(self) -> str:
        if self.is_floating_point():
            ret = f"float{self.size_bits}_e{self.exponent}m{self.mantissa}"
            if not self.is_ieee_754():
                if self._finite_values_only:
                    ret = ret + "f"
                if self.nan_repr != NanRepr.NONE:
                    ret = ret + "n"
            return ret
        else:
            ret = ("int" if self.is_signed() else "uint") + str(self.size_bits)
            if self.has_bias():
                ret = ret + "b" + str(self.bias)
            return ret

    def __str__(self) -> str:
        return self.str()

    def __repr__(self) -> str:
        return "ScalarType." + self.str()

    def __len__(self) -> int:
        raise TypeError

    @classmethod
    def int_(cls, size_bits: int, bias: int | None) -> "ScalarType":
        ret = cls(0, size_bits - 1, True, bias if bias else 0)
        ret.id
        return ret

    @classmethod
    def uint(cls, size_bits: int, bias: int | None) -> "ScalarType":
        ret = cls(0, size_bits, False, bias if bias else 0)
        ret.id
        return ret

    @classmethod
    def float_IEEE754(cls, exponent: int, mantissa: int) -> "ScalarType":
        assert mantissa > 0 and exponent > 0
        ret = cls(exponent, mantissa, True, 0)
        ret.id
        return ret

    @classmethod
    def float_(
        cls, exponent: int, mantissa: int, finite_values_only: bool, nan_repr: NanRepr
    ) -> "ScalarType":
        assert mantissa > 0 and exponent > 0
        assert nan_repr != NanRepr.IEEE_754
        ret = cls(exponent, mantissa, True, 0, finite_values_only, nan_repr)
        ret.id
        return ret

    @classmethod
    def from_id(cls, scalar_type_id: int):
        if scalar_type_id not in _SCALAR_TYPES_ID_MAP:
            raise ValueError(f"scalar_type_id {scalar_type_id} doesn't exist.")
        return _SCALAR_TYPES_ID_MAP[scalar_type_id]


# Type constants used by marlin kernels (mirrors C++ scalar_type.hpp)
kFloat16 = ScalarType.float_IEEE754(5, 10)       # float16_e5m10 (half)
kBFloat16 = ScalarType.float_IEEE754(8, 7)        # float16_e8m7 (bfloat16)
kU4 = ScalarType.uint(4, None)                     # uint4
kU4B8 = ScalarType.uint(4, 8)                      # uint4b8
kU8 = ScalarType.uint(8, None)                     # uint8
kU8B128 = ScalarType.uint(8, 128)                  # uint8b128
kS4 = ScalarType.int_(4, None)                     # int4
kS8 = ScalarType.int_(8, None)                     # int8
kFE4M3fn = ScalarType.float_(4, 3, True, NanRepr.EXTD_RANGE_MAX_MIN)   # float8_e4m3fn
kFE2M1f = ScalarType.float_(2, 1, True, NanRepr.NONE)                   # float4_e2m1f
kFE8M0fnu = ScalarType(8, 0, False, 0, True, NanRepr.EXTD_RANGE_MAX_MIN)  # float8_e8m0fnu
