"""
Python bindings for marlin-cuda torch ops.

These functions wrap the registered torch.ops.marlin_cuda.* operators
and maintain the same API as the original vLLM marlin ops.
"""

from typing import Optional

import torch

from .scalar_type import ScalarType


def gptq_marlin_repack(
    b_q_weight: torch.Tensor,
    perm: torch.Tensor,
    size_k: int,
    size_n: int,
    num_bits: int,
    is_a_8bit: bool = False,
) -> torch.Tensor:
    """Repack GPTQ quantized weights for use with the Marlin kernel."""
    return torch.ops.marlin_cuda.gptq_marlin_repack(
        b_q_weight, perm, size_k, size_n, num_bits, is_a_8bit
    )


def awq_marlin_repack(
    b_q_weight: torch.Tensor,
    size_k: int,
    size_n: int,
    num_bits: int,
    is_a_8bit: bool = False,
) -> torch.Tensor:
    """Repack AWQ quantized weights for use with the Marlin kernel."""
    return torch.ops.marlin_cuda.awq_marlin_repack(
        b_q_weight, size_k, size_n, num_bits, is_a_8bit
    )


def marlin_int4_fp8_preprocess(
    qweight: torch.Tensor,
    qzeros_or_none: Optional[torch.Tensor] = None,
    inplace: bool = False,
) -> torch.Tensor:
    """Preprocess INT4 quantized weights for FP8 computation."""
    return torch.ops.marlin_cuda.marlin_int4_fp8_preprocess(
        qweight, qzeros_or_none, inplace
    )


def marlin_gemm(
    a: torch.Tensor,
    c: Optional[torch.Tensor],
    b_q_weight: torch.Tensor,
    b_bias: Optional[torch.Tensor],
    b_scales: torch.Tensor,
    a_scales: Optional[torch.Tensor],
    global_scale: Optional[torch.Tensor],
    b_zeros: Optional[torch.Tensor],
    g_idx: Optional[torch.Tensor],
    perm: Optional[torch.Tensor],
    workspace: torch.Tensor,
    b_q_type: ScalarType,
    size_m: int,
    size_n: int,
    size_k: int,
    is_k_full: bool = True,
    use_atomic_add: bool = False,
    use_fp32_reduce: bool = False,
    is_zp_float: bool = False,
) -> torch.Tensor:
    """Marlin GEMM: quantized matrix multiplication with on-the-fly dequantization.

    Computes C = A @ dequant(B) where B is a quantized weight matrix.

    Args:
        a: Activation tensor of shape (size_m, size_k), FP16/BF16/FP8/INT8
        c: Optional output tensor, same shape as result
        b_q_weight: Quantized weight tensor in Marlin format
        b_bias: Optional bias tensor of shape (size_n,)
        b_scales: Weight scales tensor of shape (num_groups, size_n)
        a_scales: Activation scales for 8-bit activation (optional)
        global_scale: Global scale for NVFP4 format (optional)
        b_zeros: Zero points tensor (optional, for AWQ format)
        g_idx: Group indices for act_order (optional)
        perm: Permutation indices for act_order (optional)
        workspace: Workspace tensor for atomic operations
        b_q_type: ScalarType of the quantized weights
        size_m: M dimension of the GEMM
        size_n: N dimension of the GEMM
        size_k: K dimension of the GEMM
        is_k_full: Whether K is the full problem dimension
        use_atomic_add: Use atomicAdd for partial reduction
        use_fp32_reduce: Use FP32 accumulation for reduction
        is_zp_float: Whether zero points are in floating-point format

    Returns:
        Output tensor of shape (size_m, size_n)
    """
    return torch.ops.marlin_cuda.marlin_gemm(
        a,
        c,
        b_q_weight,
        b_bias,
        b_scales,
        a_scales,
        global_scale,
        b_zeros,
        g_idx,
        perm,
        workspace,
        b_q_type.id,
        size_m,
        size_n,
        size_k,
        is_k_full,
        use_atomic_add,
        use_fp32_reduce,
        is_zp_float,
    )


def moe_wna16_marlin_gemm(
    input: torch.Tensor,
    output: Optional[torch.Tensor],
    b_qweight: torch.Tensor,
    b_bias: Optional[torch.Tensor],
    b_scales: torch.Tensor,
    a_scales: Optional[torch.Tensor],
    global_scale: Optional[torch.Tensor],
    b_qzeros: Optional[torch.Tensor],
    g_idx: Optional[torch.Tensor],
    perm: Optional[torch.Tensor],
    workspace: torch.Tensor,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_past_padded: torch.Tensor,
    topk_weights: torch.Tensor,
    moe_block_size: int,
    top_k: int,
    mul_topk_weights: bool,
    b_q_type: ScalarType,
    size_m: int,
    size_n: int,
    size_k: int,
    is_k_full: bool,
    use_atomic_add: bool,
    use_fp32_reduce: bool,
    is_zp_float: bool,
    thread_k: int = -1,
    thread_n: int = -1,
    blocks_per_sm: int = -1,
) -> torch.Tensor:
    """Marlin MoE WNA16 GEMM: quantized matrix multiplication for Mixture of Experts.

    Computes the grouped GEMM for MoE where each expert's weights are stacked
    and tokens are routed to their assigned experts.

    Args:
        input: Activation tensor of shape (num_tokens, size_k), FP16/BF16/FP8
        output: Optional output tensor, same shape as result
        b_qweight: Stacked quantized weight tensor in Marlin format
        b_bias: Optional bias tensor
        b_scales: Weight scales tensor
        a_scales: Activation scales for 8-bit activation (optional)
        global_scale: Global scale for NVFP4 format (optional)
        b_qzeros: Zero points tensor (optional, for AWQ format)
        g_idx: Group indices for act_order (optional)
        perm: Permutation indices for act_order (optional)
        workspace: Workspace tensor for atomic operations
        sorted_token_ids: Sorted token IDs for MoE routing
        expert_ids: Expert IDs assigned to each token
        num_tokens_past_padded: Number of tokens per expert (padded)
        topk_weights: Top-k weights for weighted combination
        moe_block_size: MoE block size for tiling
        top_k: Number of experts per token
        mul_topk_weights: Whether to multiply by topk weights
        b_q_type: ScalarType of the quantized weights
        size_m: M dimension (total tokens)
        size_n: N dimension of each expert
        size_k: K dimension
        is_k_full: Whether K is the full problem dimension
        use_atomic_add: Use atomicAdd for partial reduction
        use_fp32_reduce: Use FP32 accumulation for reduction
        is_zp_float: Whether zero points are in floating-point format
        thread_k: Thread configuration for K dimension (-1 for auto)
        thread_n: Thread configuration for N dimension (-1 for auto)
        blocks_per_sm: Blocks per SM (-1 for auto)

    Returns:
        Output tensor of shape (num_tokens, size_n)
    """
    return torch.ops.marlin_cuda.moe_wna16_marlin_gemm(
        input,
        output,
        b_qweight,
        b_bias,
        b_scales,
        a_scales,
        global_scale,
        b_qzeros,
        g_idx,
        perm,
        workspace,
        sorted_token_ids,
        expert_ids,
        num_tokens_past_padded,
        topk_weights,
        moe_block_size,
        top_k,
        mul_topk_weights,
        b_q_type.id,
        size_m,
        size_n,
        size_k,
        is_k_full,
        use_atomic_add,
        use_fp32_reduce,
        is_zp_float,
        thread_k,
        thread_n,
        blocks_per_sm,
    )
