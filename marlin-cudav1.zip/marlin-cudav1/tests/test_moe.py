"""Tests for the marlin-cuda MoE kernel.

Run `pytest tests/test_moe.py`.
"""

import pytest
import torch

# Try to import marlin_cuda; skip tests if not available
try:
    import marlin_cuda
    from marlin_cuda.scalar_type import kU4B8

    HAVE_MARLIN = True
except ImportError:
    HAVE_MARLIN = False

pytestmark = pytest.mark.skipif(not HAVE_MARLIN, reason="marlin-cuda not installed")

if not torch.cuda.is_available():
    pytest.skip("CUDA not available", allow_module_level=True)

COMPUTE_CAP = torch.cuda.get_device_capability()[0] * 10 + torch.cuda.get_device_capability()[1]
if COMPUTE_CAP < 75:
    pytest.skip("Marlin requires compute capability >= 7.5", allow_module_level=True)


def marlin_make_workspace(device):
    """Create workspace tensor for marlin gemm (MoE safe upper bound)."""
    sms = torch.cuda.get_device_properties(device).multi_processor_count
    return torch.zeros(sms * 4, dtype=torch.int32, device=device)


def quantize_gptq_int4(weight, group_size):
    """Quantize a float weight [K, N] to GPTQ INT4 format.

    Returns (qweight_raw, scales, weight_ref) where:
      - qweight_raw: packed int32 tensor of shape (K // 8, N)
      - scales: float scales of shape (num_groups, N)
      - weight_ref: dequantized reference weight [K, N]
    """
    size_k, size_n = weight.shape
    num_groups = size_k // group_size
    dtype = weight.dtype
    weight_cpu = weight.cpu()

    qweight_raw = torch.zeros((size_k // 8, size_n), dtype=torch.int32)
    scales = torch.zeros((num_groups, size_n), dtype=dtype)
    weight_ref = torch.zeros((size_k, size_n), dtype=dtype)

    for g in range(num_groups):
        start_k = g * group_size
        end_k = start_k + group_size
        w_group = weight_cpu[start_k:end_k, :]
        scale = w_group.abs().max(dim=0, keepdim=True).values / 7.0
        scale = scale.clamp(min=1e-6)
        scales[g] = scale.squeeze(0).to(dtype)

        w_q = (w_group / scale).round().clamp(-8, 7).to(torch.int8)
        # GPTQ INT4 encoding: store (w_q + 8) as 4-bit unsigned
        w_q_u = (w_q + 8).to(torch.int32) & 0xF
        weight_ref[start_k:end_k, :] = (w_q.to(dtype)) * scales[g]

        for k in range(group_size):
            row = k // 8
            pos = k % 8
            qweight_raw[start_k // 8 + row, :] |= w_q_u[k] << (pos * 4)

    return qweight_raw, scales, weight_ref


class TestMarlinMoeGemm:
    """Tests for moe_wna16_marlin_gemm — validate kernel runs and produces correct results."""

    def _run_moe_and_ref(self, a, expert_weights_ref, expert_scales, sorted_token_ids,
                         expert_ids, num_tokens_past_padded, topk_weights,
                         moe_block_size, top_k, mul_topk_weights):
        """Run MoE gemm and compute reference.

        expert_weights_ref: list of [K, N] per expert
        expert_scales: list of [num_groups, N] per expert (only used for b_qweight shape)
        """
        num_experts = len(expert_weights_ref)
        size_k = expert_weights_ref[0].shape[0]
        size_n = expert_weights_ref[0].shape[1]
        size_m = a.shape[0]
        dtype = a.dtype
        group_size = size_k // expert_scales[0].shape[0]
        num_groups = expert_scales[0].shape[0]

        # Quantize and repack each expert
        expert_qweights = []
        all_scales = []
        for e in range(num_experts):
            qweight_raw, scales, _ = quantize_gptq_int4(expert_weights_ref[e], group_size)
            qweight_raw = qweight_raw.to(device="cuda")
            perm_empty = torch.empty(0, dtype=torch.int32, device="cuda")
            qw_repacked = marlin_cuda.gptq_marlin_repack(
                qweight_raw, perm_empty, size_k, size_n, 4
            )
            expert_qweights.append(qw_repacked)
            all_scales.append(scales.to(device="cuda"))

        b_q_weight = torch.stack(expert_qweights, dim=0)
        b_scales = torch.stack(all_scales, dim=0)

        workspace = marlin_make_workspace(a.device)

        output = marlin_cuda.moe_wna16_marlin_gemm(
            input=a,
            output=None,
            b_qweight=b_q_weight,
            b_bias=None,
            b_scales=b_scales,
            a_scales=None,
            global_scale=None,
            b_qzeros=None,
            g_idx=None,
            perm=None,
            workspace=workspace,
            sorted_token_ids=sorted_token_ids,
            expert_ids=expert_ids,
            num_tokens_past_padded=num_tokens_past_padded,
            topk_weights=topk_weights,
            moe_block_size=moe_block_size,
            top_k=top_k,
            mul_topk_weights=mul_topk_weights,
            b_q_type=kU4B8,
            size_m=size_m,
            size_n=size_n,
            size_k=size_k,
            is_k_full=True,
            use_atomic_add=False,
            use_fp32_reduce=True,
            is_zp_float=False,
        )
        torch.cuda.synchronize()

        # Reference: compute per-expert matmul and route
        output_ref = torch.zeros(size_m, size_n, dtype=dtype, device="cuda")
        block_size = moe_block_size
        num_tokens_pp = num_tokens_past_padded.sum().item()
        num_blocks = (num_tokens_pp + block_size - 1) // block_size

        for block_idx in range(num_blocks):
            expert = expert_ids[block_idx].item()
            if expert < 0:
                continue
            w_ref = expert_weights_ref[expert].to(device="cuda", dtype=dtype)
            for i in range(block_size):
                idx = block_idx * block_size + i
                if idx >= num_tokens_pp:
                    break
                token_id = sorted_token_ids[idx].item()
                if token_id >= size_m:
                    break
                # In MoE, each token appears top_k times (once per routed expert)
                orig_token = token_id % size_m
                weight = topk_weights[idx].item() if mul_topk_weights else 1.0
                output_ref[orig_token] += (a[orig_token:orig_token+1].to(torch.float32) @
                                           w_ref.to(torch.float32)).to(dtype) * weight

        return output, output_ref

    @pytest.mark.parametrize("size_n", [256])
    @pytest.mark.parametrize("size_k", [512, 1024])
    @pytest.mark.parametrize("group_size", [128])
    @pytest.mark.parametrize("num_experts,top_k,moe_block_size", [
        (2, 1, 32),
        (2, 2, 32),
        (4, 2, 32),
    ])
    def test_moe_gemm_int4(self, size_n, size_k, group_size, num_experts, top_k, moe_block_size):
        """Test moe_wna16_marlin_gemm with GPTQ-INT4 weights against reference."""
        dtype = torch.float16
        size_m = moe_block_size * num_experts * top_k

        # Create input and expert weights
        a = torch.randn((size_m, size_k), dtype=dtype, device="cuda") / 10
        expert_weights_ref = []
        expert_scales = []
        for e in range(num_experts):
            w = torch.randn((size_k, size_n), dtype=dtype) / 10
            _, scales, w_ref = quantize_gptq_int4(w, group_size)
            expert_weights_ref.append(w_ref)
            expert_scales.append(scales)

        # Routing: each token goes to its assigned experts
        # For top_k=1: token i -> expert (i * num_experts // size_m)
        # For top_k=2: each token gets two experts
        sorted_ids_list = []
        expert_ids_list = []
        token_counts = torch.zeros(num_experts, dtype=torch.int32)
        for e in range(num_experts):
            tokens_for_expert = []
            for t in range(size_m):
                if top_k == 1:
                    if t % num_experts == e:
                        tokens_for_expert.append(t)
                else:
                    if (t + e) % num_experts < top_k:
                        tokens_for_expert.append(t)
            # Round up to moe_block_size
            padded = (len(tokens_for_expert) + moe_block_size - 1) // moe_block_size * moe_block_size
            token_counts[e] = padded
            tokens_for_expert += [size_m] * (padded - len(tokens_for_expert))
            sorted_ids_list.extend(tokens_for_expert)
            num_blocks = padded // moe_block_size
            expert_ids_list.extend([e] * num_blocks)

        sorted_token_ids = torch.tensor(sorted_ids_list, dtype=torch.int32, device="cuda")
        expert_ids = torch.tensor(expert_ids_list, dtype=torch.int32, device="cuda")
        num_tokens_past_padded = token_counts.to(device="cuda")
        topk_weights = torch.ones(sorted_token_ids.shape[0], dtype=torch.float32, device="cuda")

        output, output_ref = self._run_moe_and_ref(
            a, expert_weights_ref, expert_scales, sorted_token_ids,
            expert_ids, num_tokens_past_padded, topk_weights,
            moe_block_size, top_k, mul_topk_weights=False,
        )

        assert output.shape == (size_m, size_n)
        assert output.dtype == dtype

        max_diff = torch.mean(torch.abs(output - output_ref)) / torch.mean(torch.abs(output_ref))
        assert max_diff < 0.12, f"Max relative diff {max_diff:.4f} exceeds threshold"

    def test_moe_gemm_mul_topk_weights(self):
        """Test moe_wna16_marlin_gemm with mul_topk_weights=True."""
        dtype = torch.float16
        num_experts = 2
        top_k = 2
        moe_block_size = 32
        size_n = 256
        size_k = 512
        group_size = 128
        size_m = moe_block_size * num_experts * top_k

        a = torch.randn((size_m, size_k), dtype=dtype, device="cuda") / 10
        expert_weights_ref = []
        expert_scales = []
        for e in range(num_experts):
            w = torch.randn((size_k, size_n), dtype=dtype) / 10
            _, scales, w_ref = quantize_gptq_int4(w, group_size)
            expert_weights_ref.append(w_ref)
            expert_scales.append(scales)

        # Each token goes to both experts
        sorted_ids = []
        expert_ids = []
        token_counts = torch.zeros(num_experts, dtype=torch.int32)
        for e in range(num_experts):
            tokens = list(range(size_m))
            padded = (len(tokens) + moe_block_size - 1) // moe_block_size * moe_block_size
            token_counts[e] = padded
            tokens += [size_m] * (padded - len(tokens))
            sorted_ids.extend(tokens)
            num_blocks = padded // moe_block_size
            expert_ids.extend([e] * num_blocks)

        sorted_token_ids = torch.tensor(sorted_ids, dtype=torch.int32, device="cuda")
        expert_ids = torch.tensor(expert_ids, dtype=torch.int32, device="cuda")
        num_tokens_past_padded = token_counts.to(device="cuda")
        topk_weights = torch.full((sorted_token_ids.shape[0],), 0.5, dtype=torch.float32, device="cuda")

        output, output_ref = self._run_moe_and_ref(
            a, expert_weights_ref, expert_scales, sorted_token_ids,
            expert_ids, num_tokens_past_padded, topk_weights,
            moe_block_size, top_k, mul_topk_weights=True,
        )

        assert output.shape == (size_m, size_n)
        max_diff = torch.mean(torch.abs(output - output_ref)) / torch.mean(torch.abs(output_ref))
        assert max_diff < 0.15, f"Max relative diff {max_diff:.4f} exceeds threshold"

    def test_moe_gemm_output_shape(self):
        """Smoke test: verify moe_wna16_marlin_gemm produces correct output shape."""
        dtype = torch.float16
        num_experts = 2
        top_k = 1
        moe_block_size = 32
        size_n = 256
        size_k = 512
        group_size = 128
        size_m = 32  # exactly one block worth of tokens

        a = torch.randn((size_m, size_k), dtype=dtype, device="cuda") / 10
        expert_weights_ref = []
        expert_scales = []
        for e in range(num_experts):
            w = torch.randn((size_k, size_n), dtype=dtype) / 10
            _, scales, w_ref = quantize_gptq_int4(w, group_size)
            expert_weights_ref.append(w_ref)
            expert_scales.append(scales)

        # Token 0-15 to expert 0, token 16-31 to expert 1
        sorted_token_ids = torch.arange(size_m, dtype=torch.int32, device="cuda")
        expert_ids = torch.tensor([0, 1], dtype=torch.int32, device="cuda")
        num_tokens_past_padded = torch.tensor([moe_block_size, moe_block_size],
                                              dtype=torch.int32, device="cuda")
        topk_weights = torch.ones(size_m, dtype=torch.float32, device="cuda")

        output, _ = self._run_moe_and_ref(
            a, expert_weights_ref, expert_scales, sorted_token_ids,
            expert_ids, num_tokens_past_padded, topk_weights,
            moe_block_size, top_k, mul_topk_weights=False,
        )

        assert output.shape == (size_m, size_n)
        assert output.dtype == dtype
