"""Tests for the marlin-cuda kernel.

Run `pytest tests/test_marlin_gemm.py`.
"""

import pytest
import torch

# Try to import marlin_cuda; skip tests if not available
try:
    import marlin_cuda
    from marlin_cuda.scalar_type import (
        kFloat16,
        kBFloat16,
        kU4,
        kU4B8,
        kU8B128,
        kFE4M3fn,
        kFE2M1f,
        kFE8M0fnu,
        ScalarType,
    )
    HAVE_MARLIN = True
except ImportError:
    HAVE_MARLIN = False

pytestmark = pytest.mark.skipif(not HAVE_MARLIN, reason="marlin-cuda not installed")

# Check if CUDA is available
if not torch.cuda.is_available():
    pytest.skip("CUDA not available", allow_module_level=True)

# Check compute capability
COMPUTE_CAP = torch.cuda.get_device_capability()[0] * 10 + torch.cuda.get_device_capability()[1]
if COMPUTE_CAP < 75:
    pytest.skip("Marlin requires compute capability >= 7.5", allow_module_level=True)


def compute_max_diff(output, output_ref):
    return torch.mean(torch.abs(output - output_ref)) / torch.mean(
        torch.abs(output_ref)
    )


def rand_data(shape, dtype=torch.float16):
    return torch.randn(shape, dtype=dtype, device="cuda")


def marlin_make_workspace(device):
    """Create workspace tensor for marlin gemm."""
    sms = torch.cuda.get_device_properties(device).multi_processor_count
    return torch.zeros(sms, dtype=torch.int32, device=device)


class TestPreprocess:
    """Tests for marlin_int4_fp8_preprocess."""

    def test_preprocess_without_zp(self):
        qweight_unpacked = torch.randint(
            0, 16, size=(2048, 2048), dtype=torch.int32, device="cuda"
        )
        qweight_packed = qweight_unpacked[:, ::2] * 16 + qweight_unpacked[:, 1::2]
        qweight_packed = qweight_packed.to(torch.int8).view(torch.int32)

        cuda_res = marlin_cuda.marlin_int4_fp8_preprocess(qweight_packed)

        torch_res = torch.where(
            qweight_unpacked >= 8, qweight_unpacked - 8, 15 - qweight_unpacked
        )
        torch_res = torch_res[:, ::2] * 16 + torch_res[:, 1::2]
        torch_res = torch_res.to(torch.int8).view(torch.int32)

        assert (cuda_res == torch_res).all()

    def test_preprocess_awq(self):
        group_size = 128

        qweight_unpacked = torch.randint(
            0, 16, size=(2048, 2048), dtype=torch.int32, device="cuda"
        )
        qzeros_unpacked = torch.randint(
            0, 16, size=(2048 // group_size, 2048), dtype=torch.int32, device="cuda"
        )

        qweight_packed = qweight_unpacked[:, ::2] * 16 + qweight_unpacked[:, 1::2]
        qweight_packed = qweight_packed.to(torch.int8).view(torch.int32)
        qzeros_packed = qzeros_unpacked[:, ::2] * 16 + qzeros_unpacked[:, 1::2]
        qzeros_packed = qzeros_packed.to(torch.int8).view(torch.int32)

        cuda_res = marlin_cuda.marlin_int4_fp8_preprocess(qweight_packed, qzeros_packed)

        repeated_zp = qzeros_unpacked.repeat_interleave(group_size, 0)
        torch_res = qweight_unpacked - repeated_zp
        torch_res[torch_res < 0] = 15 - qweight_unpacked[torch_res < 0]
        torch_res = torch_res[:, ::2] * 16 + torch_res[:, 1::2]
        torch_res = torch_res.to(torch.int8).view(torch.int32)

        assert (cuda_res == torch_res).all()


class TestMarlinGemm:
    """Tests for marlin_gemm — validate the kernel runs and produces correct shapes."""

    @pytest.mark.parametrize("dtype", [torch.float16, torch.bfloat16])
    def test_gemm_output_shape(self, dtype):
        """Run marlin_gemm with GPTQ-INT4 packed weights, verify output shape."""
        group_size = 128
        size_m, size_n, size_k = 16, 256, 1024
        s_dtype = dtype

        a = rand_data((size_m, size_k), dtype=dtype)
        b_weight = rand_data((size_k, size_n), dtype=dtype)

        # Quantize to GPTQ INT4: pack weights per group, use repack to get marlin format
        num_groups = size_k // group_size
        b_weight_cpu = b_weight.cpu()

        # GPTQ packed weight layout: [K / pack_factor, N] where pack_factor=8 for 4bit
        b_q_weight_raw = torch.zeros(
            (size_k // 8, size_n), dtype=torch.int32
        )
        b_scales_raw = torch.zeros(
            (num_groups, size_n), dtype=s_dtype
        )

        for g in range(num_groups):
            start_k = g * group_size
            end_k = start_k + group_size
            w_group = b_weight_cpu[start_k:end_k, :]  # [group, N]
            scale = w_group.abs().max(dim=0, keepdim=True).values / 7.0
            scale = scale.clamp(min=1e-6)
            b_scales_raw[g] = scale.squeeze(0).to(s_dtype)

            w_q = (w_group / scale).round().clamp(-8, 7).to(torch.int8) + 8
            for k in range(group_size):
                row = k // 8
                pos = k % 8
                b_q_weight_raw[start_k // 8 + row, :] |= (w_q[k].to(torch.int32) & 0xF) << (pos * 4)

        b_q_weight_raw = b_q_weight_raw.to(device="cuda")
        b_scales_raw = b_scales_raw.to(device="cuda")
        perm = torch.empty(0, dtype=torch.int32, device="cuda")

        # Repack to marlin format
        b_q_weight = marlin_cuda.gptq_marlin_repack(
            b_q_weight_raw, perm, size_k, size_n, 4
        )

        workspace = marlin_make_workspace(a.device)
        output = marlin_cuda.marlin_gemm(
            a=a,
            c=None,
            b_q_weight=b_q_weight,
            b_bias=None,
            b_scales=b_scales_raw,
            a_scales=None,
            global_scale=None,
            b_zeros=None,
            g_idx=None,
            perm=None,
            workspace=workspace,
            b_q_type=kU4B8,
            size_m=size_m,
            size_n=size_n,
            size_k=size_k,
            is_k_full=True,
            use_atomic_add=False,
            use_fp32_reduce=True,
            is_zp_float=False,
        )

        torch.cuda.synchronize()
        assert output.shape == (size_m, size_n)
        assert output.dtype == dtype


class TestRepack:
    """Tests for repack kernels."""

    @pytest.mark.parametrize("num_bits", [4, 8])
    def test_gptq_repack_basic(self, num_bits):
        """Test GPTQ repack produces correct output shape."""
        size_k = 1024
        size_n = 256
        pack_factor = 32 // num_bits

        b_q_weight = torch.randint(
            0, 2**31 - 1,
            (size_k // pack_factor, size_n),
            dtype=torch.int32, device="cuda"
        )
        perm = torch.empty(0, dtype=torch.int32, device="cuda")

        result = marlin_cuda.gptq_marlin_repack(
            b_q_weight, perm, size_k, size_n, num_bits
        )
        torch.cuda.synchronize()

        expected_k = size_k // 16
        expected_n = size_n * 16 // pack_factor
        assert result.shape == (expected_k, expected_n)

    @pytest.mark.parametrize("num_bits", [4, 8])
    def test_awq_repack_basic(self, num_bits):
        """Test AWQ repack produces correct output shape."""
        size_k = 1024
        size_n = 256
        pack_factor = 32 // num_bits

        b_q_weight = torch.randint(
            0, 2**31 - 1,
            (size_k, size_n // pack_factor),
            dtype=torch.int32, device="cuda"
        )

        result = marlin_cuda.awq_marlin_repack(
            b_q_weight, size_k, size_n, num_bits
        )
        torch.cuda.synchronize()

        expected_k = size_k // 16
        expected_n = size_n * 16 // pack_factor
        assert result.shape == (expected_k, expected_n)



