# marlin-cuda

从 vLLM 中提取的独立 Marlin CUDA 量化 GEMM 内核库。利用 NVIDIA TensorCore MMA 指令实现 INT4/INT8/FP4/FP8 量化权重的快速矩阵乘法，支持运行时反量化。

## 系统要求

- Python >= 3.10
- PyTorch >= 2.0.0（CUDA 版本）
- CUDA Toolkit >= 12.0（编译 SM89 需要 >= 12.9）
- GPU 计算能力 >= 7.5（SM75+），FP8 支持需要 SM89+

## 安装

### 方式一：pip 安装（推荐）

```bash
cd marlin-cuda
MAX_JOBS=2 pip install -e .  --no-build-isolation
```

`MAX_JOBS` 环境变量控制并行编译线程数（默认 2），避免内存不足。

### 方式二：手动 CMake 编译

```bash
cd marlin-cuda
mkdir build && cd build

# 配置（指定 Python 路径和 PyTorch cmake 模块路径）
cmake .. -G Ninja \
  -DCMAKE_PREFIX_PATH=$(python -c "import torch; print(torch.utils.cmake_prefix_path)") \
  -DPYTHON_EXECUTABLE=$(which python)

# 编译（限制线程数以控制内存占用）
cmake --build . -j2

# 将生成的 .so 复制到包目录
cp marlin_cuda/marlin_cuda.so ../marlin_cuda/marlin_cuda.so
```

默认编译目标为 SM89（Ada Lovelace）。SM120（Blackwell）向下兼容 SM89 PTX，可直接运行。

### 方式三：使用 build_kernel.py

```bash
cd marlin-cuda
python build_kernel.py
```

直接用 nvcc 编译，适合快速调试。

## 使用示例

```python
import torch
from marlin_cuda import marlin_gemm, gptq_marlin_repack, awq_marlin_repack
from marlin_cuda.scalar_type import kU4B8, kFloat16

# 准备输入
size_m, size_n, size_k = 16, 256, 1024
a = torch.randn((size_m, size_k), dtype=torch.float16, device="cuda")

# 量化权重（以 GPTQ INT4 为例）
b_weight = torch.randn((size_k, size_n), dtype=torch.float16, device="cuda")
# ... 量化过程（按 group 做 per-channel 量化）...

# 使用 repack 将权重转为 Marlin 格式
b_q_weight_repacked = gptq_marlin_repack(b_q_weight, perm, size_k, size_n, 4)

# 创建工作空间
sms = torch.cuda.get_device_properties(0).multi_processor_count
workspace = torch.zeros(sms, dtype=torch.int32, device="cuda")

# 执行 Marlin GEMM
output = marlin_gemm(
    a=a,
    c=None,                 # 输出 tensor（可选）
    b_q_weight=b_q_weight_repacked,
    b_bias=None,            # bias（可选）
    b_scales=b_scales,      # 量化 scale
    a_scales=None,
    global_scale=None,
    b_zeros=None,
    g_idx=None,
    perm=None,
    workspace=workspace,
    b_q_type=kU4B8,         # 量化类型
    size_m=size_m,
    size_n=size_n,
    size_k=size_k,
    is_k_full=True,
    use_atomic_add=False,
    use_fp32_reduce=True,
    is_zp_float=False,
)

print(output.shape)  # torch.Size([16, 256])
```

## 支持的量化类型

| 常量 | C++ 类型 | 说明 |
|------|---------|------|
| `kU4` | `uint4` | AWQ INT4 |
| `kU4B8` | `uint4b8` | GPTQ INT4（bias=8） |
| `kU8B128` | `uint8b128` | GPTQ INT8（bias=128） |
| `kFE4M3fn` | `float8_e4m3fn` | FP8（E4M3） |
| `kFE2M1f` | `float4_e2m1f` | NVFP4 / MXFP4 |
| `kFE8M0fnu` | `float8_e8m0fnu` | MXFP 共享 scale 类型 |
| `kFloat16` | `float16` | FP16 累加器 |
| `kBFloat16` | `bfloat16` | BF16 累加器 |
| `kS8` | `int8` | INT8 激活 |

## API

### marlin_gemm

Marlin GEMM 核心接口：`C = A @ dequant(B)`。

```python
def marlin_gemm(
    a: Tensor,                 # 激活 [size_m, size_k]，FP16/BF16/FP8/INT8
    c: Optional[Tensor],       # 输出 [size_m, size_n]（可为 None）
    b_q_weight: Tensor,        # Marlin 格式量化权重
    b_bias: Optional[Tensor],  # bias [size_n]（可为 None）
    b_scales: Tensor,          # 量化 scale [num_groups, size_n]
    a_scales: Optional[Tensor],# 激活 scale（INT8 激活时需要）
    global_scale: Optional[Tensor],  # NVFP4 全局 scale
    b_zeros: Optional[Tensor], # AWQ zero point
    g_idx: Optional[Tensor],   # act_order group index
    perm: Optional[Tensor],    # act_order permutation
    workspace: Tensor,         # 工作空间 [num_sms]，int32
    b_q_type: ScalarType,      # 权重量化类型
    size_m: int,               # M 维度
    size_n: int,               # N 维度
    size_k: int,               # K 维度
    is_k_full: bool = True,
    use_atomic_add: bool = False,
    use_fp32_reduce: bool = False,
    is_zp_float: bool = False,
) -> Tensor
```

### gptq_marlin_repack

将 GPTQ 格式量化权重重排为 Marlin 格式。

```python
def gptq_marlin_repack(
    b_q_weight: Tensor,   # [K/pack_factor, N]
    perm: Tensor,          # act_order permutation（可为空）
    size_k: int,
    size_n: int,
    num_bits: int,         # 量化位宽（4 或 8）
) -> Tensor               # [K/16, N*16/pack_factor]
```

### awq_marlin_repack

将 AWQ 格式量化权重重排为 Marlin 格式。

```python
def awq_marlin_repack(
    b_q_weight: Tensor,   # [K, N/pack_factor]
    size_k: int,
    size_n: int,
    num_bits: int,         # 量化位宽（4 或 8）
) -> Tensor               # [K/16, N*16/pack_factor]
```

### marlin_int4_fp8_preprocess

将 INT4 权重预处理为 FP8 友好的布局。

```python
def marlin_int4_fp8_preprocess(
    qweight: Tensor,                # 量化权重
    qzeros_or_none: Optional[Tensor] = None,  # AWQ zero point（可选）
    inplace: bool = False,
) -> Tensor
```

## 运行测试

```bash
cd marlin-cuda
pip install pytest
python -m pytest tests/test_marlin_gemm.py -v
```

## 架构说明

```
marlin-cuda/
├── csrc/                         # CUDA 内核源码
│   ├── marlin.cu                 # 宿主调度 + torch op 注册
│   ├── marlin.cuh                # GPU kernel（核心计算逻辑）
│   ├── marlin_template.h         # 模板参数调度
│   ├── kernel.h / kernel_selector.h  # kernel 选择器
│   ├── marlin_dtypes.cuh         # 数据类型工具
│   ├── marlin_mma.h              # MMA 指令封装
│   ├── dequant.h                 # 反量化逻辑
│   ├── scalar_type.hpp           # C++ ScalarType 定义
│   ├── registration.h            # Torch 库注册宏
│   ├── generate_kernels.py       # 模板实例化代码生成器
│   ├── gptq_marlin_repack.cu     # GPTQ 权重重排
│   ├── awq_marlin_repack.cu      # AWQ 权重重排
│   ├── marlin_int4_fp8_preprocess.cu  # INT4→FP8 预处理
│   └── sm*_kernel_*.cu           # 自动生成的模板实例化
├── marlin_cuda/                  # Python 包
│   ├── __init__.py               # torch.library schema 注册 + .so 加载
│   ├── _ops.py                   # Python API 封装
│   ├── scalar_type.py            # Python ScalarType 实现
│   └── marlin_cuda.so            # 编译产物
├── tests/
│   └── test_marlin_gemm.py       # 测试（预处理 / GEMM / 重排）
├── CMakeLists.txt                # CMake 构建配置
├── setup.py                      # pip 安装入口
├── build_kernel.py               # 直接 nvcc 编译脚本
└── pyproject.toml
```

内核通过 `generate_kernels.py` 自动生成模板实例化（Jinja2 模板 + 排列组合），再经由 `kernel_selector.h` 中的 if-else 链做运行时 dispatch。编译目标为 SM89 PTX，SM120 通过 GPU 的 PTX 向下兼容能力直接执行。
