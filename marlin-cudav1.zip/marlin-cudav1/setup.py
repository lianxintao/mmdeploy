import os
import subprocess
import sys
from pathlib import Path

from setuptools import Extension, find_packages, setup
from setuptools.command.build_ext import build_ext


class CMakeBuildExtension(build_ext):
    """Custom build_ext that invokes CMake to build the CUDA extension."""

    def run(self):
        for ext in self.extensions:
            self.build_cmake(ext)

    def build_cmake(self, ext):
        import torch

        extdir = Path(self.get_ext_fullpath(ext.name)).parent.resolve()
        srcdir = Path(__file__).parent.resolve()
        build_dir = Path(self.build_temp).resolve() / "cmake_build"
        build_dir.mkdir(parents=True, exist_ok=True)

        # Find torch cmake modules
        torch_cmake_dir = Path(torch.utils.cmake_prefix_path)
        if not (torch_cmake_dir / "TorchConfig.cmake").exists():
            # Fallback: try the torch share/cmake directory
            torch_cmake_dir = Path(torch.__file__).parent / "share" / "cmake"

        cmake_args = [
            f"-DCMAKE_PREFIX_PATH={torch_cmake_dir}",
            f"-DPYTHON_EXECUTABLE={sys.executable}",
            f"-DCMAKE_LIBRARY_OUTPUT_DIRECTORY={extdir}",
            "-DCMAKE_BUILD_TYPE=Release",
        ]

        # CMake configure
        subprocess.check_call(
            ["cmake", str(srcdir)] + cmake_args,
            cwd=str(build_dir),
        )

        # CMake build — respect MAX_JOBS env var, default to 2
        max_jobs = os.environ.get("MAX_JOBS", "2")
        subprocess.check_call(
            ["cmake", "--build", ".", "-j", max_jobs],
            cwd=str(build_dir),
        )

        # Copy the built .so to the package directory
        so_candidates = list(build_dir.glob("marlin_cuda/*.so"))
        if not so_candidates:
            so_candidates = list(build_dir.glob("**/marlin_cuda.so"))
        if so_candidates:
            dest = extdir / "marlin_cuda.so"
            import shutil
            shutil.copy2(str(so_candidates[0]), str(dest))


class MarlinCudaExtension(Extension):
    """Placeholder extension that triggers CMake build."""
    def __init__(self):
        super().__init__("marlin_cuda._marlin_cuda", sources=[])


setup(
    name="marlin-cuda",
    version="0.1.0",
    packages=find_packages(include=["marlin_cuda", "marlin_cuda.*"]),
    ext_modules=[MarlinCudaExtension()],
    cmdclass={"build_ext": CMakeBuildExtension},
    python_requires=">=3.10",
    install_requires=[
        "torch>=2.0.0",
    ],
)
