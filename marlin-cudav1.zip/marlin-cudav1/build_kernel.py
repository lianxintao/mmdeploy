"""Build the marlin_cuda shared library directly using nvcc and torch.

Usage: python build_kernel.py
"""

import glob
import os
import subprocess
import sys
import sysconfig
from pathlib import Path


def get_torch_lib_dir():
    import torch
    return Path(torch.__file__).parent / "lib"


def main():
    import torch
    from torch.utils.cpp_extension import include_paths as torch_include_paths

    cc = torch.cuda.get_device_capability()
    arch = f"{cc[0]}{cc[1]}"
    arch_dot = f"{cc[0]}.{cc[1]}"
    print(f"Building for CUDA architecture: {arch_dot} (sm_{arch})")

    # Run kernel generation
    csrc_dir = Path(__file__).parent / "csrc"
    gen_script = csrc_dir / "generate_kernels.py"
    print(f"Generating kernel instantiations...")
    result = subprocess.run(
        [sys.executable, str(gen_script), arch_dot],
        capture_output=True, text=True
    )
    if result.returncode != 0 and not result.stdout:
        print(f"Generation stderr: {result.stderr}")
    print(f"Generation stdout: {result.stdout.strip()[:500]}")

    # Collect source files
    source_files = [
        str(csrc_dir / f) for f in [
            "marlin.cu",
            "marlin_int4_fp8_preprocess.cu",
            "gptq_marlin_repack.cu",
            "awq_marlin_repack.cu",
        ]
    ]
    for pattern in ["sm80_kernel_*.cu", "sm75_kernel_*.cu", "sm89_kernel_*.cu"]:
        for f in glob.glob(str(csrc_dir / pattern)):
            source_files.append(f)

    print(f"Found {len(source_files)} source files")

    # Build flags
    cuda_home = os.environ.get("CUDA_HOME", "/usr/local/cuda")
    nvcc = os.path.join(cuda_home, "bin", "nvcc")
    if not os.path.exists(nvcc):
        nvcc = "nvcc"

    torch_lib = get_torch_lib_dir()
    torch_include = list(torch_include_paths())

    include_dirs = [str(csrc_dir), *torch_include]
    include_flags = " ".join(f'-I"{d}"' for d in include_dirs)

    gencode_flags = [
        f"-gencode=arch=compute_{arch},code=sm_{arch}",
    ]

    cflags = (
        "-shared -O3 -std=c++17 "
        f"--compiler-options '-fPIC -O3' "
        f"{' '.join(gencode_flags)} "
        f"-t=4 "
    )

    # Additional flags for CUDA >= 12.8
    cuda_ver = torch.version.cuda
    if cuda_ver:
        major, minor = map(int, cuda_ver.split(".")[:2])
        if major * 10 + minor >= 128:
            cflags += " -static-global-template-stub=false"

    output_dir = Path(__file__).parent / "marlin_cuda"
    output_dir.mkdir(exist_ok=True)
    output_path = output_dir / "marlin_cuda.so"

    sources_str = " ".join(f'"{s}"' for s in source_files)
    lib_dir_flag = f'-L"{torch_lib}"'
    rpath_flag = f'-Wl,-rpath,"{torch_lib}"'

    cmd = (
        f'{nvcc} {cflags} {include_flags} '
        f'-o "{output_path}" '
        f'{sources_str} '
        f'{lib_dir_flag} {rpath_flag} '
        f'-ltorch -ltorch_cpu -ltorch_cuda -lc10 -lc10_cuda'
    )

    print(f"Building with nvcc...")
    print(f"Command: {cmd[:200]}...")

    result = subprocess.run(cmd, shell=True, executable="/bin/bash",
                          cwd=str(csrc_dir))
    if result.returncode != 0:
        print(f"\nBuild FAILED (exit={result.returncode})")
        sys.exit(result.returncode)

    print(f"Build successful: {output_path}")
    print(f"File size: {output_path.stat().st_size / 1024 / 1024:.1f} MB")


if __name__ == "__main__":
    main()
