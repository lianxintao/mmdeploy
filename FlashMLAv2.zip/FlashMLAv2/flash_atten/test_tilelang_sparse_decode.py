"""
Test script for flash_mla_sparse_decode_tilelang (TileLang SM89 kernel).

Constraints:
  - H must be divisible by 16 (H_PER_BLOCK)
  - topk must be divisible by 64 (block_I)

Usage:
    cd /home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA/flash_atten
    python test_tilelang_sparse_decode.py
"""

import sys, os, time
from typing import Optional, Tuple

import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from triton_kernel import flash_mla_sparse_decode_triton
from tilelang_sm89_kernel import flash_mla_sparse_decode_tilelang

# ── DSv4 layout constants ──────────────────────────────────────────────────
D_NOPE = 448
D_ROPE = 64
D_QK = D_NOPE + D_ROPE   # 512
D_V = 512
TOKEN_DATA_STRIDE = 576
SCALE_STRIDE = 8
GROUP_SIZE = 64
NUM_GROUPS = D_NOPE // GROUP_SIZE  # 7


# ═══════════════════════════════════════════════════════════════════════════
# Reference: BF16 sparse attention (same as triton test)
# ═══════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def ref_sparse_decode_single(
    q: torch.Tensor,            # [B, 1, H, D] bf16
    kv_flat: torch.Tensor,      # [total_tokens, D] bf16
    indices: torch.Tensor,      # [B, topk] int32
    topk_length: Optional[torch.Tensor],
    softmax_scale: float,
    attn_sink: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    B, _, H, D = q.shape
    q2 = q[:, 0].float() * softmax_scale

    topk = indices.shape[1]
    out = torch.zeros(B, H, D, dtype=torch.float32, device=q.device)
    lse = torch.zeros(B, H, dtype=torch.float32, device=q.device)

    for b in range(B):
        cur_topk = int(topk_length[b].item()) if topk_length is not None else topk
        idx = indices[b]
        valid = idx >= 0

        if kv_flat.shape[0] == 0 or not valid.any():
            out[b] = 0.0
            lse[b] = float("-inf")
            continue

        idx_clamped = idx.clamp(min=0)
        kv = kv_flat[idx_clamped].float()

        scores = q2[b] @ kv.T  # [H, D] @ [D, topk] -> [H, topk]
        scores[:, ~valid] = float("-inf")
        if cur_topk < topk:
            scores[:, cur_topk:] = float("-inf")

        max_s = scores.max(dim=-1, keepdim=True).values
        exp_s = torch.exp(scores - max_s)
        sum_s = exp_s.sum(dim=-1, keepdim=True).clamp(min=1e-20)

        out[b] = (exp_s.unsqueeze(-1) * kv.unsqueeze(0)).sum(dim=1) / sum_s
        lse[b] = (max_s.squeeze(-1) + torch.log(sum_s.squeeze(-1)))

    if attn_sink is not None:
        sink = attn_sink.float().unsqueeze(0).expand(B, -1)  # [H] -> [B, H]
        combined_lse = torch.logaddexp(lse, sink)
        w = torch.where(lse > -1e20, torch.exp(lse - combined_lse), torch.zeros_like(lse))
        out = out * w.unsqueeze(-1)
        lse = combined_lse

    return out.to(torch.bfloat16).unsqueeze(1), lse.unsqueeze(1)


# ═══════════════════════════════════════════════════════════════════════════
# KV cache builder (same as triton test)
# ═══════════════════════════════════════════════════════════════════════════

def build_fp8_kv_cache(
    kv_bf16: torch.Tensor,
    page_size: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    total_tokens = kv_bf16.shape[0]
    num_pages = (total_tokens + page_size - 1) // page_size
    pad_len = num_pages * page_size - total_tokens

    if pad_len > 0:
        kv_bf16 = torch.cat([
            kv_bf16,
            torch.zeros(pad_len, D_QK, dtype=torch.bfloat16, device=kv_bf16.device),
        ], dim=0)

    N = num_pages * page_size
    kv_bf16 = kv_bf16.view(N, D_QK).clone()
    nope_bf16 = kv_bf16[:, :D_NOPE]
    rope_bf16 = kv_bf16[:, D_NOPE:]

    nope_fp8 = torch.empty(N, D_NOPE, dtype=torch.float8_e4m3fn, device=kv_bf16.device)
    scales_ue8m0 = torch.empty(N, NUM_GROUPS, dtype=torch.uint8, device=kv_bf16.device)

    for g in range(NUM_GROUPS):
        g_start = g * GROUP_SIZE
        g_end = g_start + GROUP_SIZE
        chunk = nope_bf16[:, g_start:g_end].float()

        amax = chunk.abs().max(dim=-1).values.clamp(min=1e-8)
        scale = amax / 448.0

        nope_fp8[:, g_start:g_end] = (chunk / scale.unsqueeze(-1)).to(torch.float8_e4m3fn)

        raw = torch.clamp(scale.log2().ceil() + 127, 1, 254).to(torch.uint8)
        scales_ue8m0[:, g] = raw

    data_per_page = page_size * TOKEN_DATA_STRIDE
    scale_per_page = page_size * SCALE_STRIDE
    page_total = data_per_page + scale_per_page

    raw = torch.empty(num_pages * page_total, dtype=torch.uint8, device=kv_bf16.device)

    for p in range(num_pages):
        page_off = p * page_total
        data_off = page_off
        scale_off = page_off + data_per_page

        for t in range(page_size):
            tidx = p * page_size + t

            nope_bytes = nope_fp8[tidx].view(torch.uint8)
            raw[data_off + t * TOKEN_DATA_STRIDE:
                data_off + t * TOKEN_DATA_STRIDE + D_NOPE].copy_(nope_bytes)

            rope_bytes = rope_bf16[tidx].view(torch.uint8)
            raw[data_off + t * TOKEN_DATA_STRIDE + D_NOPE:
                data_off + (t + 1) * TOKEN_DATA_STRIDE].copy_(rope_bytes)

            raw[scale_off + t * SCALE_STRIDE:
                scale_off + t * SCALE_STRIDE + NUM_GROUPS].copy_(scales_ue8m0[tidx])
            raw[scale_off + t * SCALE_STRIDE + NUM_GROUPS] = 0

    k_cache = raw.view(torch.float8_e4m3fn).view(
        num_pages, page_size, 1, TOKEN_DATA_STRIDE + SCALE_STRIDE)

    return k_cache, kv_bf16


# ═══════════════════════════════════════════════════════════════════════════
# Test runner
# ═══════════════════════════════════════════════════════════════════════════

def run_test_with_kernel(
    kernel_fn,
    kernel_name: str,
    B: int, H: int,
    total_kv_tokens: int, topk: int,
    page_size: int = 64,
    extra_kv_tokens: Optional[int] = None,
    extra_topk: Optional[int] = None,
    use_attn_sink: bool = True,
    use_topk_len: bool = False,
    verbose: bool = True,
) -> Tuple[bool, float, float]:
    """Run one test with a given kernel function."""
    device = torch.device("cuda:0")
    softmax_scale = D_QK ** -0.5

    # --- Generate Q: [B, 1, H, D_QK] ---
    q = torch.randn(B, 1, H, D_QK, dtype=torch.bfloat16, device=device) / 10
    q = q + (torch.rand(B, 1, H, D_QK, device=device) - 0.5) / 50

    # --- Generate KV ---
    kv_bf16 = torch.randn(total_kv_tokens, D_QK, dtype=torch.bfloat16, device=device) / 10
    kv_bf16 = kv_bf16 + (torch.rand(total_kv_tokens, D_QK, device=device) - 0.5) / 50

    k_cache, kv_bf16_padded = build_fp8_kv_cache(kv_bf16, page_size)
    total_padded = kv_bf16_padded.shape[0]

    # --- Generate indices ---
    flat_indices = torch.full((B, topk), -1, dtype=torch.int32, device=device)
    for b in range(B):
        n_valid = min(total_padded, topk)
        perm = torch.randperm(total_padded, device=device)[:n_valid]
        flat_indices[b, :n_valid] = perm.to(torch.int32)
        flat_indices[b, :n_valid] = flat_indices[b, torch.randperm(n_valid, device=device)]

    indices = flat_indices

    # --- Topk length ---
    topk_length = None
    if use_topk_len:
        topk_length = torch.randint(1, topk + 1, (B,), dtype=torch.int32, device=device)

    # --- Attn sink ---
    attn_sink = None
    if use_attn_sink:
        # attn_sink shape: [H] — one scalar per head, shared across batch
        attn_sink = torch.randn(H, dtype=torch.float32, device=device)

    # --- Extra cache ---
    extra_k_cache = None
    extra_indices = None
    extra_topk_length = None
    extra_kv_bf16_padded = None
    if extra_kv_tokens is not None and extra_topk is not None:
        extra_kv_bf16 = torch.randn(extra_kv_tokens, D_QK, dtype=torch.bfloat16, device=device) / 10
        extra_k_cache, extra_kv_bf16_padded = build_fp8_kv_cache(extra_kv_bf16, page_size)
        extra_total_padded = extra_kv_bf16_padded.shape[0]

        extra_indices = torch.full((B, extra_topk), -1, dtype=torch.int32, device=device)
        for b in range(B):
            n_extra = min(extra_total_padded, extra_topk)
            perm = torch.randperm(extra_total_padded, device=device)[:n_extra]
            extra_indices[b, :n_extra] = perm.to(torch.int32)

    # --- Run kernel ---
    out, lse = kernel_fn(
        q, k_cache, indices, topk_length, attn_sink,
        D_V, softmax_scale,
        extra_k_cache, extra_indices, extra_topk_length,
    )

    # --- Reference ---
    out_ref, lse_ref = ref_sparse_decode_single(
        q, kv_bf16_padded, indices, topk_length,
        softmax_scale, attn_sink,
    )

    if extra_k_cache is not None:
        out_ref2, lse_ref2 = ref_sparse_decode_single(
            q, extra_kv_bf16_padded, extra_indices, extra_topk_length,
            softmax_scale, None,
        )
        max_lse = torch.maximum(lse_ref, lse_ref2)
        w1 = torch.where(lse_ref > -1e20,
                         torch.exp(lse_ref - max_lse),
                         torch.zeros_like(lse_ref))
        w2 = torch.where(lse_ref2 > -1e20,
                         torch.exp(lse_ref2 - max_lse),
                         torch.zeros_like(lse_ref2))
        total = (w1 + w2).clamp(min=1e-20)
        out_ref = (w1.unsqueeze(-1) * out_ref.float() + w2.unsqueeze(-1) * out_ref2.float()) / total.unsqueeze(-1)
        lse_ref = max_lse + torch.log(total)
        out_ref = out_ref.to(torch.bfloat16)

    # --- Compare ---
    lse_for_cmp = lse.squeeze(-1).unsqueeze(1)
    lse_ref_for_cmp = lse_ref

    out_diff = (out.float() - out_ref.float()).abs()
    lse_diff = (lse_for_cmp.float() - lse_ref_for_cmp.float()).abs()
    lse_diff = torch.nan_to_num(lse_diff, nan=0.0, posinf=float("inf"), neginf=0.0)

    out_max = out_diff.max().item()
    out_mean = out_diff.mean().item()
    lse_max = lse_diff.max().item()
    lse_mean = lse_diff.mean().item()

    OUT_ABS_TOL = 0.20
    LSE_ABS_TOL = 0.30

    out_ok = out_max < OUT_ABS_TOL
    lse_ok = lse_max < LSE_ABS_TOL
    ok = out_ok and lse_ok

    if verbose:
        status = "PASS" if ok else "FAIL"
        print(f"    [{kernel_name}] out max={out_max:.4e} mean={out_mean:.4e}  "
              f"lse max={lse_max:.4e} mean={lse_mean:.4e}  [{status}]")

    return ok, out_max, lse_max


def benchmark_kernel(kernel_fn, name: str, q, k_cache, indices, topk_length, attn_sink,
                     softmax_scale, extra_k_cache, extra_indices, extra_topk_length,
                     num_runs: int = 100):
    """Benchmark a kernel and report ms/iter."""
    # Warmup
    for _ in range(5):
        kernel_fn(q, k_cache, indices, topk_length, attn_sink,
                  D_V, softmax_scale,
                  extra_k_cache, extra_indices, extra_topk_length)
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_runs):
        kernel_fn(q, k_cache, indices, topk_length, attn_sink,
                  D_V, softmax_scale,
                  extra_k_cache, extra_indices, extra_topk_length)
    torch.cuda.synchronize()
    elapsed_ms = (time.perf_counter() - t0) * 1000 / num_runs
    print(f"    [{name}] {elapsed_ms:.3f} ms/iter")
    return elapsed_ms


# ═══════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════

def main():
    if not torch.cuda.is_available():
        print("CUDA not available. Exiting.")
        return

    device = torch.device("cuda:0")
    torch.set_default_dtype(torch.bfloat16)
    torch.set_default_device(device)
    torch.cuda.set_device(device)
    torch.set_float32_matmul_precision("high")

    print("=" * 64)
    print("TileLang Sparse Decode Test Suite (DeepSeekV4 Config)")
    print(f"  d_qk={D_QK}  d_nope={D_NOPE}  d_rope={D_ROPE}  d_v={D_V}")
    print(f"  CUDA Device: {torch.cuda.get_device_name(0)}")
    print("=" * 64)

    # Two kernels to compare
    kernels = [
        (flash_mla_sparse_decode_triton, "triton"),
        (flash_mla_sparse_decode_tilelang, "tilelang"),
    ]

    # ── Correctness tests: H % 16 == 0, topk % 64 == 0 ──────────────
    test_cases = []

    for H in [16, 64]:
        for B in [1, 4]:
            for (kv_tokens, topk, pg_size) in [
                (256, 64, 2),
                (512, 64, 64),
                (1024, 128, 4),
                (512, 64, 4),
                (1024, 128, 64),
            ]:
                test_cases.append(dict(
                    B=B, H=H, total_kv_tokens=kv_tokens, topk=topk,
                    page_size=pg_size,
                    use_attn_sink=True, use_topk_len=True,
                ))

    # H=128 (larger)
    for B in [1, 4]:
        for (kv_tokens, topk, pg_size) in [
            (1024, 128, 4),
            (512, 64, 64),
        ]:
            test_cases.append(dict(
                B=B, H=128, total_kv_tokens=kv_tokens, topk=topk,
                page_size=pg_size,
                use_attn_sink=True, use_topk_len=True,
            ))

    # Extra KV cache (B=1 and B=4)
    for B in [1, 4]:
        test_cases.append(dict(
            B=B, H=64, total_kv_tokens=512, topk=64, page_size=4,
            extra_kv_tokens=512, extra_topk=64,
            use_attn_sink=True, use_topk_len=True,
        ))

    # Corner cases
    test_cases.append(dict(
        B=2, H=32, total_kv_tokens=256, topk=64, page_size=4,
        use_attn_sink=False, use_topk_len=False,
    ))
    test_cases.append(dict(
        B=8, H=16, total_kv_tokens=128, topk=64, page_size=2,
        use_attn_sink=True, use_topk_len=False,
    ))

    print(f"\nRunning {len(test_cases)} test configs x {len(kernels)} kernels...\n")

    # Track last partial kernel key to avoid TileLang JIT cache collisions
    import shutil, itertools
    last_partial_key = None

    for i, tc in enumerate(test_cases):
        # Clear TileLang cache when kernel signature changes (avoids JIT cache key collision)
        partial_have = tc.get('use_topk_len', True)
        if i > 0:
            new_key = (tc['H'], tc['topk'], partial_have)
            if new_key != last_partial_key:
                cache_dir = os.path.expanduser('~/.tilelang/cache')
                if os.path.exists(cache_dir):
                    shutil.rmtree(cache_dir)
        last_partial_key = (tc['H'], tc['topk'], tc.get('use_topk_len', True))

        print(f"[{i+1:3d}/{len(test_cases)}] B={tc['B']} H={tc['H']} "
              f"topk={tc['topk']} page={tc['page_size']}"
              + (f" extra_topk={tc.get('extra_topk')}" if tc.get('extra_topk') else ""),
              flush=True)

        for kernel_fn, name in kernels:
            try:
                ok, out_max, lse_max = run_test_with_kernel(
                    kernel_fn, name, **tc, verbose=True)
            except Exception as e:
                print(f"    [{name}] EXCEPTION: {e}")
                import traceback
                traceback.print_exc()

    # ── Cross-kernel comparison: TileLang vs Triton ────────────────────────
    print("\n" + "=" * 64)
    print("Cross-kernel comparison (TileLang vs Triton output)")
    print("=" * 64)

    for B, H, topk, kv_tokens in [
        (1, 64, 64, 512),
        (1, 128, 128, 1024),
    ]:
        print(f"\n  B={B} H={H} topk={topk} kv={kv_tokens}:")
        device = torch.device("cuda:0")
        softmax_scale = D_QK ** -0.5

        q = torch.randn(B, 1, H, D_QK, dtype=torch.bfloat16, device=device) / 10
        kv_bf16 = torch.randn(kv_tokens, D_QK, dtype=torch.bfloat16, device=device) / 10
        k_cache, _ = build_fp8_kv_cache(kv_bf16, 64)
        total_padded = k_cache.shape[0] * 64

        indices = torch.full((B, topk), -1, dtype=torch.int32, device=device)
        for b in range(B):
            n_valid = min(total_padded, topk)
            perm = torch.randperm(total_padded, device=device)[:n_valid]
            indices[b, :n_valid] = perm.to(torch.int32)

        out_triton, lse_triton = flash_mla_sparse_decode_triton(
            q, k_cache, indices, None, None, D_V, softmax_scale)
        out_tilelang, lse_tilelang = flash_mla_sparse_decode_tilelang(
            q, k_cache, indices, None, None, D_V, softmax_scale)

        out_diff = (out_triton.float() - out_tilelang.float()).abs()
        lse_diff = (lse_triton.float().squeeze(-1).unsqueeze(1) -
                    lse_tilelang.float().squeeze(-1).unsqueeze(1)).abs()

        print(f"    out diff: max={out_diff.max():.4e} mean={out_diff.mean():.4e}")
        print(f"    lse diff: max={lse_diff.max():.4e} mean={lse_diff.mean():.4e}")

    # ── Performance comparison ────────────────────────────────────────────
    print("\n" + "=" * 64)
    print("Performance comparison")
    print("=" * 64)

    bench_cases = [
        # Small: easy to compare
        {"B": 1, "H": 64, "topk": 64, "kv_tokens": 1024, "page_size": 64,
         "use_attn_sink": False, "extra": False},
        # Medium
        {"B": 1, "H": 64, "topk": 128, "kv_tokens": 4096, "page_size": 64,
         "use_attn_sink": False, "extra": False},
        # Large
        {"B": 1, "H": 128, "topk": 256, "kv_tokens": 8192, "page_size": 64,
         "use_attn_sink": False, "extra": False},
    ]

    for tc in bench_cases:
        device = torch.device("cuda:0")
        softmax_scale = D_QK ** -0.5

        q = torch.randn(tc["B"], 1, tc["H"], D_QK, dtype=torch.bfloat16, device=device) / 10
        kv_bf16 = torch.randn(tc["kv_tokens"], D_QK, dtype=torch.bfloat16, device=device) / 10
        k_cache, _ = build_fp8_kv_cache(kv_bf16, tc["page_size"])
        total_padded = k_cache.shape[0] * tc["page_size"]

        indices = torch.full((tc["B"], tc["topk"]), -1, dtype=torch.int32, device=device)
        for b in range(tc["B"]):
            n_valid = min(total_padded, tc["topk"])
            perm = torch.randperm(total_padded, device=device)[:n_valid]
            indices[b, :n_valid] = perm.to(torch.int32)

        attn_sink = torch.randn(tc["H"], dtype=torch.float32, device=device) if tc["use_attn_sink"] else None
        extra_k = extra_i = extra_tl = None

        print(f"\n  B={tc['B']} H={tc['H']} topk={tc['topk']} kv={tc['kv_tokens']}:")
        b1 = benchmark_kernel(
            flash_mla_sparse_decode_triton, "triton",
            q, k_cache, indices, None, attn_sink, softmax_scale,
            extra_k, extra_i, extra_tl, num_runs=50)
        b2 = benchmark_kernel(
            flash_mla_sparse_decode_tilelang, "tilelang",
            q, k_cache, indices, None, attn_sink, softmax_scale,
            extra_k, extra_i, extra_tl, num_runs=50)
        print(f"    speedup: {b1/b2:.2f}x" + (" (tilelang faster)" if b2 < b1 else " (triton faster)"))

    print("\n" + "=" * 64)
    print("Done.")


if __name__ == "__main__":
    main()
