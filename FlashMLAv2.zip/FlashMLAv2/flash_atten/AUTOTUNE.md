# Triton Kernel Autotune 指南

## 工作原理

`_tiled_sparse_decode_kernel` 使用 `@triton.autotune` 装饰器，首次遇到新的 `(topk_rounded, H, page_size)` 组合时，Triton 会：

1. 对所有 config 逐个 benchmark
2. 选出最快的 config
3. 缓存结果到 `~/.triton/cache/`

之后的调用直接使用缓存结果，不再重复 benchmark。

## 当前 Autotune 搜索空间

```python
# triton_kernel.py:43-66
BLOCK_T  ∈ {16, 32, 64, 128}     # 每 tile 处理的 token 数
num_warps ∈ {4, 8, 16}           # 每个 block 的 warp 数 (×32 线程)
num_stages ∈ {1, 2, 3}           # 流水线深度
```

搜索 Key: `(topk_rounded, H, page_size)`

## 运行 Autotune

### 方式 1：直接跑测试（自动触发）

```bash
cd /home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA/flash_atten

# 运行测试脚本，首次遇到新 key 组合会自动 benchmark
python test_triton_sparse_decode.py
```

测试会覆盖多种 `(topk, H, page_size)` 组合，autotune 会为每种组合找到最优 config。

### 方式 2：写最小触发脚本

```python
import torch
from triton_kernel import flash_mla_sparse_decode_triton

# 指定你想调优的 DSv4 配置
B, H, D, topk, page_size = 74, 128, 512, 2048, 64
total_tokens = 32768

device = torch.device("cuda:0")
q = torch.randn(B, 1, H, D, dtype=torch.bfloat16, device=device)

# 模拟 FP8 KV cache（格式见 test_triton_sparse_decode.py 中的 build_fp8_kv_cache）
k_cache = torch.randn(total_tokens // page_size, page_size, 1, 584,
                      dtype=torch.float8_e4m3fn, device=device)
indices = torch.randint(0, total_tokens, (B, topk), dtype=torch.int32, device=device)

# 第一次调用：触发 autotune benchmark（较慢）
# 之后调用：使用缓存结果（快）
for _ in range(5):
    out, lse = flash_mla_sparse_decode_triton(
        q, k_cache, indices, None, None, 512, D**-0.5)
torch.cuda.synchronize()
print("Autotune 完成")
```

### 方式 3：清缓存重跑

```bash
# 清空 Triton 缓存
rm -rf ~/.triton/cache/

# 重新运行，强制重新 benchmark
python test_triton_sparse_decode.py
```

## 查看 Autotune 结果

```bash
# 查看所有编译过的 config 变体
python3 -c "
import json, os, glob
from collections import Counter

configs = Counter()
for d in glob.glob(os.path.expanduser('~/.triton/cache/*/')):
    jf = os.path.join(d, '_tiled_sparse_decode_kernel.json')
    if not os.path.exists(jf):
        continue
    with open(jf) as fp:
        data = json.load(fp)
    nw = data.get('num_warps', '?')
    ns = data.get('num_stages', '?')
    smem = data.get('shared', 0)
    # smem 大小近似反映 BLOCK_T: 8KB→16, 16KB→32, 32KB→64, 64KB→128
    if smem >= 60000: bt = 128
    elif smem >= 30000: bt = 64
    elif smem >= 15000: bt = 32
    else: bt = 16
    configs[(bt, nw, ns)] += 1

print('BLOCK_T  num_warps  num_stages  count')
for (bt, nw, ns), c in sorted(configs.items()):
    print(f'  {bt:3d}      {nw:2d}          {ns:2d}        {c}')
"
```

## 添加新 Config

编辑 `triton_kernel.py` 第 44-62 行的 configs 列表：

```python
configs=[
    # 添加你的新 config，格式：
    triton.Config({"BLOCK_T": <tokens>}, num_warps=<2的幂>, num_stages=<1-4>),
    ...
]
```

**约束**：
- `num_warps` 必须是 2 的幂 (4, 8, 16, 32)
- `num_stages` 范围 1-4
- BLOCK_T 越大 → 寄存器压力越大，需要更多 warp 分担
- BLOCK_T 小 + warp 多 → 浪费线程资源

## 注意事项

- Autotune 只在**首次调用某个 key 组合**时触发，后续走缓存
- Triton 版本升级后可能需要清缓存 (`rm -rf ~/.triton/cache/`)
- `reset_to_zero=["O_ptr", "LSE_ptr"]` 确保每个 config 公平对比
- 生产部署前建议在**目标 GPU 上**跑一轮 autotune（不同 GPU 最优参数不同）
