"""
TileLang SM89 sparse MLA decode kernel — "sparse gather → dense GEMM" architecture.

Key design (industry-standard approach for sparse attention on Tensor Cores):
  1. Static unrolling: 4 nope tiles × 128 dims + 1 rope tile × 64 dims
  2. Tensorized shared memory: T.alloc_shared([M,N]) — no pointer arithmetic
  3. Sparse gather → dense tile: block_I=64 tokens → [64, D] dense → T.gemm
  4. Split partial + combine: break topk into groups, LSE-weighted merge

Interface: drop-in compatible with flash_mla_sparse_decode_triton.

DSv4 config: d_qk=512 (nope=448→512 pad, rope=64), d_v=512, FP8 KV cache.
"""

from typing import Optional, Tuple
import torch
import tilelang
import tilelang.language as T

# ── Pass configs (SM89: no TMA, no warp specialization) ────────────────
_PASS_CONFIGS = {
    tilelang.PassConfigKey.TL_DISABLE_TMA_LOWER: True,
    tilelang.PassConfigKey.TL_DISABLE_WARP_SPECIALIZED: True,
}
if hasattr(tilelang.PassConfigKey, "TL_ENABLE_FAST_MATH"):
    _PASS_CONFIGS[tilelang.PassConfigKey.TL_ENABLE_FAST_MATH] = False

# ── Data types ─────────────────────────────────────────────────────────
BF16  = "bfloat16"
FP8   = "float8_e4m3fn"
FP32  = "float32"
INT32 = "int32"

# ── DSv4 layout constants ──────────────────────────────────────────────
D_NOPE  = 448          # original nope dims
D_ROPE  = 64           # rope dims
D_QK    = D_NOPE + D_ROPE   # 512 (API output dim)
D_QK_PAD = 576         # nope padded 512 + rope 64 (kernel internal dim)
D_V     = 512          # value dims
NOPE_PAD = 512         # padded to 4×128 tiles
QTS     = 128          # nope tile size per group
N_GROUPS_NOPE = 4      # number of nope GEMM groups
H_PER_BLOCK = 16       # heads per CTA (Tensor Core M≥16 constraint)
BI      = 64           # KV tokens per inner iteration (block_I)
LOG2E   = 1.4426950408889634


# ═══════════════════════════════════════════════════════════════════════════
# KV cache preparation
# ═══════════════════════════════════════════════════════════════════════════

_kv_cache_store: dict = {}

def _prepare_kv(k_cache: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Split paged FP8 KV cache into flat (nope_fp8, scale_f32, rope_bf16).

    DSv4 layout per token (584 bytes):
      [0:448]   FP8 nope
      [448:576] BF16 rope (128 bytes = 64 vals)
      [576:584] UE8M0 scales (7 bytes + 1 pad)

    Returns:
        kv_flat:    [N, 512]  float8_e4m3fn  (nope padded 448→512)
        k_scale:    [N, 4]    float32        (7 groups merged → 4 groups)
        k_rope:     [N, 64]   bfloat16
    """
    cid = id(k_cache)
    if cid in _kv_cache_store:
        return _kv_cache_store[cid]

    num_pages, page_sz, _, bpt = k_cache.shape
    N = num_pages * page_sz

    # Access flat underlying bytes (layout: data section + scale section per page)
    page_bytes = k_cache.stride(0)  # stride(0) in float8 elements = page_sz * bpt
    total_elems = num_pages * page_bytes
    raw_fp8 = k_cache.as_strided((total_elems,), (1,))
    raw_u8 = raw_fp8.view(torch.uint8)  # 1D byte view

    data_per_page = page_sz * 576  # 576 bytes per token data (448 nope + 128 rope)
    scale_per_page = page_sz * 8  # 8 bytes per token scale
    page_total = data_per_page + scale_per_page  # page_sz * 584

    # Build flat [N, 512] FP8 nope (padded) and [N, 64] BF16 rope
    kv_flat = torch.empty(N, NOPE_PAD, dtype=torch.float8_e4m3fn, device=k_cache.device)
    k_rope = torch.empty(N, D_ROPE, dtype=torch.bfloat16, device=k_cache.device)
    scale_u8_all = torch.empty(N, 7, dtype=torch.uint8, device=k_cache.device)

    for p in range(num_pages):
        page_start = p * page_total
        data_start = page_start
        scale_start = page_start + data_per_page
        for t in range(page_sz):
            tidx = p * page_sz + t
            # Nope: bytes [t*576 : t*576+448]
            nope_start = data_start + t * 576
            kv_flat[tidx, :D_NOPE] = raw_u8[nope_start:nope_start + D_NOPE].view(torch.float8_e4m3fn)
            # Rope: bytes [t*576+448 : t*576+576] = 128 bytes = 64 BF16 values
            rope_start = data_start + t * 576 + D_NOPE
            k_rope[tidx] = raw_u8[rope_start:rope_start + D_ROPE * 2].view(torch.bfloat16)
            # Scale: bytes [page_sz*576 + t*8 : ...] = 7 UE8M0 + 1 pad
            sc_start = scale_start + t * 8
            scale_u8_all[tidx] = raw_u8[sc_start:sc_start + 7]

    # Convert UE8M0 scales to float32: 7 groups of 64
    scale_f32_7 = torch.exp2(scale_u8_all.float() - 127.0)  # [N, 7]

    # Merge 7 groups (×64 dims) → 4 groups (×128 dims)
    k_scale = torch.zeros(N, N_GROUPS_NOPE, dtype=torch.float32, device=k_cache.device)
    k_scale[:, 0] = (scale_f32_7[:, 0] + scale_f32_7[:, 1]) * 0.5
    k_scale[:, 1] = (scale_f32_7[:, 2] + scale_f32_7[:, 3]) * 0.5
    k_scale[:, 2] = (scale_f32_7[:, 4] + scale_f32_7[:, 5]) * 0.5
    k_scale[:, 3] = scale_f32_7[:, 6]

    # Cache management
    result = (kv_flat, k_scale, k_rope)
    _kv_cache_store[cid] = result
    if len(_kv_cache_store) > 8:
        oldest = next(iter(_kv_cache_store))
        del _kv_cache_store[oldest]

    return result


# ═══════════════════════════════════════════════════════════════════════════
# Partial kernel: sparse gather → dense GEMM → online softmax
# ═══════════════════════════════════════════════════════════════════════════

@tilelang.jit(out_idx=[-2, -1], pass_configs=_PASS_CONFIGS)
def _build_partial(heads: int, topk: int, inner_iter: int, have_topk_length: bool):
    """Partial attention kernel: 4-group static unroll, online softmax (log2)."""
    REPLICATE_H = heads // H_PER_BLOCK
    N_GROUPS = topk // (BI * inner_iter)

    batch   = T.symbolic("batch")
    seq_len = T.symbolic("seq_len")
    n_tokens = T.symbolic("n_tokens")

    @T.prim_func
    def main(
        q:            T.Tensor([batch, seq_len, heads, D_QK_PAD], BF16),
        kv_flat:      T.Tensor([n_tokens, NOPE_PAD], FP8),
        k_scale:      T.Tensor([n_tokens, N_GROUPS_NOPE], FP32),
        k_rope:       T.Tensor([n_tokens, D_ROPE], BF16),
        indices:      T.Tensor([batch, seq_len, 1, topk], INT32),
        topk_length:  T.Tensor([batch], INT32),
        partial_o:    T.Tensor([batch, seq_len, N_GROUPS, heads, D_QK_PAD], BF16),
        partial_lse:  T.Tensor([batch, seq_len, N_GROUPS, heads], FP32),
    ):
        with T.Kernel(batch * seq_len * REPLICATE_H, N_GROUPS, threads=256) as (bx, by):
            rep_i = bx % REPLICATE_H
            tmp   = bx // REPLICATE_H
            s_i   = tmp % seq_len
            b_i   = tmp // seq_len
            group_i = by
            H0 = rep_i * H_PER_BLOCK

            # ── Shared memory allocations ────────────────────────────
            Q_nope = T.alloc_shared([H_PER_BLOCK, NOPE_PAD], BF16)
            Q_rope = T.alloc_shared([H_PER_BLOCK, D_ROPE], BF16)
            K_fp8  = T.alloc_shared([BI, NOPE_PAD], FP8)
            K_rope_s = T.alloc_shared([BI, D_ROPE], BF16)
            K_scl  = T.alloc_shared([BI, N_GROUPS_NOPE], FP32)
            K_buf  = T.alloc_shared([BI, QTS], BF16)
            S_smem = T.alloc_shared([H_PER_BLOCK, BI], BF16)
            page_s = T.alloc_shared([BI], INT32)
            mask_s = T.alloc_shared([BI], INT32)

            # ── Fragment accumulators ─────────────────────────────────
            acc_s = T.alloc_fragment([H_PER_BLOCK, BI], FP32)
            m_i   = T.alloc_fragment([H_PER_BLOCK], FP32)
            m_prev = T.alloc_fragment([H_PER_BLOCK], FP32)
            lsum  = T.alloc_fragment([H_PER_BLOCK], FP32)
            l_i   = T.alloc_fragment([H_PER_BLOCK], FP32)
            alpha = T.alloc_fragment([H_PER_BLOCK], FP32)

            acc_g0 = T.alloc_fragment([H_PER_BLOCK, QTS], FP32)
            acc_g1 = T.alloc_fragment([H_PER_BLOCK, QTS], FP32)
            acc_g2 = T.alloc_fragment([H_PER_BLOCK, QTS], FP32)
            acc_g3 = T.alloc_fragment([H_PER_BLOCK, QTS], FP32)
            acc_r  = T.alloc_fragment([H_PER_BLOCK, D_ROPE], FP32)
            tmp_out = T.alloc_fragment([H_PER_BLOCK, QTS], FP32)

            T.fill(m_i, -(2.0 ** 30))
            T.fill(lsum, 0.0)
            T.fill(acc_g0, 0.0)
            T.fill(acc_g1, 0.0)
            T.fill(acc_g2, 0.0)
            T.fill(acc_g3, 0.0)
            T.fill(acc_r, 0.0)

            # ── Load Q into shared memory (once, constant across KV tiles) ─
            # q layout: [B, 1, H, 576] = nope padded 512 + rope 64
            T.copy(q[b_i, s_i, H0:H0 + H_PER_BLOCK, :NOPE_PAD], Q_nope)
            T.copy(q[b_i, s_i, H0:H0 + H_PER_BLOCK, NOPE_PAD:], Q_rope)

            # ── Inner iteration loop (processes inner_iter × BI tokens) ──
            for k_i in T.serial(inner_iter):
                topk_blk = group_i * inner_iter + k_i
                base = topk_blk * BI

                # Stage 1: Sparse gather — load indices, compute mask
                for bi in T.Parallel(BI):
                    gidx = base + bi
                    raw = indices[b_i, s_i, 0, gidx]
                    if have_topk_length:
                        v = T.if_then_else((raw >= 0) & (gidx < topk_length[b_i]), 1, 0)
                    else:
                        v = T.if_then_else(raw >= 0, 1, 0)
                    mask_s[bi] = v
                    page_s[bi] = T.if_then_else(v == 1, raw, 0)

                # Stage 2: Gather KV data into dense tiles [BI, D]
                for bi, d in T.Parallel(BI, NOPE_PAD):
                    K_fp8[bi, d] = T.if_then_else(mask_s[bi] == 1, kv_flat[page_s[bi], d], 0.0)
                for bi, d in T.Parallel(BI, D_ROPE):
                    K_rope_s[bi, d] = T.if_then_else(mask_s[bi] == 1, k_rope[page_s[bi], d], 0.0)
                for bi, g in T.Parallel(BI, N_GROUPS_NOPE):
                    K_scl[bi, g] = T.if_then_else(mask_s[bi] == 1, k_scale[page_s[bi], g], 0.0)

                # Init scores: valid tokens → 0, invalid → -inf
                for hi, bi in T.Parallel(H_PER_BLOCK, BI):
                    acc_s[hi, bi] = T.if_then_else(mask_s[bi] == 1, 0.0, -T.infinity(FP32))

                # Stage 3: QK^T — 4 nope groups (static unroll) + rope
                for bi, d in T.Parallel(BI, QTS):
                    K_buf[bi, d] = T.Cast(BF16, K_fp8[bi, d]) * T.Cast(BF16, K_scl[bi, 0])
                T.gemm(Q_nope[:, 0:QTS], K_buf, acc_s, transpose_B=True,
                       clear_accum=False, policy=T.GemmWarpPolicy.FullCol)

                for bi, d in T.Parallel(BI, QTS):
                    K_buf[bi, d] = T.Cast(BF16, K_fp8[bi, QTS + d]) * T.Cast(BF16, K_scl[bi, 1])
                T.gemm(Q_nope[:, QTS:2*QTS], K_buf, acc_s, transpose_B=True,
                       clear_accum=False, policy=T.GemmWarpPolicy.FullCol)

                for bi, d in T.Parallel(BI, QTS):
                    K_buf[bi, d] = T.Cast(BF16, K_fp8[bi, 2*QTS + d]) * T.Cast(BF16, K_scl[bi, 2])
                T.gemm(Q_nope[:, 2*QTS:3*QTS], K_buf, acc_s, transpose_B=True,
                       clear_accum=False, policy=T.GemmWarpPolicy.FullCol)

                for bi, d in T.Parallel(BI, QTS):
                    K_buf[bi, d] = T.Cast(BF16, K_fp8[bi, 3*QTS + d]) * T.Cast(BF16, K_scl[bi, 3])
                T.gemm(Q_nope[:, 3*QTS:4*QTS], K_buf, acc_s, transpose_B=True,
                       clear_accum=False, policy=T.GemmWarpPolicy.FullCol)

                # Rope GEMM
                T.gemm(Q_rope, K_rope_s, acc_s, transpose_B=True,
                       clear_accum=False, policy=T.GemmWarpPolicy.FullCol)

                # Stage 4: Online softmax (log2 domain)
                T.copy(m_i, m_prev)
                T.reduce_max(acc_s, m_i, dim=1, clear=False)
                for hi in T.Parallel(H_PER_BLOCK):
                    alpha[hi] = T.exp2(m_prev[hi] - m_i[hi])
                for hi, bi in T.Parallel(H_PER_BLOCK, BI):
                    acc_s[hi, bi] = T.exp2(acc_s[hi, bi] - m_i[hi])
                T.reduce_sum(acc_s, l_i, dim=1)
                for hi in T.Parallel(H_PER_BLOCK):
                    lsum[hi] = lsum[hi] * alpha[hi] + l_i[hi]

                # Stage 5: Rescale V accumulators
                for hi, d in T.Parallel(H_PER_BLOCK, QTS):
                    acc_g0[hi, d] *= alpha[hi]
                    acc_g1[hi, d] *= alpha[hi]
                    acc_g2[hi, d] *= alpha[hi]
                    acc_g3[hi, d] *= alpha[hi]
                for hi, d in T.Parallel(H_PER_BLOCK, D_ROPE):
                    acc_r[hi, d] *= alpha[hi]

                # Store S to shared mem for PV
                for hi, bi in T.Parallel(H_PER_BLOCK, BI):
                    S_smem[hi, bi] = T.Cast(BF16, acc_s[hi, bi])

                # Stage 6: PV — 4 nope groups
                for bi, d in T.Parallel(BI, QTS):
                    K_buf[bi, d] = T.Cast(BF16, K_fp8[bi, d]) * T.Cast(BF16, K_scl[bi, 0])
                T.gemm(S_smem, K_buf, tmp_out, clear_accum=True, policy=T.GemmWarpPolicy.FullCol)
                for hi, d in T.Parallel(H_PER_BLOCK, QTS):
                    acc_g0[hi, d] += tmp_out[hi, d]

                for bi, d in T.Parallel(BI, QTS):
                    K_buf[bi, d] = T.Cast(BF16, K_fp8[bi, QTS + d]) * T.Cast(BF16, K_scl[bi, 1])
                T.gemm(S_smem, K_buf, tmp_out, clear_accum=True, policy=T.GemmWarpPolicy.FullCol)
                for hi, d in T.Parallel(H_PER_BLOCK, QTS):
                    acc_g1[hi, d] += tmp_out[hi, d]

                for bi, d in T.Parallel(BI, QTS):
                    K_buf[bi, d] = T.Cast(BF16, K_fp8[bi, 2*QTS + d]) * T.Cast(BF16, K_scl[bi, 2])
                T.gemm(S_smem, K_buf, tmp_out, clear_accum=True, policy=T.GemmWarpPolicy.FullCol)
                for hi, d in T.Parallel(H_PER_BLOCK, QTS):
                    acc_g2[hi, d] += tmp_out[hi, d]

                for bi, d in T.Parallel(BI, QTS):
                    K_buf[bi, d] = T.Cast(BF16, K_fp8[bi, 3*QTS + d]) * T.Cast(BF16, K_scl[bi, 3])
                T.gemm(S_smem, K_buf, tmp_out, clear_accum=True, policy=T.GemmWarpPolicy.FullCol)
                for hi, d in T.Parallel(H_PER_BLOCK, QTS):
                    acc_g3[hi, d] += tmp_out[hi, d]

                # Rope PV
                T.gemm(S_smem, K_rope_s, acc_r, clear_accum=False, policy=T.GemmWarpPolicy.FullCol)

            # ── Finalize: normalize + write partial output ────────────
            for hi in T.Parallel(H_PER_BLOCK):
                denom = T.if_then_else(lsum[hi] == 0.0, 1.0, lsum[hi])
                alpha[hi] = 1.0 / denom
                partial_lse[b_i, s_i, group_i, H0 + hi] = T.if_then_else(
                    lsum[hi] == 0.0, -(2.0 ** 30),
                    T.log2(lsum[hi]) + m_i[hi])

            for hi, d in T.Parallel(H_PER_BLOCK, QTS):
                partial_o[b_i, s_i, group_i, H0 + hi, d] = T.Cast(BF16, acc_g0[hi, d] * alpha[hi])
                partial_o[b_i, s_i, group_i, H0 + hi, QTS + d] = T.Cast(BF16, acc_g1[hi, d] * alpha[hi])
                partial_o[b_i, s_i, group_i, H0 + hi, 2*QTS + d] = T.Cast(BF16, acc_g2[hi, d] * alpha[hi])
                partial_o[b_i, s_i, group_i, H0 + hi, 3*QTS + d] = T.Cast(BF16, acc_g3[hi, d] * alpha[hi])
            for hi, d in T.Parallel(H_PER_BLOCK, D_ROPE):
                partial_o[b_i, s_i, group_i, H0 + hi, NOPE_PAD + d] = T.Cast(
                    BF16, acc_r[hi, d] * alpha[hi])

    return main


# ═══════════════════════════════════════════════════════════════════════════
# Combine kernel: LSE-weighted merge of partial results
# ═══════════════════════════════════════════════════════════════════════════

@tilelang.jit(out_idx=[-2, -1], pass_configs=_PASS_CONFIGS)
def _build_combine(heads: int, n_groups: int, have_attn_sink: bool):
    """Combine partial attention results via LSE-weighted merge."""
    REPLICATE_H = heads // H_PER_BLOCK
    batch   = T.symbolic("batch")
    seq_len = T.symbolic("seq_len")

    @T.prim_func
    def main(
        partial_o:   T.Tensor([batch, seq_len, n_groups, heads, D_QK_PAD], BF16),
        partial_lse: T.Tensor([batch, seq_len, n_groups, heads], FP32),
        attn_sink:   T.Tensor([heads], FP32),
        output:      T.Tensor([batch, seq_len, heads, D_QK_PAD], BF16),
        lse_out:     T.Tensor([batch, seq_len, heads], FP32),
    ):
        with T.Kernel(batch * seq_len * REPLICATE_H, threads=256) as (bx,):
            rep_i = bx % REPLICATE_H
            tmp   = bx // REPLICATE_H
            s_i   = tmp % seq_len
            b_i   = tmp // seq_len
            H0 = rep_i * H_PER_BLOCK

            lse_smem = T.alloc_shared([n_groups, H_PER_BLOCK], FP32)
            for g in T.serial(n_groups):
                T.copy(partial_lse[b_i, s_i, g, H0:H0 + H_PER_BLOCK], lse_smem[g, :])

            lse_max = T.alloc_fragment([H_PER_BLOCK], FP32)
            lse_sum = T.alloc_fragment([H_PER_BLOCK], FP32)
            scale_f = T.alloc_fragment([H_PER_BLOCK], FP32)
            acc_o   = T.alloc_fragment([H_PER_BLOCK, D_QK_PAD], FP32)

            # Find max LSE across groups
            T.fill(lse_max, -(2.0 ** 30))
            for g in T.serial(n_groups):
                for hi in T.Parallel(H_PER_BLOCK):
                    lse_max[hi] = T.max(lse_max[hi], lse_smem[g, hi])

            # Apply attn_sink if present
            if have_attn_sink:
                for hi in T.Parallel(H_PER_BLOCK):
                    lse_max[hi] = T.max(lse_max[hi], attn_sink[H0 + hi])

            # Sum of exp2(LSE - max)
            T.fill(lse_sum, 0.0)
            for g in T.serial(n_groups):
                for hi in T.Parallel(H_PER_BLOCK):
                    lse_sum[hi] = lse_sum[hi] + T.exp2(lse_smem[g, hi] - lse_max[hi])
            if have_attn_sink:
                for hi in T.Parallel(H_PER_BLOCK):
                    lse_sum[hi] = lse_sum[hi] + T.exp2(attn_sink[H0 + hi] - lse_max[hi])

            # Weighted sum of partial outputs
            T.fill(acc_o, 0.0)
            for g in T.serial(n_groups):
                for hi in T.Parallel(H_PER_BLOCK):
                    scale_f[hi] = T.exp2(lse_smem[g, hi] - lse_max[hi] - T.log2(lse_sum[hi]))
                for hi, d in T.Parallel(H_PER_BLOCK, D_QK_PAD):
                    acc_o[hi, d] = acc_o[hi, d] + scale_f[hi] * T.Cast(FP32, partial_o[b_i, s_i, g, H0 + hi, d])

            # Final LSE
            for hi in T.Parallel(H_PER_BLOCK):
                lse_out[b_i, s_i, H0 + hi] = T.log2(lse_sum[hi]) + lse_max[hi]

            # Write output
            for hi, d in T.Parallel(H_PER_BLOCK, D_QK_PAD):
                output[b_i, s_i, H0 + hi, d] = T.Cast(BF16, acc_o[hi, d])

    return main


# ═══════════════════════════════════════════════════════════════════════════
# Public API (drop-in replacement for flash_mla_sparse_decode_triton)
# ═══════════════════════════════════════════════════════════════════════════

# Kernel cache by (H, topk, inner_iter, have_topk_len) signature
_partial_cache: dict = {}
_combine_cache: dict = {}


def _pick_inner_iter(topk: int) -> int:
    """Pick inner_iter as largest power-of-2 divisor of n_groups, up to 4."""
    n = topk // BI
    it = 1
    while it * 2 <= n and n % (it * 2) == 0 and it < 4:
        it *= 2
    return it


def flash_mla_sparse_decode_tilelang(
    q: torch.Tensor,                              # [B, 1, H, D_QK] bf16
    k_cache: torch.Tensor,                        # [num_pages, page_size, 1, bpt] float8
    indices: torch.Tensor,                        # [B, topk] int32
    topk_length: Optional[torch.Tensor],          # [B] int32 or None
    attn_sink: Optional[torch.Tensor],            # [H] float32 or None
    head_dim_v: int,                              # unused (always D_QK)
    softmax_scale: float,
    extra_k_cache: Optional[torch.Tensor] = None,
    extra_indices: Optional[torch.Tensor] = None,
    extra_topk_length: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """TileLang SM89 sparse MLA decode.

    Architecture: sparse gather → dense GEMM via T.gemm (Tensor Cores).
    Split-KV partial + combine for large topk.

    Constraints:
      - H must be divisible by 16
      - topk must be divisible by 64
      - B can be > 1 (batch folded into grid dim 0)
    """
    if softmax_scale is None:
        softmax_scale = q.shape[-1] ** (-0.5)

    B, S_Q, H, D = q.shape
    assert S_Q == 1, "decode kernel requires S_Q=1"
    assert H % H_PER_BLOCK == 0, f"H ({H}) must be divisible by {H_PER_BLOCK}"

    # ── Prepare Q ──────────────────────────────────────────────────────
    # Apply softmax_scale * LOG2E for log2-domain math
    # Pad nope from 448 → 512 so kernel sees [B, 1, H, 576] = nope(512) + rope(64)
    q_nope = q[..., :D_NOPE].float() * softmax_scale * LOG2E
    q_rope = q[..., D_NOPE:].float() * softmax_scale * LOG2E
    q_nope_pad = torch.zeros(B, S_Q, H, NOPE_PAD, dtype=torch.float32, device=q.device)
    q_nope_pad[..., :D_NOPE] = q_nope
    q_scaled = torch.cat([q_nope_pad, q_rope], dim=-1).to(torch.bfloat16).contiguous()

    # ── Prepare main KV cache ─────────────────────────────────────────
    kv_flat, k_scale, k_rope = _prepare_kv(k_cache)
    N = kv_flat.shape[0]

    # Reshape indices to [B, S_Q, 1, topk]
    flat_indices = indices.reshape(B, S_Q, 1, -1).contiguous()
    topk = flat_indices.shape[-1]
    assert topk % BI == 0, f"topk ({topk}) must be divisible by {BI}"

    inner_iter = _pick_inner_iter(topk)
    n_groups = topk // (BI * inner_iter)

    tl_have = topk_length is not None

    # ── Build / get partial kernel ────────────────────────────────────
    partial_key = (H, topk, inner_iter, tl_have)
    if partial_key not in _partial_cache:
        _partial_cache[partial_key] = _build_partial(H, topk, inner_iter, tl_have)
    kernel_partial = _partial_cache[partial_key]

    tl_val = topk_length if tl_have else torch.zeros(B, dtype=torch.int32, device=q.device)

    # Allocate partial output as D_QK_PAD=576 (nope pad 512 + rope 64)
    partial_o, partial_lse = kernel_partial(
        q_scaled, kv_flat, k_scale, k_rope, flat_indices, tl_val)

    # ── Process extra cache if present ────────────────────────────────
    if extra_k_cache is not None and extra_indices is not None:
        ekv_flat, ek_scale, ek_rope = _prepare_kv(extra_k_cache)
        extra_flat = extra_indices.reshape(B, S_Q, 1, -1).contiguous()
        extra_topk_val = extra_flat.shape[-1]
        assert extra_topk_val % BI == 0

        extra_inner = _pick_inner_iter(extra_topk_val)
        extra_ng = extra_topk_val // (BI * extra_inner)
        extra_have = extra_topk_length is not None

        extra_pkey = (H, extra_topk_val, extra_inner, extra_have)
        if extra_pkey not in _partial_cache:
            _partial_cache[extra_pkey] = _build_partial(H, extra_topk_val, extra_inner, extra_have)
        extra_kernel = _partial_cache[extra_pkey]

        extra_tl = extra_topk_length if extra_have else torch.zeros(B, dtype=torch.int32, device=q.device)

        extra_o, extra_lse = extra_kernel(
            q_scaled, ekv_flat, ek_scale, ek_rope, extra_flat, extra_tl)

        # Merge: cat partial results along group dim
        total_ng = n_groups + extra_ng
        merged_o = torch.cat([partial_o, extra_o], dim=2)   # [B, 1, total_ng, H, D_QK]
        merged_lse = torch.cat([partial_lse, extra_lse], dim=2)
        partial_o, partial_lse = merged_o, merged_lse
        n_groups = total_ng

    # ── Combine partial results ───────────────────────────────────────
    combine_key = (H, n_groups, attn_sink is not None)
    if combine_key not in _combine_cache:
        _combine_cache[combine_key] = _build_combine(H, n_groups, attn_sink is not None)
    kernel_combine = _combine_cache[combine_key]

    sink = attn_sink if attn_sink is not None else torch.zeros(H, dtype=torch.float32, device=q.device)

    # Combine outputs [B, 1, H, 576] → trim to [B, 1, H, 512] (drop padded nope tail)
    output, lse_out = kernel_combine(partial_o, partial_lse, sink)
    output_trimmed = torch.cat([
        output[..., :D_NOPE],           # nope [0:448]
        output[..., NOPE_PAD:],         # rope [512:576]
    ], dim=-1)  # → [B, 1, H, 512]

    # Return format: (out [B, 1, H, D_QK], lse [B, H, 1])
    return output_trimmed, lse_out.permute(0, 2, 1)
