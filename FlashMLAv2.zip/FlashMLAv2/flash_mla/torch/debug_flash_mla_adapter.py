from typing import Optional

import torch

from .ref import flash_mla_decode_torch


def flash_mla_with_kvcache_entrypoint(backend: str, **kwargs):
    from sglang.srt.utils import is_hip

    if is_hip():
        import os

        backend = os.environ.get("SGLANG_HACK_FLASHMLA_BACKEND", "kernel")
    else:
        import flash_mla

    if backend == "comparison":
        pack_ref = flash_mla_with_kvcache_entrypoint(backend="torch", **kwargs)
        pack_fast = flash_mla_with_kvcache_entrypoint(backend="kernel", **kwargs)
        _assert_close(pack_ref=pack_ref, pack_fast=pack_fast)
        return pack_ref

    if backend == "torch":
        return flash_mla_with_kvcache_torch(**kwargs)

    if backend == "kernel":
        return flash_mla.flash_mla_with_kvcache(**kwargs)

    raise NotImplementedError(f"Unknown backend: {backend}")


def flash_mla_with_kvcache_torch(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    block_table: Optional[torch.Tensor],
    cache_seqlens: Optional[torch.Tensor],
    head_dim_v: int,
    tile_scheduler_metadata,
    num_splits=None,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    is_fp8_kvcache: bool = False,
    indices: Optional[torch.Tensor] = None,
    attn_sink: Optional[torch.Tensor] = None,
    extra_k_cache: Optional[torch.Tensor] = None,
    extra_indices_in_kvcache: Optional[torch.Tensor] = None,
    topk_length: Optional[torch.Tensor] = None,
    extra_topk_length: Optional[torch.Tensor] = None,
):
    assert block_table is None
    assert cache_seqlens is None
    assert is_fp8_kvcache

    if softmax_scale is None:
        softmax_scale = q.shape[-1] ** (-0.5)

    return flash_mla_decode_torch(
        q=q,
        k_cache=k_cache,
        indices=indices,
        head_dim_v=head_dim_v,
        softmax_scale=softmax_scale,
        attn_sink=attn_sink,
        extra_k_cache=extra_k_cache,
        extra_indices=extra_indices_in_kvcache,
        topk_length=topk_length,
        extra_topk_length=extra_topk_length,
    )


def _assert_close(pack_ref, pack_fast):
    import sglang.srt.flashmla_tests.kernelkit as kk

    out_ref, lse_ref = pack_ref
    out_fast, lse_fast = pack_fast

    is_out_correct = kk.check_is_allclose(
        "out", out_fast, out_ref, abs_tol=1e-2, rel_tol=10.0, cos_diff_tol=5e-6
    )
    is_lse_correct = kk.check_is_allclose(
        "lse", lse_fast, lse_ref, abs_tol=1e-6, rel_tol=8.01 / 65536
    )
    assert is_out_correct and is_lse_correct, (
        f"{is_out_correct=} {is_lse_correct=}"
    )
