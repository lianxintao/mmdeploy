"""
Fused dequant + gather reference for FlashMLA sparse decoding.
Deep-merged: the triton kernel reads nope/rope directly from overlapping
fp8/bf16 views that share the same contiguous memory, using byte offsets.
Scale: float32 for V32 (zero-copy view), raw uint8 e8m0 for MODEL1 (kernel converts inline).
"""

from typing import Optional, Tuple

import torch
import triton
import triton.language as tl


# ---------------------------------------------------------------------------
# FP8 KV cache flatten: overlapping typed views + scale metadata
# ---------------------------------------------------------------------------

def _flatten_kvcache(k_cache: torch.Tensor, d_qk: int):
    """
    Create overlapping fp8/bf16 views of the packed KV cache.

    Returns (kv_fp8, kv_bf16, k_scale, d_nope, d_rope, num_tiles, tile_size,
             rope_bf16_off, scale_is_e8m0)
    where kv_fp8 and kv_bf16 share the same backing memory.
    k_scale is float32 for V32, raw uint8 for MODEL1.
    """
    assert k_cache.ndim == 4 and k_cache.shape[2] == 1
    num_blocks, block_size = k_cache.shape[:2]
    N = num_blocks * block_size

    if d_qk == 576:  # V32_FP8Sparse  —  layout: [nope_fp8:512][scale_f32:16][rope_bf16:128] = 656
        d_nope, d_rope, tile_size, num_tiles = 512, 64, 128, 4
        bpt = 656

        kv_flat = k_cache.squeeze(2).reshape(N, bpt).contiguous()

        # Overlapping views sharing the same contiguous memory
        kv_fp8  = kv_flat                                                # fp8  [N, 656]
        kv_bf16 = kv_flat.view(torch.uint8).view(torch.bfloat16)         # bf16 [N, 328]

        # scale: embedded as float32 at bytes 512–527,  zero-copy view
        k_scale = (
            kv_flat.view(torch.uint8)[:, d_nope : d_nope + num_tiles * 4]
            .contiguous()
            .view(torch.float32)
            .view(N, num_tiles)
        )
        scale_is_e8m0 = False

        rope_bf16_off = (d_nope + num_tiles * 4) // 2                   # 528 / 2 = 264

    elif d_qk == 512:  # MODEL1_FP8Sparse  —  layout: [nope_fp8:448][rope_bf16:128][scale_e8m0:8] = 584
        d_nope, d_rope, tile_size, num_tiles = 448, 64, 64, 7

        flat = k_cache.view(num_blocks, -1)                                # preserves strides

        # nope+rope: contiguous copy of first 576 bytes per "flat token"
        nope_rope = (
            flat[:, : block_size * (d_nope + 2 * d_rope)]                  # [B, S*576]
            .view(num_blocks, block_size, d_nope + 2 * d_rope)             # [B, S, 576]
            .reshape(N, d_nope + 2 * d_rope)                               # contiguous copy
        )
        kv_fp8  = nope_rope.view(torch.float8_e4m3fn)                     # fp8  [N, 576]
        kv_bf16 = nope_rope.view(torch.bfloat16)                           # bf16 [N, 288]

        # Scale: raw e8m0 bytes from separate scale section; kernel converts inline
        k_scale = (
            flat[:, block_size * (d_nope + 2 * d_rope):]                   # [B, S*8]
            .view(num_blocks, block_size, 8)[:, :, :num_tiles]             # [B, S, 7]
            .reshape(N, num_tiles)                                         # contiguous copy
            .view(torch.uint8)                                             # raw e8m0 bytes
        )
        scale_is_e8m0 = True

        rope_bf16_off = d_nope // 2                                       # 448 / 2 = 224

    else:
        raise ValueError(f"Unsupported d_qk={d_qk}")

    return kv_fp8, kv_bf16, k_scale, d_nope, d_rope, num_tiles, tile_size, rope_bf16_off, scale_is_e8m0


# ---------------------------------------------------------------------------
# Fused dequantize + gather kernel  (reads nope from fp8 view, rope from bf16 view)
# ---------------------------------------------------------------------------

@triton.jit
def _fused_dequant_gather_kernel(
    kv_nope_ptr,           # float8e4nv [N, stride_nope]   fp8 view, nope at offset 0
    kv_rope_ptr,           # bf16       [N, stride_rope]   bf16 view, rope at rope_off
    k_scale_ptr,           # float32 (V32) or uint8 (M1)   [N, num_tiles]
    indices_ptr,           # int32      [b, s_q, topk]
    topk_length_ptr,       # int32      [b] or empty
    gathered_kv_ptr,       # bf16       [b, s_q, topk, d_qk]
    invalid_mask_ptr,      # int8       [b, s_q, topk]
    #
    d_nope: tl.constexpr,
    d_rope: tl.constexpr,
    d_qk: tl.constexpr,
    num_tiles: tl.constexpr,
    tile_size: tl.constexpr,
    rope_bf16_off: tl.constexpr,
    SCALE_IS_E8M0: tl.constexpr,   # True: scale is uint8 e8m0; False: float32
    topk: tl.constexpr,
    BLOCK_TK: tl.constexpr,
    HAS_TOPK_LENGTH: tl.constexpr,
    #
    stride_nope_n: tl.int32,
    stride_rope_n: tl.int32,
    stride_scale_n: tl.int32,
    stride_idx_b: tl.int32,
    stride_idx_s: tl.int32,
    stride_out_b: tl.int32,
    stride_out_s: tl.int32,
    stride_out_t: tl.int32,
    stride_mask_b: tl.int32,
    stride_mask_s: tl.int32,
    B: tl.int32,
    S_Q: tl.int32,
):
    pid = tl.program_id(0)
    tile_y = tl.program_id(1)                                     # which nope tile (0..num_tiles-1)
    tiles_per_seq = topk // BLOCK_TK
    bid_sq = pid // tiles_per_seq
    tile_id = pid % tiles_per_seq
    bid = bid_sq // S_Q
    sid = bid_sq % S_Q

    t_start = tile_id * BLOCK_TK
    offs_tk = t_start + tl.arange(0, BLOCK_TK)
    t_in_bounds = offs_tk < topk

    # Load indices
    idx_ptr = indices_ptr + bid * stride_idx_b + sid * stride_idx_s + offs_tk
    kv_idx = tl.load(idx_ptr, mask=t_in_bounds, other=-1)
    invalid = (kv_idx < 0) | ~t_in_bounds
    kv_idx_safe = tl.maximum(kv_idx, 0)

    if HAS_TOPK_LENGTH:
        tk_len = tl.load(topk_length_ptr + bid)
        invalid = invalid | (offs_tk >= tk_len)

    # Only tile_y == 0 writes the invalid mask (avoids redundant stores)
    if tile_y == 0:
        mask_ptr = invalid_mask_ptr + bid * stride_mask_b + sid * stride_mask_s + offs_tk
        tl.store(mask_ptr, invalid.to(tl.int8), mask=t_in_bounds)

    valid_1d = ~invalid

    # ---- dequant ONE nope tile (indexed by tile_y) ----
    t_off = tile_y * tile_size
    offs_d_nope = t_off + tl.arange(0, tile_size)

    # Load nope fp8  (offset 0 in the fp8 view)
    nope_ptr = (
        kv_nope_ptr
        + kv_idx_safe[:, None] * stride_nope_n
        + offs_d_nope[None, :]
    )
    nope_fp8 = tl.load(nope_ptr, mask=valid_1d[:, None], other=0.0)

    # Load scale for this tile
    scale_ptr = k_scale_ptr + kv_idx_safe * stride_scale_n + tile_y
    if SCALE_IS_E8M0:
        scale_raw = tl.load(scale_ptr, mask=valid_1d, other=127)
        scale = tl.math.exp2(scale_raw.to(tl.float32) - 127.0)
    else:
        scale = tl.load(scale_ptr, mask=valid_1d, other=0.0)

    # Dequantize
    nope_f32 = nope_fp8.to(tl.float32) * scale[:, None]
    nope_bf16 = nope_f32.to(tl.bfloat16)

    out_ptr = (
        gathered_kv_ptr
        + bid * stride_out_b
        + sid * stride_out_s
        + offs_tk[:, None] * stride_out_t
        + offs_d_nope[None, :]
    )
    tl.store(out_ptr, nope_bf16, mask=t_in_bounds[:, None])

    # ---- load + store rope  (only tile_y == 0) ----
    if tile_y == 0:
        offs_rope = tl.arange(0, d_rope)
        rope_ptr = (
            kv_rope_ptr
            + kv_idx_safe[:, None] * stride_rope_n
            + (rope_bf16_off + offs_rope)[None, :]
        )
        rope = tl.load(rope_ptr, mask=valid_1d[:, None], other=0.0)

        out_rope_ptr = (
            gathered_kv_ptr
            + bid * stride_out_b
            + sid * stride_out_s
            + offs_tk[:, None] * stride_out_t
            + (d_nope + offs_rope)[None, :]
        )
        tl.store(out_rope_ptr, rope, mask=t_in_bounds[:, None])


# ---------------------------------------------------------------------------
# Python wrapper
# ---------------------------------------------------------------------------

def _fused_gather_kv(
    kv_fp8: torch.Tensor,
    kv_bf16: torch.Tensor,
    k_scale: torch.Tensor,
    indices: torch.Tensor,
    topk_length: Optional[torch.Tensor],
    d_nope: int,
    d_rope: int,
    num_tiles: int,
    tile_size: int,
    rope_bf16_off: int,
    scale_is_e8m0: bool = False,
) -> Tuple[torch.Tensor, torch.Tensor]:
    b, s_q, topk = indices.shape
    d_qk = d_nope + d_rope
    device = kv_fp8.device

    gathered_kv = torch.empty(b, s_q, topk, d_qk, dtype=torch.bfloat16, device=device)
    invalid_mask = torch.empty(b, s_q, topk, dtype=torch.bool, device=device)

    topk_len_tensor = (
        topk_length
        if topk_length is not None
        else torch.empty(0, dtype=torch.int32, device=device)
    )

    # Pick BLOCK_TK: prefer largest compatible value, reduce when GPU underutilized
    BLOCK_TK = 64
    for blk in [64, 32, 16, 8]:
        if topk % blk == 0:
            BLOCK_TK = blk
            break
    # If too few blocks for GPU occupancy on small-B decode, use smaller tiles
    if b * s_q * (topk // BLOCK_TK) < 16:
        for blk in [16, 8, 4]:
            if topk % blk == 0:
                BLOCK_TK = blk
                if b * s_q * (topk // blk) >= 8:
                    break

    grid = (b * s_q * (topk // BLOCK_TK), num_tiles)

    _fused_dequant_gather_kernel[grid](
        kv_fp8,
        kv_bf16,
        k_scale,
        indices,
        topk_len_tensor,
        gathered_kv,
        invalid_mask,
        d_nope=d_nope,
        d_rope=d_rope,
        d_qk=d_qk,
        num_tiles=num_tiles,
        tile_size=tile_size,
        rope_bf16_off=rope_bf16_off,
        SCALE_IS_E8M0=scale_is_e8m0,
        topk=topk,
        BLOCK_TK=BLOCK_TK,
        HAS_TOPK_LENGTH=topk_length is not None,
        stride_nope_n=kv_fp8.stride(0),
        stride_rope_n=kv_bf16.stride(0),
        stride_scale_n=k_scale.stride(0),
        stride_idx_b=indices.stride(0),
        stride_idx_s=indices.stride(1),
        stride_out_b=gathered_kv.stride(0),
        stride_out_s=gathered_kv.stride(1),
        stride_out_t=gathered_kv.stride(2),
        stride_mask_b=invalid_mask.stride(0),
        stride_mask_s=invalid_mask.stride(1),
        B=b,
        S_Q=s_q,
    )
    return gathered_kv, invalid_mask


# ---------------------------------------------------------------------------
# Main decode function
# ---------------------------------------------------------------------------

def flash_mla_decode_torch(
    q: torch.Tensor,                           # [b, s_q, h_q, d_qk] bf16
    k_cache: torch.Tensor,                     # FP8 packed [B, S, 1, bpt]
    indices: torch.Tensor,                     # [b, s_q, topk] int32
    head_dim_v: int,
    softmax_scale: float,
    attn_sink: Optional[torch.Tensor] = None,  # [h_q] float32
    extra_k_cache: Optional[torch.Tensor] = None,
    extra_indices: Optional[torch.Tensor] = None,
    topk_length: Optional[torch.Tensor] = None,
    extra_topk_length: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    FlashMLA sparse decoding — pure PyTorch + Triton reference.

    Returns (output, lse):
      output: [b, s_q, h_q, head_dim_v] bf16
      lse:    [b, h_q, s_q] float32
    """
    b, s_q, h_q, d_qk = q.shape
    d_v = head_dim_v

    # ---------- flatten FP8 cache + fused dequant/gather ----------
    (kv_fp8, kv_bf16, k_scale, d_nope, d_rope,
     n_tiles, t_size, rope_off, scale_is_e8m0) = _flatten_kvcache(k_cache, d_qk)
    gathered_kv, invalid_mask = _fused_gather_kv(
        kv_fp8, kv_bf16, k_scale, indices, topk_length,
        d_nope, d_rope, n_tiles, t_size, rope_off, scale_is_e8m0,
    )

    if extra_k_cache is not None:
        assert extra_indices is not None
        (ek_fp8, ek_bf16, ek_scale, _, _, _, _, er_off,
         ek_e8m0) = _flatten_kvcache(extra_k_cache, d_qk)
        extra_gkv, extra_mask = _fused_gather_kv(
            ek_fp8, ek_bf16, ek_scale, extra_indices, extra_topk_length,
            d_nope, d_rope, n_tiles, t_size, er_off, ek_e8m0,
        )
        gathered_kv = torch.cat([gathered_kv, extra_gkv], dim=2)
        invalid_mask = torch.cat([invalid_mask, extra_mask], dim=2)

    # ---------- attention ----------
    total_topk = gathered_kv.shape[2]

    gathered_kv = gathered_kv.view(b * s_q, total_topk, d_qk).float()
    gathered_kv[gathered_kv != gathered_kv] = 0.0  # NaN → 0
    q_flat = q.float().view(b * s_q, h_q, d_qk)

    attn_weight = q_flat @ gathered_kv.transpose(-1, -2)   # [b*s_q, h_q, topk]
    attn_weight *= softmax_scale
    attn_weight[
        invalid_mask.view(b * s_q, 1, total_topk).broadcast_to(
            b * s_q, h_q, total_topk
        )
    ] = float("-inf")

    lse = attn_weight.logsumexp(dim=-1)                     # [b*s_q, h_q]
    attn_weight = torch.exp(attn_weight - lse.unsqueeze(-1))
    output = attn_weight @ gathered_kv[..., :d_v]           # [b*s_q, h_q, dv]
    output = output.view(b, s_q, h_q, d_v)
    lse = lse.view(b, s_q, h_q)

    # Attention sink
    if attn_sink is not None:
        output *= (
            1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - lse))
        ).unsqueeze(-1)

    # Lonely q tokens (no attendable k)
    lonely_q_mask = lse == float("-inf")
    output[lonely_q_mask.unsqueeze(-1).broadcast_to(b, s_q, h_q, d_v)] = 0.0
    lse[lonely_q_mask] = float("+inf")

    return output.to(torch.bfloat16), lse.transpose(1, 2)
