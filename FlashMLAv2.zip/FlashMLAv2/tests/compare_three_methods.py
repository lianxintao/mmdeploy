"""
3-way comparison: Triton fused kernel vs optimized torch vs original torch.

Methods:
  A. triton_kernel  — flash_mla_sparse_decode_triton (fully fused)
  B. torch_opt      — flash_mla_decode_torch (deep merge: overlapping views + fused gather)
  C. torch_orig     — dequantize_k_cache + manual gather + PyTorch attention

Usage:
    python tests/compare_three_methods.py
"""
import sys, os, time, types
from typing import Optional, Tuple

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ── Mock flash_mla.cuda so flash_mla.torch.ref can be imported ──
_mock_cuda = types.ModuleType("flash_mla.cuda")
sys.modules["flash_mla.cuda"] = _mock_cuda

import torch, importlib.util

# Import our optimized torch impl (ref.py)
_spec = importlib.util.spec_from_file_location(
    "ref_torch", os.path.join(os.path.dirname(__file__), "..", "flash_mla", "torch", "ref.py"),
)
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)

# Import the flash_atten triton kernel
_spec2 = importlib.util.spec_from_file_location(
    "triton_kernel", os.path.join(os.path.dirname(__file__), "..", "flash_atten", "triton_kernel.py"),
)
triton_kernel = importlib.util.module_from_spec(_spec2)
_spec2.loader.exec_module(triton_kernel)

from tests.quant import dequantize_k_cache, FP8KVCacheLayout

# ── DSv4 config ──────────────────────────────────────────────────────────────
D_QK = 512
D_NOPE = 448
D_ROPE = 64
D_V = 512


# ═══════════════════════════════════════════════════════════════════════════════
# KV cache builder (same layout as flash_atten/test_triton_sparse_decode.py)
# ═══════════════════════════════════════════════════════════════════════════════

def build_fp8_kv_cache(kv_bf16: torch.Tensor, page_size: int):
    """Build FP8 KV cache compatible with all three implementations (vectorized)."""
    total_tokens = kv_bf16.shape[0]
    num_pages = (total_tokens + page_size - 1) // page_size
    pad_len = num_pages * page_size - total_tokens

    if pad_len > 0:
        kv_bf16 = torch.cat([
            kv_bf16,
            torch.zeros(pad_len, D_QK, dtype=torch.bfloat16, device=kv_bf16.device),
        ], dim=0)

    N = num_pages * page_size
    kv_bf16 = kv_bf16.view(N, D_QK).clone()
    nope_bf16 = kv_bf16[:, :D_NOPE]   # [N, 448]
    rope_bf16 = kv_bf16[:, D_NOPE:]   # [N, 64]

    # Quantize nope per-group (vectorized)
    nope_fp8 = torch.empty(N, D_NOPE, dtype=torch.float8_e4m3fn, device=kv_bf16.device)
    scales_ue8m0 = torch.empty(N, D_NOPE // 64, dtype=torch.uint8, device=kv_bf16.device)
    for g in range(D_NOPE // 64):
        gs, ge = g * 64, (g + 1) * 64
        chunk = nope_bf16[:, gs:ge].float()
        amax = chunk.abs().max(dim=-1).values.clamp(min=1e-8)
        scale = amax / 448.0
        nope_fp8[:, gs:ge] = (chunk / scale.unsqueeze(-1)).to(torch.float8_e4m3fn)
        raw = torch.clamp(scale.log2().ceil() + 127, 1, 254).to(torch.uint8)
        scales_ue8m0[:, g] = raw

    # Build flat buffer (vectorized, no per-token Python loop)
    page_total = page_size * (D_NOPE + D_ROPE * 2 + 8)
    raw = torch.zeros(num_pages * page_total, dtype=torch.uint8, device=kv_bf16.device)

    # Reshape to [num_pages, page_size, 584], fill nope, rope, scale per token
    raw_view = raw.view(num_pages, page_size, D_NOPE + D_ROPE * 2 + 8)
    nope_bytes = nope_fp8.view(torch.uint8).view(N, D_NOPE)          # [N, 448] uint8
    rope_bytes = rope_bf16.view(torch.uint8).view(N, D_ROPE * 2)     # [N, 128] uint8
    scales = scales_ue8m0.view(N, D_NOPE // 64)                      # [N, 7] uint8

    # Tile into pages
    nope_paged = nope_bytes.view(num_pages, page_size, D_NOPE)       # [P, S, 448]
    rope_paged = rope_bytes.view(num_pages, page_size, D_ROPE * 2)   # [P, S, 128]
    scales_paged = scales.view(num_pages, page_size, D_NOPE // 64)   # [P, S, 7]

    raw_view[:, :, :D_NOPE] = nope_paged
    raw_view[:, :, D_NOPE:D_NOPE + D_ROPE * 2] = rope_paged
    raw_view[:, :, D_NOPE + D_ROPE * 2:D_NOPE + D_ROPE * 2 + (D_NOPE // 64)] = scales_paged

    k_cache = raw.view(torch.float8_e4m3fn).view(num_pages, page_size, 1, D_NOPE + D_ROPE * 2 + 8)
    return k_cache, kv_bf16


# ═══════════════════════════════════════════════════════════════════════════════
# Method A: Triton fused kernel
# ═══════════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def method_triton_kernel(q, k_cache, indices, topk_length, attn_sink, softmax_scale):
    """flash_mla_sparse_decode_triton — fully fused triton kernel."""
    return triton_kernel.flash_mla_sparse_decode_triton(
        q, k_cache, indices, topk_length, attn_sink,
        D_V, softmax_scale,
    )
    # Returns (out [B, 1, H, D_V], lse [B, 1, H])


# ═══════════════════════════════════════════════════════════════════════════════
# Method B: Optimized torch (deep merge)
# ═══════════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def method_torch_opt(q, k_cache, indices, topk_length, attn_sink, softmax_scale):
    """flash_mla_decode_torch — overlapping fp8/bf16 views + fused gather."""
    # Our impl expects indices [B, s_q, topk] but we have [B, topk] — add s_q dim
    if indices.ndim == 2:
        indices_3d = indices.unsqueeze(1)  # [B, 1, topk]
    else:
        indices_3d = indices
    out, lse = ref_torch.flash_mla_decode_torch(
        q=q,
        k_cache=k_cache,
        indices=indices_3d,
        head_dim_v=D_V,
        softmax_scale=softmax_scale,
        attn_sink=attn_sink,
        topk_length=topk_length,
    )
    # Returns (out [B, 1, H, D_V], lse [B, H, 1])
    return out, lse


# ═══════════════════════════════════════════════════════════════════════════════
# Method C: Original torch (dequantize all + gather)
# ═══════════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def method_torch_orig(q, k_cache, indices, topk_length, attn_sink, softmax_scale):
    """dequantize_k_cache + manual gather + PyTorch attention."""
    b, s_q, h_q, d_qk = q.shape
    topk = indices.shape[-1]

    # Our impl expects indices [B, s_q, topk]; if 2D, add s_q dim
    if indices.ndim == 2:
        indices_3d = indices.unsqueeze(1)  # [B, 1, topk]
    else:
        indices_3d = indices

    # Dequantize ALL tokens
    kv_deq = dequantize_k_cache(k_cache, FP8KVCacheLayout.MODEL1_FP8Sparse)
    kv_flat = kv_deq.view(-1, d_qk)

    # Gather needed tokens
    gathered = kv_flat[indices_3d.view(-1)].view(b, s_q, topk, d_qk).float()
    gathered[gathered != gathered] = 0.0  # NaN → 0
    invalid = indices_3d < 0
    if topk_length is not None:
        invalid |= (
            torch.arange(topk, device=indices.device).view(1, 1, -1)
            >= topk_length.view(b, 1, 1)
        )

    # Attention
    q_flat = q.float().view(b * s_q, h_q, d_qk)
    gkv_flat = gathered.view(b * s_q, topk, d_qk)
    attn = q_flat @ gkv_flat.transpose(-1, -2)
    attn *= softmax_scale
    attn[invalid.view(b * s_q, 1, topk).broadcast_to(b * s_q, h_q, topk)] = float("-inf")

    lse = attn.logsumexp(dim=-1)
    attn = torch.exp(attn - lse.unsqueeze(-1))
    out = attn @ gkv_flat[..., :D_V]
    out = out.view(b, s_q, h_q, D_V)
    lse = lse.view(b, s_q, h_q)

    if attn_sink is not None:
        out *= (1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - lse))).unsqueeze(-1)

    lonely = lse == float("-inf")
    out[lonely.unsqueeze(-1).broadcast_to(b, s_q, h_q, D_V)] = 0.0
    lse[lonely] = float("+inf")

    return out.to(torch.bfloat16), lse.transpose(1, 2)


# ═══════════════════════════════════════════════════════════════════════════════
# Test runner — single config
# ═══════════════════════════════════════════════════════════════════════════════

@torch.inference_mode()
def compare(
    B: int, H: int,
    kv_tokens: int, topk: int, page_size: int = 64,
    use_sink: bool = True, use_topk_len: bool = True,
    num_bench: int = 100,
):
    device = torch.device("cuda:0")
    softmax_scale = D_QK ** -0.5
    s_q = 1  # decode

    # ── Generate Q ───────────────────────────────────────────────────────
    q = torch.randn(B, s_q, H, D_QK, dtype=torch.bfloat16, device=device) / 10

    # ── Generate KV cache ─────────────────────────────────────────────────
    kv_bf16 = torch.randn(kv_tokens, D_QK, dtype=torch.bfloat16, device=device) / 10
    k_cache, kv_bf16_padded = build_fp8_kv_cache(kv_bf16, page_size)
    total_padded = kv_bf16_padded.shape[0]

    # ── Generate indices ──────────────────────────────────────────────────
    indices = torch.full((B, topk), -1, dtype=torch.int32, device=device)
    for b in range(B):
        n_valid = min(total_padded, topk)
        perm = torch.randperm(total_padded, device=device)[:n_valid]
        indices[b, :n_valid] = perm.to(torch.int32)

    # ── Topk length ───────────────────────────────────────────────────────
    topk_length = None
    if use_topk_len:
        topk_length = torch.randint(topk // 2 + 1, topk + 1, (B,), dtype=torch.int32, device=device)

    # ── Attn sink ─────────────────────────────────────────────────────────
    attn_sink = None
    if use_sink:
        attn_sink = torch.randn(H, dtype=torch.float32, device=device)

    cfg = f"B={B:<3} H={H:<4} topk={topk:<5} kv={kv_tokens:<6} pg={page_size}"
    print(f"\n{'='*70}")
    print(f"  {cfg}")
    print(f"{'='*70}")

    # ── Run all three ─────────────────────────────────────────────────────
    results = {}

    for name, fn in [
        ("torch_orig", method_torch_orig),
        ("torch_opt",  method_torch_opt),
        ("triton_kernel", method_triton_kernel),
    ]:
        try:
            out, lse = fn(q, k_cache, indices, topk_length, attn_sink, softmax_scale)

            # Warmup
            for _ in range(5):
                fn(q, k_cache, indices, topk_length, attn_sink, softmax_scale)
            torch.cuda.synchronize()

            t0 = time.perf_counter()
            for _ in range(num_bench):
                fn(q, k_cache, indices, topk_length, attn_sink, softmax_scale)
            torch.cuda.synchronize()
            elapsed = (time.perf_counter() - t0) * 1000 / num_bench

            results[name] = {"out": out, "lse": lse, "ms": elapsed}
            print(f"  {name:<18} {elapsed:>8.3f} ms")

        except Exception as e:
            print(f"  {name:<18} ERROR: {e}")
            import traceback; traceback.print_exc()

    # ── Compare errors ────────────────────────────────────────────────────
    if len(results) >= 2:
        print(f"\n  {'─'*50}")
        print(f"  Error comparison (vs torch_orig as reference)")
        print(f"  {'─'*50}")

        ref = results.get("torch_orig")
        if ref is not None:
            for name in ["torch_opt", "triton_kernel"]:
                r = results.get(name)
                if r is None:
                    continue
                # Align shapes
                out_ref = ref["out"].float()
                lse_ref = ref["lse"].float()
                out_cmp = r["out"].float()
                lse_cmp = r["lse"].float()

                # Ensure same shape
                if out_cmp.shape != out_ref.shape:
                    out_cmp = out_cmp.view_as(out_ref)
                if lse_cmp.shape != lse_ref.shape:
                    lse_cmp = lse_cmp.view_as(lse_ref)

                out_diff = (out_cmp - out_ref).abs()
                lse_diff = (lse_cmp - lse_ref).abs()
                out_diff = torch.nan_to_num(out_diff, nan=0.0, posinf=float("inf"), neginf=0.0)
                lse_diff = torch.nan_to_num(lse_diff, nan=0.0, posinf=float("inf"), neginf=0.0)

                print(f"  {name} vs torch_orig:")
                print(f"    out max_err={out_diff.max():.4e}  mean_err={out_diff.mean():.4e}")
                print(f"    lse max_err={lse_diff.max():.4e}  mean_err={lse_diff.mean():.4e}")

    # ── Speed comparison ──────────────────────────────────────────────────
    if len(results) >= 2:
        print(f"\n  {'─'*50}")
        print(f"  Speed comparison")
        print(f"  {'─'*50}")
        orig_ms = results.get("torch_orig", {}).get("ms", None)
        if orig_ms is not None:
            for name in ["torch_opt", "triton_kernel"]:
                r = results.get(name)
                if r is None:
                    continue
                speedup = orig_ms / r["ms"]
                print(f"  {name} vs torch_orig: {speedup:.2f}x {'faster' if speedup > 1 else 'slower'} "
                      f"({orig_ms:.3f} → {r['ms']:.3f} ms)")

    return results


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    if not torch.cuda.is_available():
        print("CUDA not available.")
        return

    device = torch.device("cuda:0")
    torch.set_default_dtype(torch.bfloat16)
    torch.set_default_device(device)
    torch.cuda.set_device(device)
    torch.set_float32_matmul_precision("high")

    print("=" * 70)
    print("3-Way Comparison: Triton Fused vs Torch Optimized vs Torch Original")
    print(f"  d_qk={D_QK}  d_nope={D_NOPE}  d_rope={D_ROPE}  d_v={D_V}")
    print(f"  GPU: {torch.cuda.get_device_name(0)}")
    print("=" * 70)

    configs = [
        # (B, H, kv_tokens, topk, page_size, use_sink, use_topk_len, num_bench)
        # Small batch, small topk
        (1,   128, 1200000, 128, 64, True,  False, 200),
        (4,   128, 1200000, 128, 64, True,  False, 100),
        (8,   128, 1200000, 128, 64, True,  False, 100),
        (16,  128, 1200000, 128, 64, True,  False, 100),
        (32,  128, 1200000, 128, 64, True,  False,  50),
        # Large topk
        (1,   128, 1200000, 512, 64, True,  False, 100),
        (4,   128, 1200000, 512, 64, True,  False,  50),
        (8,   128, 1200000, 512, 64, True,  False,  50),
        (16,  128, 1200000, 512, 64, True,  False,  30),
        (32,  128, 1200000, 512, 64, True,  False,  20),
    ]

    all_ok = True
    for cfg in configs:
        try:
            results = compare(*cfg)
            # Quick sanity: torch_opt should match torch_orig closely
            ref = results.get("torch_orig")
            opt = results.get("torch_opt")
            if ref and opt:
                diff = (opt["out"].float() - ref["out"].float()).abs().max()
                if diff > 0.5:
                    print(f"  ⚠ torch_opt large deviation: {diff:.4f}")
                    all_ok = False
        except Exception as e:
            print(f"  FAILED: {e}")
            all_ok = False

    print(f"\n{'='*70}")
    if all_ok:
        print("All comparisons completed successfully")
    else:
        print("Some comparisons had issues — check above")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
