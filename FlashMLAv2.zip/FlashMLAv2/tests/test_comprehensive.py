"""
Comprehensive correctness test with edge cases.
"""
import sys, types, os
sys.path.insert(0, '/home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA')

_mock_cuda = types.ModuleType('flash_mla.cuda')
sys.modules['flash_mla.cuda'] = _mock_cuda

import torch, importlib.util

_spec = importlib.util.spec_from_file_location(
    'ref_torch', os.path.join(os.path.dirname(__file__), '..', 'flash_mla', 'torch', 'ref.py'),
)
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)

from tests.quant import quantize_k_cache, dequantize_k_cache, FP8KVCacheLayout


def compute_ref_output(q, k_cache, indices, head_dim_v, softmax_scale,
                       attn_sink=None, topk_length=None,
                       extra_k_cache=None, extra_indices=None, extra_topk_length=None):
    b, s_q, h_q, d_qk = q.shape
    d_v = head_dim_v

    def gather_and_dequant(kc, idx, tl):
        kv_deq = dequantize_k_cache(kc, FP8KVCacheLayout.V32_FP8Sparse if d_qk == 576
                                    else FP8KVCacheLayout.MODEL1_FP8Sparse)
        kv_flat = kv_deq.view(-1, d_qk)
        topk = idx.shape[-1]
        gathered = kv_flat[idx.view(-1)].view(b, s_q, topk, d_qk).float()
        invalid = idx < 0
        if tl is not None:
            invalid |= torch.arange(topk, device=idx.device).view(1, 1, -1) >= tl.view(b, 1, 1)
        gathered[gathered != gathered] = 0.0
        return gathered, invalid

    gkv, inv = gather_and_dequant(k_cache, indices, topk_length)
    if extra_k_cache is not None:
        egkv, einv = gather_and_dequant(extra_k_cache, extra_indices, extra_topk_length)
        gkv = torch.cat([gkv, egkv], dim=2)
        inv = torch.cat([inv, einv], dim=2)
    total_topk = gkv.shape[2]

    q_flat = q.float().view(b * s_q, h_q, d_qk)
    gkv_flat = gkv.view(b * s_q, total_topk, d_qk)
    attn = q_flat @ gkv_flat.transpose(-1, -2)
    attn *= softmax_scale
    attn[inv.view(b * s_q, 1, total_topk).broadcast_to(b * s_q, h_q, total_topk)] = float("-inf")
    lse = attn.logsumexp(dim=-1)
    attn = torch.exp(attn - lse.unsqueeze(-1))
    out = attn @ gkv_flat[..., :d_v]
    out = out.view(b, s_q, h_q, d_v)
    lse = lse.view(b, s_q, h_q)
    if attn_sink is not None:
        out *= (1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - lse))).unsqueeze(-1)
    lonely = lse == float("-inf")
    out[lonely.unsqueeze(-1).broadcast_to(b, s_q, h_q, d_v)] = 0.0
    lse[lonely] = float("+inf")
    return out.to(torch.bfloat16), lse.transpose(1, 2)


@torch.inference_mode()
def test_case(desc, d_qk, b, s_q, h_q, topk, s_k, block_size, has_sink=True,
              has_tl=False, extra=False):
    device = torch.device("cuda:0")
    d_v = 512
    layout = FP8KVCacheLayout.V32_FP8Sparse if d_qk == 576 else FP8KVCacheLayout.MODEL1_FP8Sparse
    num_blocks = (s_k + block_size - 1) // block_size
    N = num_blocks * block_size

    q = torch.randn(b, s_q, h_q, d_qk, dtype=torch.bfloat16, device=device)
    kv_bf16 = torch.randn(num_blocks, block_size, 1, d_qk, dtype=torch.bfloat16, device=device).clamp_(-1, 1)
    k_cache = quantize_k_cache(kv_bf16, layout)

    indices = torch.randint(0, N, (b, s_q, topk), dtype=torch.int32, device=device)
    indices[torch.rand(b, s_q, topk, device=device) < 0.1] = -1

    attn_sink = torch.randn(h_q, dtype=torch.float32, device=device) if has_sink else None
    if has_sink:
        attn_sink[torch.rand(h_q, device=device) < 0.1] = float("-inf")
        attn_sink[torch.rand(h_q, device=device) < 0.1] = float("+inf")

    tl = torch.randint(1, topk + 1, (b,), dtype=torch.int32, device=device) if has_tl else None

    ek, ei, etl = None, None, None
    if extra:
        extra_topk = topk // 2
        e_blocks = (s_k // 2 + block_size - 1) // block_size
        ekv = torch.randn(e_blocks, block_size, 1, d_qk, dtype=torch.bfloat16, device=device).clamp_(-1, 1)
        ek = quantize_k_cache(ekv, layout)
        ei = torch.randint(0, e_blocks * block_size, (b, s_q, extra_topk), dtype=torch.int32, device=device)
        ei[torch.rand(b, s_q, extra_topk, device=device) < 0.1] = -1

    ss = d_qk ** (-0.5)

    out_ref, lse_ref = compute_ref_output(q, k_cache, indices, d_v, ss, attn_sink, tl, ek, ei, etl)
    out_new, lse_new = ref_torch.flash_mla_decode_torch(
        q=q, k_cache=k_cache, indices=indices,
        head_dim_v=d_v, softmax_scale=ss, attn_sink=attn_sink,
        extra_k_cache=ek, extra_indices=ei,
        topk_length=tl, extra_topk_length=etl,
    )

    out_ok = torch.allclose(out_new.float(), out_ref.float(), atol=1e-2, rtol=1e-2)
    lse_ok = torch.allclose(lse_new.float(), lse_ref.float(), atol=1e-2, rtol=1e-2)
    out_diff = (out_new.float() - out_ref.float()).abs()
    lse_diff = (lse_new.float() - lse_ref.float()).abs()
    status = "PASS" if (out_ok and lse_ok) else "FAIL"
    print(f"[{status}] {desc}: out_max={out_diff.max():.4e} lse_max={lse_diff.max():.4e}")
    return out_ok and lse_ok


if __name__ == "__main__":
    all_pass = True
    for d_qk in [576, 512]:
        bs = 128 if d_qk == 576 else 64
        all_pass &= test_case(f"d_qk={d_qk} basic", d_qk, 4, 1, 32, 64, 512, bs, has_sink=False)
        all_pass &= test_case(f"d_qk={d_qk} +sink", d_qk, 4, 1, 32, 64, 512, bs, has_sink=True)
        all_pass &= test_case(f"d_qk={d_qk} +topk_length", d_qk, 4, 2, 64, 128, 1024, bs, has_sink=True, has_tl=True)
        all_pass &= test_case(f"d_qk={d_qk} +extra_kv", d_qk, 4, 1, 32, 64, 512, bs, has_sink=True, extra=True)
        all_pass &= test_case(f"d_qk={d_qk} large", d_qk, 8, 2, 128, 256, 4096, bs, has_sink=True, has_tl=True)
    if all_pass:
        print("\nAll comprehensive tests PASSED")
    else:
        print("\nSome tests FAILED")
        sys.exit(1)
