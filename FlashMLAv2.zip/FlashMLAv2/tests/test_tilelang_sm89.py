"""
test_tilelang_sm89.py
=====================
Correctness and (optional) performance tests for the SM89 TileLang
implementation of FlashMLA sparse decode.

Uses the same lib.py / ref.py infrastructure as the official CUDA tests.
Run with:
  cd /home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA/tests
  /home/lxt/sglang-deepseekv4/venv/bin/python test_tilelang_sm89.py
"""

import sys, os, time, dataclasses, types
from typing import List, Optional, Tuple

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import torch

# ---- Mock flash_mla.cuda so that lib.py can be imported without the CUDA ext ----
# lib.py does `import flash_mla` which tries to import flash_mla.cuda.
# We provide a stub so we can use the test infrastructure without rebuilding the ext.
_mock_cuda = types.ModuleType("flash_mla.cuda")
sys.modules["flash_mla.cuda"] = _mock_cuda

_mock_flash_mla_pkg = types.ModuleType("flash_mla")
# Stub the public API used by lib.py / ref.py
for _attr in ["get_mla_metadata", "flash_mla_with_kvcache",
              "flash_mla_sparse_fwd", "flash_attn_varlen_func",
              "flash_attn_varlen_qkvpacked_func", "flash_attn_varlen_kvpacked_func"]:
    setattr(_mock_flash_mla_pkg, _attr, None)
sys.modules["flash_mla"] = _mock_flash_mla_pkg

# ---- Import the SM89 module directly to avoid flash_mla.cuda dependency ----
import importlib.util
_spec = importlib.util.spec_from_file_location(
    "tilelang_sm89",
    os.path.join(os.path.dirname(__file__), "..", "flash_mla", "tilelang_sm89.py"),
)
sm89 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sm89)

sm89_flash_mla = sm89.flash_mla_with_kvcache
sm89_get_meta  = sm89.get_mla_metadata

# ---- Test infrastructure ----
import lib
from lib import TestParam, RawTestParamForDecode as RawTestParam
import ref

try:
    import kernelkit as kk
    def check_close(name, a, b, abs_tol, rel_tol):
        return kk.check_is_allclose(name, a, b, abs_tol=abs_tol, rel_tol=rel_tol)
except ImportError:
    def check_close(name, a, b, abs_tol, rel_tol):
        ok = torch.allclose(a.float(), b.float(), atol=abs_tol, rtol=rel_tol)
        if not ok:
            diff = (a.float() - b.float()).abs()
            print(f"  [{name}] MISMATCH max={diff.max():.4e} mean={diff.mean():.4e}")
        return ok


# ---------------------------------------------------------------------------
# Test case generation
# ---------------------------------------------------------------------------

def gen_correctness_cases() -> List[RawTestParam]:
    """Small correctness cases covering all feature combinations."""
    cases = []
    for d_qk in [576, 512]:
        # extra_k only supported in MODEL1 style in the original CUDA kernel
        have_extra_k_opts = [False, True] if d_qk == 512 else [False]
        for have_extra_k in have_extra_k_opts:
            have_etl_opts = [False, True] if have_extra_k else [False]
            for have_etl in have_etl_opts:
                for have_topk_len in ([False, True] if d_qk == 512 else [False]):
                    for h_q in [16, 64, 128]:
                        for (s_k, topk, block_size) in [
                            (512,  64, 2),
                            (512,  64, 64),
                            (1024, 128, 4),
                        ]:
                            for (extra_sk, extra_topk, extra_bs) in (
                                [(512, 64, 4), (512, 128, 2)] if have_extra_k
                                else [(None, None, None)]
                            ):
                                for b in [1, 4, 8]:
                                    for s_q in [1, 2]:
                                        cases.append(RawTestParam(
                                            b=b, h_q=h_q, s_q=s_q, h_kv=1,
                                            s_kv=s_k, is_varlen=True, topk=topk,
                                            have_topk_length=have_topk_len,
                                            enable_attn_sink=True,
                                            extra_s_k=extra_sk,
                                            extra_topk=extra_topk,
                                            block_size=block_size,
                                            extra_block_size=extra_bs,
                                            have_extra_topk_length=have_etl,
                                            d_qk=d_qk,
                                            check_correctness=True,
                                            num_runs=0,
                                        ))
    return cases


def gen_corner_cases() -> List[RawTestParam]:
    """Edge cases: all-invalid indices, zero seqlen, attn_sink with +inf/-inf."""
    cases = []
    for d_qk in [576, 512]:
        for h_q in [16, 64, 128]:
            for b in [4]:
                for is_all_inv in [True, False]:
                    for have_zero in [True, False]:
                        for have_sink in [True, False]:
                            if not (is_all_inv or have_zero or have_sink):
                                continue
                            cases.append(RawTestParam(
                                b=b, h_q=h_q, s_q=2, h_kv=1,
                                s_kv=256, is_varlen=True, topk=64,
                                is_all_indices_invalid=is_all_inv,
                                have_zero_seqlen_k=have_zero,
                                enable_attn_sink=have_sink,
                                block_size=4, d_qk=d_qk,
                                check_correctness=True, num_runs=0,
                            ))
    return cases


def gen_performance_cases() -> List[RawTestParam]:
    """Production-size benchmark cases."""
    return [
        # DeepSeek V3.2 shape
        RawTestParam(74, 128, 2, 1, 32768, True, topk=2048, d_qk=576,
                     enable_attn_sink=True, num_runs=10),
        # MODEL1 CONFIG1
        RawTestParam(74, 64, 2, 1, 16384, True, topk=128, d_qk=512,
                     extra_s_k=16384, extra_topk=512,
                     block_size=256, extra_block_size=64,
                     enable_attn_sink=True, num_runs=10),
    ]


# ---------------------------------------------------------------------------
# Run one test
# ---------------------------------------------------------------------------

@torch.inference_mode()
def run_test(p: TestParam, verbose: bool = False) -> bool:
    if verbose:
        print(f"  b={p.decode.b} s_q={p.s_q} h_q={p.h_q} sk={p.s_kv} "
              f"topk={p.topk} d_qk={p.d_qk} "
              f"extra_topk={p.decode.extra_topk} "
              f"have_tl={p.have_topk_length} have_etl={p.decode.have_extra_topk_length} "
              f"sink={p.have_attn_sink}")

    t = lib.generate_testcase_for_decode(p)
    meta, _ = sm89_get_meta()

    def run():
        kv    = t.kv_scope.get_kvcache_for_flash_mla()
        ekv   = t.extra_kv_scope.get_kvcache_for_flash_mla() if t.extra_kv_scope else None
        eidx  = t.extra_kv_scope.indices_in_kvcache if t.extra_kv_scope else None
        etl   = (t.extra_kv_scope.topk_length
                 if t.extra_kv_scope and t.extra_kv_scope.topk_length is not None
                 else None)
        return sm89_flash_mla(
            t.q, kv, None, None, p.d_v, meta, None,
            t.sm_scale, False, True,
            t.kv_scope.indices_in_kvcache, t.attn_sink,
            ekv, eidx,
            t.kv_scope.topk_length, etl,
        )

    out_ans, lse_ans = run()

    is_correct = True
    if p.check_correctness:
        out_ref, lse_ref = ref.ref_sparse_attn_decode(p, t)
        # TileLang BF16 kernels have wider numerical noise than the CUDA bf16
        # kernel due to: BF16 dequant (CUDA uses f32), BF16 GEMM accumulation
        # for QK^T, and FP8 round-trip differences.
        ok_out = check_close("out", out_ans, out_ref, abs_tol=5e-2, rel_tol=8.0/128)
        ok_lse = check_close("lse", lse_ans, lse_ref, abs_tol=1e-1, rel_tol=4.0/128)
        is_correct = ok_out and ok_lse

    if p.num_runs > 0 and is_correct:
        import kernelkit as kk
        t0 = time.perf_counter()
        for _ in range(p.num_runs):
            run()
        torch.cuda.synchronize()
        elapsed_ms = (time.perf_counter() - t0) * 1000 / p.num_runs
        print(f"    → {elapsed_ms:.2f} ms/iter")

    return is_correct


# ---------------------------------------------------------------------------
# Split test: verify _split_kvcache_fp8 round-trips correctly
# ---------------------------------------------------------------------------

def test_split_roundtrip():
    """Verify that split->dequant in Python matches quant.dequantize_k_cache."""
    import sys
    sys.path.insert(0, os.path.dirname(__file__))
    import quant

    print("Testing _split_kvcache_fp8 round-trip...")
    for d_qk in [576, 512]:
        num_blocks, block_size = 8, 64
        h_kv = 1
        if d_qk == 576:
            layout = quant.FP8KVCacheLayout.V32_FP8Sparse
        else:
            layout = quant.FP8KVCacheLayout.MODEL1_FP8Sparse

        # Random BF16 KV cache
        kv_bf16 = torch.randn(num_blocks, block_size, h_kv, d_qk, dtype=torch.bfloat16).cuda()
        kv_bf16.clamp_(-1, 1)

        # Quantize
        kv_fp8 = quant.quantize_k_cache(kv_bf16, layout)  # [B, S, 1, bytes_per_token] fp8

        # Dequantize via official function
        kv_dequant_ref = quant.dequantize_k_cache(kv_fp8, layout)  # [B, S, 1, d_qk] bf16

        # Our split
        kv_flat, k_scale, k_rope = sm89._split_kvcache_fp8(kv_fp8, d_qk)

        N = num_blocks * block_size
        if d_qk == 576:
            d_nope, d_rope = 512, 64
        else:
            d_nope, d_rope = 448, 64

        # Reconstruct dequantized from our split
        kv_flat_ref = kv_dequant_ref.squeeze(2).reshape(N, d_qk)  # [N, d_qk] bf16

        # k_rope_bf16 should match rope part of dequant
        rope_ref = kv_flat_ref[:, d_nope:]
        rope_ok = torch.allclose(k_rope.float(), rope_ref.float(), atol=1e-4)
        print(f"  d_qk={d_qk} rope match: {rope_ok}")

        print(f"  d_qk={d_qk} kv_flat shape: {kv_flat.shape}, scale shape: {k_scale.shape}, rope shape: {k_rope.shape}")

    print("Split round-trip test done.\n")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    device = torch.device("cuda:0")
    torch.set_default_dtype(torch.bfloat16)
    torch.set_default_device(device)
    torch.cuda.set_device(device)
    torch.set_float32_matmul_precision("high")
    torch.set_num_threads(16)

    print("=" * 60)
    print("FlashMLA SM89 TileLang Test Suite")
    print("=" * 60)

    # ---- Split round-trip ----
    test_split_roundtrip()

    # ---- Correctness tests ----
    raw_correctness = gen_correctness_cases()
    raw_corner      = gen_corner_cases()
    all_raw = raw_correctness + raw_corner

    print(f"Running {len(all_raw)} correctness + corner cases...")
    params = [r.to_test_param() for r in all_raw]
    # Auto-assign seeds (seed=-1 means not yet set)
    for i, p in enumerate(params):
        if p.seed == -1:
            p.seed = i

    failed = []
    for i, p in enumerate(params):
        print(f"[{i+1:4d}/{len(params)}] ", end="", flush=True)
        try:
            ok = run_test(p, verbose=True)
        except Exception as e:
            print(f"  EXCEPTION: {e}")
            ok = False
        if not ok:
            failed.append(p)
            print("  *** FAILED ***")

    print()
    n_pass = len(params) - len(failed)
    if not failed:
        print(f"\033[32m\033[1mAll {len(params)} correctness tests PASSED\033[0m")
    else:
        print(f"\033[31m\033[1m{len(failed)} tests FAILED out of {len(params)}\033[0m")
        for p in failed:
            print(f"  {p}")
        sys.exit(1)

    # ---- Performance (optional) ----
    perf_cases = gen_performance_cases()
    if perf_cases:
        print("\nRunning performance cases...")
        for r in perf_cases:
            p = r.to_test_param()
            print(f"  d_qk={p.d_qk} h_q={p.h_q} b={p.decode.b} topk={p.topk} "
                  f"extra_topk={p.decode.extra_topk}", end=" ")
            run_test(p, verbose=False)


if __name__ == "__main__":
    main()
