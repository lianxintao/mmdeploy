"""
Verify the deep-merged dequant+gather implementation against the reference.
"""
import sys
sys.path.insert(0, '/home/lxt/sglang-deepseekv4/flashmla_warp/FlashMLA')

import types
_mock_cuda = types.ModuleType("flash_mla.cuda")
sys.modules["flash_mla.cuda"] = _mock_cuda

import torch, importlib.util, os

_spec = importlib.util.spec_from_file_location(
    "ref_torch", os.path.join(os.path.dirname(__file__), "..", "flash_mla", "torch", "ref.py"),
)
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)

from tests.quant import quantize_k_cache, dequantize_k_cache, FP8KVCacheLayout


@torch.inference_mode()
def test_flatten_roundtrip():
    """Verify _flatten_kvcache + manual dequant matches dequantize_k_cache."""
    device = torch.device("cuda:0")

    for d_qk in [576, 512]:
        if d_qk == 576:
            layout = FP8KVCacheLayout.V32_FP8Sparse
            num_blocks, block_size = 4, 128
        else:
            layout = FP8KVCacheLayout.MODEL1_FP8Sparse
            num_blocks, block_size = 4, 64

        kv_bf16 = torch.randn(num_blocks, block_size, 1, d_qk,
                              dtype=torch.bfloat16, device=device).clamp_(-1, 1)
        kv_fp8_data = quantize_k_cache(kv_bf16, layout)
        kv_ref = dequantize_k_cache(kv_fp8_data, layout).squeeze(2)
        N = num_blocks * block_size

        (kv_fp8, kv_bf16, k_scale, d_nope, d_rope,
         n_tiles, t_size, rope_off, _e8m0) = ref_torch._flatten_kvcache(kv_fp8_data, d_qk)

        # Reconstruct nope from fp8 view  (nope at offset 0)
        nope_fp8_vals = kv_fp8[:, :d_nope].float()
        scale_f32 = (torch.pow(2.0, k_scale.float() - 127.0) if _e8m0
                     else k_scale.float())
        for ti in range(n_tiles):
            t_off = ti * t_size
            nope_fp8_vals[:, t_off:t_off + t_size] *= scale_f32[:, ti:ti + 1]

        # Reconstruct rope from bf16 view
        rope_vals = kv_bf16[:, rope_off : rope_off + d_rope]

        reconstructed = torch.cat([nope_fp8_vals.to(torch.bfloat16), rope_vals], dim=1)

        diff = (reconstructed.float() - kv_ref.float().reshape(N, d_qk)).abs()
        max_diff = diff.max().item()
        mean_diff = diff.mean().item()
        print(f"d_qk={d_qk} flatten round-trip: max_diff={max_diff:.6f}, mean_diff={mean_diff:.6f}")
        assert max_diff < 0.1, f"FAIL: d_qk={d_qk} max_diff={max_diff}"
    print("flatten_roundtrip test PASSED\n")


@torch.inference_mode()
def test_fused_gather():
    """Verify fused dequant+gather matches dequantize + manual gather."""
    device = torch.device("cuda:0")

    for d_qk in [576, 512]:
        if d_qk == 576:
            layout = FP8KVCacheLayout.V32_FP8Sparse
            num_blocks, block_size = 8, 128
        else:
            layout = FP8KVCacheLayout.MODEL1_FP8Sparse
            num_blocks, block_size = 8, 64

        kv_bf16 = torch.randn(num_blocks, block_size, 1, d_qk,
                              dtype=torch.bfloat16, device=device).clamp_(-1, 1)
        kv_fp8_data = quantize_k_cache(kv_bf16, layout)
        kv_ref = dequantize_k_cache(kv_fp8_data, layout)

        (kv_fp8, kv_bf16, k_scale, d_nope, d_rope,
         n_tiles, t_size, rope_off, _e8m0) = ref_torch._flatten_kvcache(kv_fp8_data, d_qk)

        N = num_blocks * block_size
        topk = 32
        perm = torch.randperm(N, device=device)[:topk]
        indices = perm.view(1, 1, topk).contiguous()

        gathered_fused, _ = ref_torch._fused_gather_kv(
            kv_fp8, kv_bf16, k_scale, indices, None,
            d_nope, d_rope, n_tiles, t_size, rope_off, scale_is_e8m0=_e8m0,
        )

        kv_ref_flat = kv_ref.squeeze(2).reshape(-1, d_qk)
        expected = kv_ref_flat[perm].view(1, 1, topk, d_qk)

        diff = (gathered_fused.float() - expected.float()).abs()
        max_diff = diff.max().item()
        mean_diff = diff.mean().item()
        print(f"d_qk={d_qk} fused_gather: max_diff={max_diff:.6f}, mean_diff={mean_diff:.6f}")
        assert max_diff < 0.1, f"FAIL: d_qk={d_qk} max_diff={max_diff}"
    print("fused_gather test PASSED\n")


@torch.inference_mode()
def test_decode_end_to_end():
    """End-to-end test comparing flash_mla_decode_torch against manual reference."""
    device = torch.device("cuda:0")

    for d_qk in [576, 512]:
        if d_qk == 576:
            layout = FP8KVCacheLayout.V32_FP8Sparse
            block_size, topk = 128, 64
        else:
            layout = FP8KVCacheLayout.MODEL1_FP8Sparse
            block_size, topk = 64, 64

        b, s_q, h_q, d_v = 2, 1, 16, 512
        num_blocks = max(topk * 2 // block_size, 4)

        q = torch.randn(b, s_q, h_q, d_qk, dtype=torch.bfloat16, device=device)
        kv_bf16 = torch.randn(num_blocks, block_size, 1, d_qk,
                              dtype=torch.bfloat16, device=device).clamp_(-1, 1)
        k_cache = quantize_k_cache(kv_bf16, layout)
        N = num_blocks * block_size
        indices = torch.randint(0, N, (b, s_q, topk), dtype=torch.int32, device=device)
        softmax_scale = d_qk ** (-0.5)
        attn_sink = torch.randn(h_q, dtype=torch.float32, device=device)

        out_new, lse_new = ref_torch.flash_mla_decode_torch(
            q=q, k_cache=k_cache, indices=indices,
            head_dim_v=d_v, softmax_scale=softmax_scale,
            attn_sink=attn_sink,
        )

        # Reference
        kv_deq = dequantize_k_cache(k_cache, layout)
        kv_flat = kv_deq.view(-1, d_qk)
        gathered = kv_flat[indices.view(-1)].view(b, s_q, topk, d_qk).float()
        gathered[gathered != gathered] = 0.0
        q_flat = q.float().view(b * s_q, h_q, d_qk)
        gkv_flat = gathered.view(b * s_q, topk, d_qk)

        attn_w = q_flat @ gkv_flat.transpose(-1, -2)
        attn_w *= softmax_scale
        lse_ref = attn_w.logsumexp(dim=-1)
        attn_w = torch.exp(attn_w - lse_ref.unsqueeze(-1))
        out_ref = attn_w @ gkv_flat[..., :d_v]
        out_ref = out_ref.view(b, s_q, h_q, d_v)
        lse_ref = lse_ref.view(b, s_q, h_q)
        if attn_sink is not None:
            out_ref *= (1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - lse_ref))).unsqueeze(-1)
        out_ref = out_ref.to(torch.bfloat16)
        lse_ref = lse_ref.transpose(1, 2)

        out_diff = (out_new.float() - out_ref.float()).abs()
        lse_diff = (lse_new.float() - lse_ref.float()).abs()
        print(f"d_qk={d_qk} decode: out max={out_diff.max():.6f} mean={out_diff.mean():.6f}")
        print(f"d_qk={d_qk} decode: lse max={lse_diff.max():.6f} mean={lse_diff.mean():.6f}")
        assert out_diff.max() < 0.5, f"FAIL: d_qk={d_qk}"
    print("decode_end_to_end test PASSED\n")


if __name__ == "__main__":
    test_flatten_roundtrip()
    test_fused_gather()
    test_decode_end_to_end()
