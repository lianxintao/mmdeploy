# FlashMLA Torch 优化版 — 测试与基准

## 文件变更概览

| 文件 | 变更 |
|------|------|
| `flash_mla/torch/ref.py` | **重写** — 融合 dequant 的 gather kernel，移除 TestParam / KVScope / TestcaseForDecode |
| `flash_mla/torch/debug_flash_mla_adapter.py` | **简化** — 直接调用 `flash_mla_decode_torch`，不再构造中间包装对象 |
| `tests/test_fused_dequant.py` | **新增** — 基础正确性测试（split round-trip + gather + 端到端） |
| `tests/test_comprehensive.py` | **新增** — 覆盖边缘情况的全面正确性测试 |
| `tests/bench_fused_dequant.py` | **新增** — 新旧方案性能对比基准 |

---

## 架构变化

```
旧方案:
  k_cache(FP8) → dequantize_k_cache(Python loop, 全部token) → blocked_k(BF16) [O(all_tokens)]
  → KVScope/TestParam/TestcaseForDecode(包装对象)
  → ref_sparse_attn_decode → triton gather kernel → gathered_kv → attention

新方案 (deep merge):
  k_cache(FP8) → _flatten_kvcache(重叠 fp8/bf16 视图, 共享同一内存, 仅 scale 预提取)
  → _fused_gather_kv(Triton, 直接从重叠视图读 nope(FP8)/rope(BF16), 即时 FP8→BF16)
  → attention
```

核心优化：
1. **消除全量反量化**：只处理 `b × s_q × topk` 个 token，不碰其余 token
2. **重叠内存视图**：`kv_fp8` 和 `kv_bf16` 共享同一块 contiguous 内存，nope 从 fp8 视图读、rope 从 bf16 视图读，零额外拷贝
3. **scale 预提取**：V32 的 float32 scale 零拷贝视图提取，MODEL1 的 e8m0 scale 在 Python 侧批量转为 f32（一次 `pow` 调用）

---

## 测试脚本

### 1. 基础正确性测试 (`tests/test_fused_dequant.py`)

验证三个层面的正确性：

- **split round-trip**：`_split_kvcache_fp8` 拆出的 (nope, scale, rope) 手动还原后与 `dequantize_k_cache` 输出一致
- **fused gather**：triton kernel 的 gather+dequant 结果与参考实现一致
- **端到端 decode**：`flash_mla_decode_torch` 完整输出（含 attn_sink）与手动计算一致

```bash
python tests/test_fused_dequant.py
```

预期输出（V32 & MODEL1 均通过）：
```
d_qk=576 split round-trip: max_diff=0.000000, mean_diff=0.000000
d_qk=512 split round-trip: max_diff=0.000000, mean_diff=0.000000
...
decode_end_to_end test PASSED
```

### 2. 全面正确性测试 (`tests/test_comprehensive.py`)

覆盖所有功能组合，共 10 个 test case：

| 测试场景 | d_qk=576 | d_qk=512 |
|----------|----------|----------|
| basic（无 attn_sink） | ✓ | ✓ |
| +attn_sink（含 ±inf） | ✓ | ✓ |
| +topk_length（变长序列） | ✓ | ✓ |
| +extra_kv（双 KV cache） | ✓ | ✓ |
| large（大批量+长序列） | ✓ | ✓ |

每个 case 自动注入 ~10% 无效 index（-1），attn_sink 随机混入 ±inf。

```bash
python tests/test_comprehensive.py
```

预期输出（全部 PASS）：
```
[PASS] d_qk=576 basic: out_max=0.0000e+00 lse_max=0.0000e+00
[PASS] d_qk=576 +sink: out_max=0.0000e+00 lse_max=0.0000e+00
...
[PASS] d_qk=512 large: out_max=0.0000e+00 lse_max=0.0000e+00

All comprehensive tests PASSED
```

### 3. 性能基准 (`tests/bench_fused_dequant.py`)

对比新旧方案在各环节的耗时：

| 对比项 | 说明 |
|--------|------|
| old: dequantize ALL tokens | 旧方案 Python loop 反量化全部 token |
| new: split kvcache | 新方案零拷贝视图拆分 |
| old: dequant + gather | 旧方案完整流程（反量化+索引） |
| new: fused dequant+gather | 新方案 triton kernel 融合方案 |
| new: full decode | 新方案端到端（split + gather + attention） |

测试参数：
- **V32 (d_qk=576)**：b=74, s_q=2, h_q=128, s_k=32768, topk=2048
- **MODEL1 (d_qk=512)**：b=74, s_q=2, h_q=128, s_k=16384, topk=128

```bash
python tests/bench_fused_dequant.py
```

### 旧方案 vs 方案二 (deep merge) 典型结果（RTX 4090）：
```
d_qk=576 (V32)
  old: dequantize ALL (32768 tokens):         0.643 ms
  new: flatten kvcache (overlapping views):   0.203 ms    ← 3.2x 加速
  old: dequant + gather (303104 tokens):      2.446 ms
  new: fused dequant+gather (303104 tokens):  1.759 ms    ← 1.4x 加速
  new: full decode:                          31.287 ms

d_qk=512 (MODEL1)
  old: dequantize ALL (16384 tokens):         0.255 ms
  new: flatten kvcache (overlapping views):   0.063 ms    ← 4.0x 加速
  old: dequant + gather (18944 tokens):       0.340 ms
  new: fused dequant+gather (18944 tokens):   0.152 ms    ← 2.2x 加速
  new: full decode:                           2.266 ms
```

> 加速比随 KV cache 规模增大而提升。当 `all_tokens ≫ gathered_tokens` 时收益最大。

### 4. 运行全部测试

```bash
# 一键运行所有测试和基准
python tests/test_fused_dequant.py && \
python tests/test_comprehensive.py && \
python tests/bench_fused_dequant.py
```

---

## 依赖与环境

- Python 3.10+
- PyTorch ≥ 2.4（需支持 `float8_e4m3fn` 和 `float8_e8m0fnu`）
- Triton ≥ 3.0（需支持 `tl.float8e4nv`）
- CUDA GPU（SM80+）

虚拟环境激活后直接运行，无需额外安装。
