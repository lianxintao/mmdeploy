from __future__ import annotations

import os
from functools import lru_cache
from typing import Optional, Tuple

import torch


def _tilelang_is_available() -> bool:
    try:
        import tilelang  # noqa: F401
    except Exception:
        return False
    return True


def _reference_fallback_enabled() -> bool:
    return os.getenv("FLASH_MLA_TILELANG_REFERENCE_FALLBACK", "").lower() in (
        "1",
        "true",
        "yes",
        "y",
    )


def should_use_tilelang_backend(device: torch.device) -> bool:
    """Return whether the sm89 TileLang-compatible backend should handle decode."""
    force = os.getenv("FLASH_MLA_FORCE_TILELANG", "").lower() in ("1", "true", "yes", "y")
    disable = os.getenv("FLASH_MLA_DISABLE_TILELANG", "").lower() in ("1", "true", "yes", "y")
    if disable:
        return False
    if force:
        return True
    if device.type != "cuda" or not torch.cuda.is_available():
        return False
    major, minor = torch.cuda.get_device_capability(device)
    return major == 8 and minor == 9


_DECODE_SCHED_META_INTS = 8


def _ceildiv(a: int, b: int) -> int:
    return (a + b - 1) // b


def _check_device(*tensors: Optional[torch.Tensor]) -> None:
    devices = [t.device for t in tensors if t is not None]
    if not devices:
        return
    first = devices[0]
    for device in devices[1:]:
        if device != first:
            raise AssertionError("all input tensors must be on the same device")


def _check_contiguous(tensor: Optional[torch.Tensor], name: str) -> None:
    if tensor is not None and not tensor.is_contiguous():
        raise AssertionError(f"{name} must be contiguous")


def _check_last_dim_contiguous(tensor: Optional[torch.Tensor], name: str) -> None:
    if tensor is not None and tensor.dim() > 0 and tensor.size(-1) != 1 and tensor.stride(-1) != 1:
        raise AssertionError(f"{name} must have contiguous last dimension")


def _num_sms(device: torch.device) -> int:
    return torch.cuda.get_device_properties(device).multi_processor_count


def _build_decode_scheduler_metadata(
    q: torch.Tensor,
    block_size_n: int,
    fixed_overhead_num_blocks: int,
    topk: int,
    extra_topk: int,
    topk_length: Optional[torch.Tensor],
    extra_topk_length: Optional[torch.Tensor],
    seqlens_k: Optional[torch.Tensor],
    num_sm_parts: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    b = q.shape[0]
    topk_length_cpu = topk_length.detach().cpu().tolist() if topk_length is not None else None
    extra_topk_length_cpu = (
        extra_topk_length.detach().cpu().tolist() if extra_topk_length is not None else None
    )
    seqlens_cpu = seqlens_k.detach().cpu().tolist() if seqlens_k is not None else None

    seqlens_for_sched = []
    num_blocks_per_req = []
    first_block_idx = []
    last_block_idx = []
    total_num_blocks = 0
    for i in range(b):
        if topk == -1:
            assert seqlens_cpu is not None
            cur_s_k = int(seqlens_cpu[i])
        else:
            cur_s_k = int(topk_length_cpu[i]) if topk_length_cpu is not None else topk
            if cur_s_k == 0:
                cur_s_k = 1
            if extra_topk:
                cur_s_k = _ceildiv(cur_s_k, block_size_n) * block_size_n
                cur_s_k += (
                    int(extra_topk_length_cpu[i]) if extra_topk_length_cpu is not None else extra_topk
                )

        seqlens_for_sched.append(cur_s_k)
        first = 0
        last_token_idx = max(cur_s_k - 1, 0)
        last = last_token_idx // block_size_n
        num_blocks = last - first + 1
        total_num_blocks += num_blocks + fixed_overhead_num_blocks
        num_blocks_per_req.append(num_blocks)
        first_block_idx.append(first)
        last_block_idx.append(last)

    payload = _ceildiv(total_num_blocks, num_sm_parts) + fixed_overhead_num_blocks
    metadata = torch.empty((num_sm_parts, _DECODE_SCHED_META_INTS), dtype=torch.int32)
    num_splits = torch.empty((b + 1,), dtype=torch.int32)

    now_req_idx = 0
    now_block = 0
    now_n_split_idx = 0
    cum_num_splits = 0
    num_splits[0] = 0
    for part in range(num_sm_parts):
        if now_req_idx >= b:
            metadata[part] = torch.tensor(
                [b, b - 1, 0, 0, now_n_split_idx, 0, 0, 0],
                dtype=torch.int32,
            )
            continue
        begin_req_idx = now_req_idx
        begin_block_idx = now_block + first_block_idx[now_req_idx]
        begin_split_idx = now_n_split_idx
        is_first_req_splitted = int(now_block != 0)
        remain_payload = payload

        while now_req_idx < b:
            num_blocks = num_blocks_per_req[now_req_idx]
            now_remain_blocks = num_blocks - now_block
            if remain_payload >= now_remain_blocks + fixed_overhead_num_blocks:
                cum_num_splits += now_n_split_idx + 1
                num_splits[now_req_idx + 1] = cum_num_splits
                remain_payload -= now_remain_blocks + fixed_overhead_num_blocks
                now_req_idx += 1
                now_block = 0
                now_n_split_idx = 0
            else:
                if remain_payload - fixed_overhead_num_blocks > 0:
                    now_block += remain_payload - fixed_overhead_num_blocks
                    now_n_split_idx += 1
                    remain_payload = 0
                break

        if now_block > 0:
            end_req_idx = now_req_idx
            end_block_idx = now_block + first_block_idx[now_req_idx]
        else:
            end_req_idx = now_req_idx - 1
            end_block_idx = (
                0
                if seqlens_for_sched[now_req_idx - 1] == 0
                else last_block_idx[now_req_idx - 1] + 1
            )
        is_last_req_splitted = int(
            end_block_idx != last_block_idx[end_req_idx] + 1 and seqlens_for_sched[end_req_idx] != 0
        )
        if begin_req_idx == end_req_idx:
            split_flag = int(is_first_req_splitted or is_last_req_splitted)
            is_first_req_splitted = split_flag
            is_last_req_splitted = split_flag

        metadata[part] = torch.tensor(
            [
                begin_req_idx,
                end_req_idx,
                begin_block_idx,
                end_block_idx,
                begin_split_idx,
                is_first_req_splitted,
                is_last_req_splitted,
                0,
            ],
            dtype=torch.int32,
        )

    return metadata.to(q.device), num_splits.to(q.device)


@lru_cache(maxsize=64)
def _get_dense_decode_kernel(
    b: int,
    s_q: int,
    h_q: int,
    h_k: int,
    d_qk: int,
    d_v: int,
    page_block_size: int,
    softmax_scale: float,
    causal: bool,
    dtype_name: str,
):
    import tilelang
    import tilelang.language as T

    dtype = T.float16 if dtype_name == "float16" else T.bfloat16
    accum_dtype = T.float32
    scale = float(softmax_scale)

    @tilelang.jit(out_idx=[4, 5])
    def dense_decode_kernel():
        @T.prim_func
        def main(
            Q: T.Tensor([b, s_q, h_q, d_qk], dtype),
            KCache: T.Tensor([T.Any(), page_block_size, h_k, d_qk], dtype),
            BlockTable: T.Tensor([b, T.Any()], T.int32),
            CacheSeqlens: T.Tensor([b], T.int32),
            Out: T.Tensor([b, s_q, h_q, d_v], dtype),
            Lse: T.Tensor([b, h_q, s_q], accum_dtype),
        ):
            with T.Kernel(b, s_q, h_q, d_v, threads=1) as (bid, qid, hid, vid):
                seqlen = T.alloc_var(T.int32)
                max_score = T.alloc_var(accum_dtype)
                score = T.alloc_var(accum_dtype)
                sum_exp = T.alloc_var(accum_dtype)
                acc = T.alloc_var(accum_dtype)
                block_offset = T.alloc_var(T.int32)
                token_offset = T.alloc_var(T.int32)
                block_id = T.alloc_var(T.int32)
                kv_hid = T.alloc_var(T.int32)
                valid = T.alloc_var(T.bool)

                seqlen = CacheSeqlens[bid]
                kv_hid = hid // (h_q // h_k)
                max_score = -T.infinity(accum_dtype)

                for k in T.serial(seqlen):
                    valid = True
                    if causal and s_q > 1:
                        valid = k <= seqlen - s_q + qid
                    if valid:
                        block_offset = k // page_block_size
                        token_offset = k - block_offset * page_block_size
                        block_id = BlockTable[bid, block_offset]
                        score = 0.0
                        for d in T.serial(d_qk):
                            score += Q[bid, qid, hid, d].astype(accum_dtype) * KCache[
                                block_id, token_offset, kv_hid, d
                            ].astype(accum_dtype)
                        score *= scale
                        max_score = T.max(max_score, score)

                sum_exp = 0.0
                acc = 0.0
                for k in T.serial(seqlen):
                    valid = True
                    if causal and s_q > 1:
                        valid = k <= seqlen - s_q + qid
                    if valid:
                        block_offset = k // page_block_size
                        token_offset = k - block_offset * page_block_size
                        block_id = BlockTable[bid, block_offset]
                        score = 0.0
                        for d in T.serial(d_qk):
                            score += Q[bid, qid, hid, d].astype(accum_dtype) * KCache[
                                block_id, token_offset, kv_hid, d
                            ].astype(accum_dtype)
                        score *= scale
                        score = T.exp(score - max_score)
                        sum_exp += score
                        acc += score * KCache[block_id, token_offset, kv_hid, vid].astype(accum_dtype)

                if sum_exp == 0.0:
                    Out[bid, qid, hid, vid] = 0.0
                    if vid == 0:
                        Lse[bid, hid, qid] = T.infinity(accum_dtype)
                else:
                    Out[bid, qid, hid, vid] = (acc / sum_exp).astype(dtype)
                    if vid == 0:
                        Lse[bid, hid, qid] = T.log(sum_exp) + max_score

        return main

    return dense_decode_kernel()


def _dtype_name(dtype: torch.dtype) -> str:
    if dtype == torch.float16:
        return "float16"
    if dtype == torch.bfloat16:
        return "bfloat16"
    raise AssertionError("TileLang backend supports float16 and bfloat16 query tensors")


def _validate_dense_inputs(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    block_table: Optional[torch.Tensor],
    cache_seqlens: Optional[torch.Tensor],
    head_dim_v: int,
    attn_sink: Optional[torch.Tensor],
    extra_k_cache: Optional[torch.Tensor],
    extra_indices_in_kvcache: Optional[torch.Tensor],
    topk_length: Optional[torch.Tensor],
    extra_topk_length: Optional[torch.Tensor],
) -> None:
    if block_table is None or cache_seqlens is None:
        raise AssertionError("block_table and cache_seqlens must be provided when dense attention is used")
    if any(
        t is not None
        for t in (
            attn_sink,
            extra_k_cache,
            extra_indices_in_kvcache,
            topk_length,
            extra_topk_length,
        )
    ):
        raise AssertionError(
            "attn_sink, extra_k_cache, extra_indices_in_kvcache, topk_length and "
            "extra_topk_length must be None when dense attention is used"
        )
    _check_device(q, k_cache, block_table, cache_seqlens)
    if q.dtype not in (torch.bfloat16, torch.float16):
        raise AssertionError("dense q must have dtype torch.bfloat16 or torch.float16")
    if k_cache.dtype != q.dtype:
        raise AssertionError("query and key must have the same dtype")
    if cache_seqlens.dtype != torch.int32:
        raise AssertionError("cache_seqlens must have dtype torch.int32")
    if block_table.dtype != torch.int32:
        raise AssertionError("block_table must have dtype torch.int32")
    _check_last_dim_contiguous(q, "q")
    _check_last_dim_contiguous(k_cache, "k_cache")
    _check_last_dim_contiguous(block_table, "block_table")
    _check_contiguous(cache_seqlens, "cache_seqlens")
    b, _, h_q, d_qk = q.shape
    page_block_size = k_cache.shape[1]
    h_k = k_cache.shape[2]
    if d_qk not in (512, 576):
        raise AssertionError("Only head_size_k == 576 or 512 is supported")
    if head_dim_v != 512:
        raise AssertionError("Only head_size_v == 512 is supported")
    if page_block_size != 64:
        raise AssertionError("Currently page_block_size must be 64")
    if b <= 0:
        raise AssertionError("batch size must be positive")
    if h_q % h_k != 0:
        raise AssertionError("Number of heads in key/value must divide number of heads in query")


def _validate_sparse_inputs(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    indices: torch.Tensor,
    attn_sink: Optional[torch.Tensor],
    extra_k_cache: Optional[torch.Tensor],
    extra_indices: Optional[torch.Tensor],
    topk_length: Optional[torch.Tensor],
    extra_topk_length: Optional[torch.Tensor],
    head_dim_v: int,
) -> None:
    _check_device(
        q,
        k_cache,
        indices,
        attn_sink,
        extra_k_cache,
        extra_indices,
        topk_length,
        extra_topk_length,
    )
    if q.dim() != 4 or k_cache.dim() != 4 or indices.dim() != 3:
        raise AssertionError("q and k_cache must be 4D, indices must be 3D")
    b, s_q, h_q, d_qk = q.shape
    h_kv = k_cache.shape[2]
    topk = indices.shape[-1]
    if b <= 0 or s_q <= 0 or h_q <= 0:
        raise AssertionError("batch, s_q and h_q must be positive")
    if h_kv != 1:
        raise AssertionError("Currently only MQA (i.e. h_kv == 1) is supported for sparse decoding")
    if d_qk not in (512, 576):
        raise AssertionError("Only head_size_k == 576 or 512 is supported for sparse decoding")
    if head_dim_v != 512:
        raise AssertionError("Only head_size_v == 512 is supported for sparse decoding")
    if h_q not in (64, 128):
        raise AssertionError("Unsupported h_q for sparse decoding")
    if topk <= 0:
        raise AssertionError("topk must be positive")
    if extra_k_cache is not None and extra_indices is None:
        raise AssertionError("extra_indices_in_kvcache must be provided when extra_kcache is provided")
    if extra_k_cache is None and (extra_indices is not None or extra_topk_length is not None):
        raise AssertionError(
            "extra_indices_in_kvcache and extra_topk_length must not be provided when "
            "extra_k_cache is not provided"
        )
    if q.dtype != torch.bfloat16:
        raise AssertionError("sparse q must have dtype torch.bfloat16")
    if k_cache.dtype not in (torch.float8_e4m3fn, torch.int8, torch.uint8):
        raise AssertionError("k_cache must have dtype fp8_e4m3fn, int8 or uint8")
    if extra_k_cache is not None and extra_k_cache.dtype not in (
        torch.float8_e4m3fn,
        torch.int8,
        torch.uint8,
    ):
        raise AssertionError("extra k cache must have dtype fp8_e4m3fn, int8 or uint8")
    if indices.dtype != torch.int32:
        raise AssertionError("indices must have dtype torch.int32")
    if topk_length is not None and topk_length.dtype != torch.int32:
        raise AssertionError("topk_length must have dtype torch.int32")
    if attn_sink is not None and attn_sink.dtype != torch.float32:
        raise AssertionError("attn_sink must have dtype torch.float32")
    if extra_indices is not None and extra_indices.dtype != torch.int32:
        raise AssertionError("extra_indices_in_kvcache must have dtype torch.int32")
    if extra_topk_length is not None and extra_topk_length.dtype != torch.int32:
        raise AssertionError("extra_topk_length must have dtype torch.int32")
    _check_last_dim_contiguous(q, "q")
    _check_last_dim_contiguous(k_cache, "k_cache")
    _check_last_dim_contiguous(indices, "indices")
    _check_contiguous(topk_length, "topk_length")
    _check_contiguous(attn_sink, "attn_sink")
    _check_last_dim_contiguous(extra_k_cache, "extra_k_cache")
    _check_last_dim_contiguous(extra_indices, "extra_indices_in_kvcache")
    _check_contiguous(extra_topk_length, "extra_topk_length")
    _, _, _, _, bytes_per_token = _sparse_layout_meta(d_qk, head_dim_v)
    if k_cache.shape[-1] != bytes_per_token:
        raise AssertionError("k_cache has an invalid sparse FP8 bytes-per-token dimension")
    if k_cache.stride(1) != bytes_per_token:
        raise AssertionError("The whole block must be contiguous when is_fp8_cache is True")
    if topk_length is not None and tuple(topk_length.shape) != (b,):
        raise AssertionError("topk_length must have shape [batch_size]")
    if attn_sink is not None and tuple(attn_sink.shape) != (h_q,):
        raise AssertionError("attn_sink must have shape [h_q]")
    if extra_k_cache is not None:
        assert extra_indices is not None
        if extra_k_cache.shape[2] != 1 or extra_k_cache.shape[-1] != bytes_per_token:
            raise AssertionError("extra_k_cache has an invalid sparse FP8 shape")
        if extra_k_cache.stride(1) != bytes_per_token:
            raise AssertionError(
                "The whole block must be contiguous when is_fp8_cache is True for extra kv cache"
            )
        if tuple(extra_indices.shape[:2]) != (b, s_q):
            raise AssertionError("extra_indices_in_kvcache must have shape [b, s_q, extra_topk]")
        if extra_topk_length is not None and tuple(extra_topk_length.shape) != (b,):
            raise AssertionError("extra_topk_length must have shape [batch_size]")


def _run_dense_decode_tilelang(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    block_table: torch.Tensor,
    cache_seqlens: torch.Tensor,
    head_dim_v: int,
    softmax_scale: float,
    causal: bool,
) -> Tuple[torch.Tensor, torch.Tensor]:
    q = q.contiguous()
    k_cache = k_cache.contiguous()
    block_table = block_table.contiguous()
    cache_seqlens = cache_seqlens.contiguous()
    b, s_q, h_q, d_qk = q.shape
    page_block_size = k_cache.shape[1]
    h_k = k_cache.shape[2]
    out = torch.empty((b, s_q, h_q, head_dim_v), device=q.device, dtype=q.dtype)
    lse = torch.empty((b, h_q, s_q), device=q.device, dtype=torch.float32)
    kernel = _get_dense_decode_kernel(
        b,
        s_q,
        h_q,
        h_k,
        d_qk,
        head_dim_v,
        page_block_size,
        float(softmax_scale),
        bool(causal),
        _dtype_name(q.dtype),
    )
    kernel(q, k_cache, block_table, cache_seqlens, out, lse)
    return out, lse


@lru_cache(maxsize=128)
def _get_sparse_direct_decode_kernel(
    b: int,
    s_q: int,
    h_q: int,
    d_qk: int,
    d_v: int,
    topk: int,
    extra_topk: int,
    page_block_size: int,
    extra_page_block_size: int,
    kv_storage_bytes: int,
    extra_kv_storage_bytes: int,
    kv_stride_block: int,
    kv_stride_row: int,
    extra_kv_stride_block: int,
    extra_kv_stride_row: int,
    d_nope: int,
    d_rope: int,
    tile_size: int,
    num_tiles: int,
    is_model1: bool,
    have_topk_length: bool,
    have_extra_kcache: bool,
    have_extra_topk_length: bool,
    have_attn_sink: bool,
    softmax_scale: float,
):
    import tilelang
    import tilelang.language as T

    dtype = T.bfloat16
    accum_dtype = T.float32
    scale = float(softmax_scale)

    @tilelang.jit(out_idx=[8, 9])
    def sparse_direct_decode_kernel():
        @T.prim_func
        def main(
            Q: T.Tensor([b, s_q, h_q, d_qk], dtype),
            KVBytes: T.Tensor([kv_storage_bytes], T.uint8),
            Indices: T.Tensor([b, s_q, topk], T.int32),
            TopkLength: T.Tensor([b], T.int32),
            AttnSink: T.Tensor([h_q], accum_dtype),
            ExtraKVBytes: T.Tensor([extra_kv_storage_bytes], T.uint8),
            ExtraIndices: T.Tensor([b, s_q, extra_topk], T.int32),
            ExtraTopkLength: T.Tensor([b], T.int32),
            Out: T.Tensor([b, s_q, h_q, d_v], dtype),
            Lse: T.Tensor([b, h_q, s_q], accum_dtype),
        ):
            KVFp8 = T.view(KVBytes, [kv_storage_bytes], dtype="float8_e4m3fn")
            KVF32 = T.view(KVBytes, [kv_storage_bytes // 4], dtype="float32")
            KVBf16 = T.view(KVBytes, [kv_storage_bytes // 2], dtype="bfloat16")
            KVScaleE8 = T.view(KVBytes, [kv_storage_bytes], dtype="float8_e8m0fnu")
            ExtraKVFp8 = T.view(ExtraKVBytes, [extra_kv_storage_bytes], dtype="float8_e4m3fn")
            ExtraKVF32 = T.view(ExtraKVBytes, [extra_kv_storage_bytes // 4], dtype="float32")
            ExtraKVBf16 = T.view(ExtraKVBytes, [extra_kv_storage_bytes // 2], dtype="bfloat16")
            ExtraKVScaleE8 = T.view(ExtraKVBytes, [extra_kv_storage_bytes], dtype="float8_e8m0fnu")

            with T.Kernel(b, s_q, h_q, d_v, threads=1) as (bid, qid, hid, vid):
                max_score = T.alloc_var(accum_dtype)
                score = T.alloc_var(accum_dtype)
                sum_exp = T.alloc_var(accum_dtype)
                acc = T.alloc_var(accum_dtype)
                lse_val = T.alloc_var(accum_dtype)
                idx = T.alloc_var(T.int32)
                block_id = T.alloc_var(T.int32)
                token_offset = T.alloc_var(T.int32)
                byte_base = T.alloc_var(T.int32)
                byte_offset = T.alloc_var(T.int32)
                scale_byte_offset = T.alloc_var(T.int32)
                tile_idx = T.alloc_var(T.int32)
                cur_topk = T.alloc_var(T.int32)
                cur_extra_topk = T.alloc_var(T.int32)
                k_val = T.alloc_var(accum_dtype)

                max_score = -T.infinity(accum_dtype)

                cur_topk = topk
                if have_topk_length:
                    cur_topk = TopkLength[bid]

                for tk in T.serial(cur_topk):
                    idx = Indices[bid, qid, tk]
                    if idx >= 0:
                        block_id = idx // page_block_size
                        token_offset = idx - block_id * page_block_size
                        byte_base = block_id * kv_stride_block + token_offset * kv_stride_row
                        score = 0.0
                        for d in T.serial(d_qk):
                            if d < d_nope:
                                tile_idx = d // tile_size
                                if is_model1:
                                    scale_byte_offset = (
                                        block_id * kv_stride_block
                                        + page_block_size * (d_nope + 2 * d_rope)
                                        + token_offset * 8
                                        + tile_idx
                                    )
                                    k_val = (
                                        KVFp8[byte_base + d].astype(accum_dtype)
                                        * KVScaleE8[scale_byte_offset].astype(accum_dtype)
                                    )
                                else:
                                    scale_byte_offset = byte_base + d_nope + tile_idx * 4
                                    k_val = (
                                        KVFp8[byte_base + d].astype(accum_dtype)
                                        * KVF32[scale_byte_offset // 4]
                                    )
                            else:
                                if is_model1:
                                    byte_offset = byte_base + d_nope + (d - d_nope) * 2
                                else:
                                    byte_offset = byte_base + d_nope + num_tiles * 4 + (d - d_nope) * 2
                                k_val = KVBf16[byte_offset // 2].astype(accum_dtype)
                            score += Q[bid, qid, hid, d].astype(accum_dtype) * k_val
                        score *= scale
                        max_score = T.max(max_score, score)

                cur_extra_topk = extra_topk
                if have_extra_topk_length:
                    cur_extra_topk = ExtraTopkLength[bid]
                if have_extra_kcache:
                    for tk in T.serial(cur_extra_topk):
                        idx = ExtraIndices[bid, qid, tk]
                        if idx >= 0:
                            block_id = idx // extra_page_block_size
                            token_offset = idx - block_id * extra_page_block_size
                            byte_base = (
                                block_id * extra_kv_stride_block
                                + token_offset * extra_kv_stride_row
                            )
                            score = 0.0
                            for d in T.serial(d_qk):
                                if d < d_nope:
                                    tile_idx = d // tile_size
                                    if is_model1:
                                        scale_byte_offset = (
                                            block_id * extra_kv_stride_block
                                            + extra_page_block_size * (d_nope + 2 * d_rope)
                                            + token_offset * 8
                                            + tile_idx
                                        )
                                        k_val = (
                                            ExtraKVFp8[byte_base + d].astype(accum_dtype)
                                            * ExtraKVScaleE8[scale_byte_offset].astype(accum_dtype)
                                        )
                                    else:
                                        scale_byte_offset = byte_base + d_nope + tile_idx * 4
                                        k_val = (
                                            ExtraKVFp8[byte_base + d].astype(accum_dtype)
                                            * ExtraKVF32[scale_byte_offset // 4]
                                        )
                                else:
                                    if is_model1:
                                        byte_offset = byte_base + d_nope + (d - d_nope) * 2
                                    else:
                                        byte_offset = (
                                            byte_base + d_nope + num_tiles * 4 + (d - d_nope) * 2
                                        )
                                    k_val = ExtraKVBf16[byte_offset // 2].astype(accum_dtype)
                                score += Q[bid, qid, hid, d].astype(accum_dtype) * k_val
                            score *= scale
                            max_score = T.max(max_score, score)

                sum_exp = 0.0
                acc = 0.0

                for tk in T.serial(cur_topk):
                    idx = Indices[bid, qid, tk]
                    if idx >= 0:
                        block_id = idx // page_block_size
                        token_offset = idx - block_id * page_block_size
                        byte_base = block_id * kv_stride_block + token_offset * kv_stride_row
                        score = 0.0
                        for d in T.serial(d_qk):
                            if d < d_nope:
                                tile_idx = d // tile_size
                                if is_model1:
                                    scale_byte_offset = (
                                        block_id * kv_stride_block
                                        + page_block_size * (d_nope + 2 * d_rope)
                                        + token_offset * 8
                                        + tile_idx
                                    )
                                    k_val = (
                                        KVFp8[byte_base + d].astype(accum_dtype)
                                        * KVScaleE8[scale_byte_offset].astype(accum_dtype)
                                    )
                                else:
                                    scale_byte_offset = byte_base + d_nope + tile_idx * 4
                                    k_val = (
                                        KVFp8[byte_base + d].astype(accum_dtype)
                                        * KVF32[scale_byte_offset // 4]
                                    )
                            else:
                                if is_model1:
                                    byte_offset = byte_base + d_nope + (d - d_nope) * 2
                                else:
                                    byte_offset = byte_base + d_nope + num_tiles * 4 + (d - d_nope) * 2
                                k_val = KVBf16[byte_offset // 2].astype(accum_dtype)
                            score += Q[bid, qid, hid, d].astype(accum_dtype) * k_val
                        score = T.exp(score * scale - max_score)
                        sum_exp += score
                        if vid < d_nope:
                            tile_idx = vid // tile_size
                            if is_model1:
                                scale_byte_offset = (
                                    block_id * kv_stride_block
                                    + page_block_size * (d_nope + 2 * d_rope)
                                    + token_offset * 8
                                    + tile_idx
                                )
                                k_val = (
                                    KVFp8[byte_base + vid].astype(accum_dtype)
                                    * KVScaleE8[scale_byte_offset].astype(accum_dtype)
                                )
                            else:
                                scale_byte_offset = byte_base + d_nope + tile_idx * 4
                                k_val = (
                                    KVFp8[byte_base + vid].astype(accum_dtype)
                                    * KVF32[scale_byte_offset // 4]
                                )
                        else:
                            if is_model1:
                                byte_offset = byte_base + d_nope + (vid - d_nope) * 2
                            else:
                                byte_offset = (
                                    byte_base + d_nope + num_tiles * 4 + (vid - d_nope) * 2
                                )
                            k_val = KVBf16[byte_offset // 2].astype(accum_dtype)
                        acc += score * k_val

                if have_extra_kcache:
                    for tk in T.serial(cur_extra_topk):
                        idx = ExtraIndices[bid, qid, tk]
                        if idx >= 0:
                            block_id = idx // extra_page_block_size
                            token_offset = idx - block_id * extra_page_block_size
                            byte_base = (
                                block_id * extra_kv_stride_block
                                + token_offset * extra_kv_stride_row
                            )
                            score = 0.0
                            for d in T.serial(d_qk):
                                if d < d_nope:
                                    tile_idx = d // tile_size
                                    if is_model1:
                                        scale_byte_offset = (
                                            block_id * extra_kv_stride_block
                                            + extra_page_block_size * (d_nope + 2 * d_rope)
                                            + token_offset * 8
                                            + tile_idx
                                        )
                                        k_val = (
                                            ExtraKVFp8[byte_base + d].astype(accum_dtype)
                                            * ExtraKVScaleE8[scale_byte_offset].astype(accum_dtype)
                                        )
                                    else:
                                        scale_byte_offset = byte_base + d_nope + tile_idx * 4
                                        k_val = (
                                            ExtraKVFp8[byte_base + d].astype(accum_dtype)
                                            * ExtraKVF32[scale_byte_offset // 4]
                                        )
                                else:
                                    if is_model1:
                                        byte_offset = byte_base + d_nope + (d - d_nope) * 2
                                    else:
                                        byte_offset = (
                                            byte_base + d_nope + num_tiles * 4 + (d - d_nope) * 2
                                        )
                                    k_val = ExtraKVBf16[byte_offset // 2].astype(accum_dtype)
                                score += Q[bid, qid, hid, d].astype(accum_dtype) * k_val
                            score = T.exp(score * scale - max_score)
                            sum_exp += score
                            if vid < d_nope:
                                tile_idx = vid // tile_size
                                if is_model1:
                                    scale_byte_offset = (
                                        block_id * extra_kv_stride_block
                                        + extra_page_block_size * (d_nope + 2 * d_rope)
                                        + token_offset * 8
                                        + tile_idx
                                    )
                                    k_val = (
                                        ExtraKVFp8[byte_base + vid].astype(accum_dtype)
                                        * ExtraKVScaleE8[scale_byte_offset].astype(accum_dtype)
                                    )
                                else:
                                    scale_byte_offset = byte_base + d_nope + tile_idx * 4
                                    k_val = (
                                        ExtraKVFp8[byte_base + vid].astype(accum_dtype)
                                        * ExtraKVF32[scale_byte_offset // 4]
                                    )
                            else:
                                if is_model1:
                                    byte_offset = byte_base + d_nope + (vid - d_nope) * 2
                                else:
                                    byte_offset = (
                                        byte_base + d_nope + num_tiles * 4 + (vid - d_nope) * 2
                                    )
                                k_val = ExtraKVBf16[byte_offset // 2].astype(accum_dtype)
                            acc += score * k_val

                if sum_exp == 0.0:
                    Out[bid, qid, hid, vid] = 0.0
                    if vid == 0:
                        Lse[bid, hid, qid] = T.infinity(accum_dtype)
                else:
                    lse_val = T.log(sum_exp) + max_score
                    if have_attn_sink:
                        acc = acc / (sum_exp + T.exp(AttnSink[hid] - max_score))
                    else:
                        acc = acc / sum_exp
                    Out[bid, qid, hid, vid] = acc.astype(dtype)
                    if vid == 0:
                        Lse[bid, hid, qid] = lse_val

        return main

    return sparse_direct_decode_kernel()


def _storage_byte_view(tensor: torch.Tensor) -> Tuple[torch.Tensor, int, int, int]:
    raw = tensor.view(torch.uint8)
    storage_len = (
        (tensor.shape[0] - 1) * tensor.stride(0)
        + (tensor.shape[1] - 1) * tensor.stride(1)
        + tensor.shape[-1]
    )
    flat = torch.as_strided(raw, (storage_len,), (1,), storage_offset=raw.storage_offset())
    return flat, int(tensor.stride(0)), int(tensor.stride(1)), int(storage_len)


def _sparse_layout_meta(d_qk: int, d_v: int) -> Tuple[int, int, int, int, int]:
    if d_qk == 576 and d_v == 512:
        return 512, 64, 128, 4, 656
    if d_qk == 512 and d_v == 512:
        return 448, 64, 64, 7, 584
    raise AssertionError("unsupported sparse FP8 head dimensions")


def _run_sparse_decode_tilelang_direct(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    indices: torch.Tensor,
    attn_sink: Optional[torch.Tensor],
    extra_k_cache: Optional[torch.Tensor],
    extra_indices: Optional[torch.Tensor],
    topk_length: Optional[torch.Tensor],
    extra_topk_length: Optional[torch.Tensor],
    head_dim_v: int,
    softmax_scale: float,
) -> Tuple[torch.Tensor, torch.Tensor]:
    b, s_q, h_q, d_qk = q.shape
    d_nope, d_rope, tile_size, num_tiles, bytes_per_token = _sparse_layout_meta(d_qk, head_dim_v)
    q = q.contiguous()
    indices = indices.contiguous()
    have_topk_length = topk_length is not None
    if topk_length is None:
        topk_length = torch.empty((b,), device=q.device, dtype=torch.int32)
    else:
        topk_length = topk_length.contiguous()
    have_attn_sink = attn_sink is not None
    if attn_sink is None:
        attn_sink = torch.empty((h_q,), device=q.device, dtype=torch.float32)
    else:
        attn_sink = attn_sink.contiguous()

    k_cache_bytes, kv_stride_block, kv_stride_row, kv_storage_bytes = _storage_byte_view(k_cache)

    have_extra_kcache = extra_k_cache is not None
    extra_topk = extra_indices.shape[-1] if extra_indices is not None else 1
    if have_extra_kcache:
        assert extra_k_cache is not None and extra_indices is not None
        extra_k_cache_bytes, extra_kv_stride_block, extra_kv_stride_row, extra_kv_storage_bytes = (
            _storage_byte_view(extra_k_cache)
        )
        extra_indices = extra_indices.contiguous()
    else:
        extra_k_cache_bytes = torch.empty((4,), device=q.device, dtype=torch.uint8)
        extra_kv_stride_block = bytes_per_token
        extra_kv_stride_row = bytes_per_token
        extra_kv_storage_bytes = 4
        extra_indices = torch.empty((b, s_q, extra_topk), device=q.device, dtype=torch.int32)

    have_extra_topk_length = extra_topk_length is not None
    if extra_topk_length is None:
        extra_topk_length = torch.empty((b,), device=q.device, dtype=torch.int32)
    else:
        extra_topk_length = extra_topk_length.contiguous()

    out = torch.empty((b, s_q, h_q, head_dim_v), device=q.device, dtype=q.dtype)
    lse = torch.empty((b, h_q, s_q), device=q.device, dtype=torch.float32)
    kernel = _get_sparse_direct_decode_kernel(
        b,
        s_q,
        h_q,
        d_qk,
        head_dim_v,
        indices.shape[-1],
        extra_topk,
        k_cache.shape[1],
        extra_k_cache.shape[1] if extra_k_cache is not None else 1,
        kv_storage_bytes,
        extra_kv_storage_bytes,
        kv_stride_block,
        kv_stride_row,
        extra_kv_stride_block,
        extra_kv_stride_row,
        d_nope,
        d_rope,
        tile_size,
        num_tiles,
        d_qk == 512,
        have_topk_length,
        have_extra_kcache,
        have_extra_topk_length,
        have_attn_sink,
        float(softmax_scale),
    )
    kernel(
        q,
        k_cache_bytes,
        indices,
        topk_length,
        attn_sink,
        extra_k_cache_bytes,
        extra_indices,
        extra_topk_length,
        out,
        lse,
    )
    return out, lse


def _require_tilelang() -> None:
    if not _tilelang_is_available():
        if _reference_fallback_enabled():
            return
        raise RuntimeError(
            "TileLang backend was selected for sm89, but the tilelang package is not installed. "
            "Install tilelang or set FLASH_MLA_TILELANG_REFERENCE_FALLBACK=1 for the slow "
            "torch reference fallback."
        )


def _dequantize_fp8_kvcache(k_cache: torch.Tensor, d_qk: int) -> torch.Tensor:
    num_blocks, block_size, h_k, _ = k_cache.shape
    if h_k != 1:
        raise AssertionError("Sparse FP8 decode currently requires num_heads_k == 1")

    if d_qk == 576:
        d_nope, d_rope, tile_size, num_tiles = 512, 64, 128, 4
        flat = k_cache.view(num_blocks, block_size, -1)
        nope = flat[..., :d_nope]
        scales = flat[..., d_nope : d_nope + num_tiles * 4].view(torch.float32)
        rope = flat[..., d_nope + num_tiles * 4 :].view(torch.bfloat16)
    elif d_qk == 512:
        d_nope, d_rope, tile_size, num_tiles = 448, 64, 64, 7
        flat = k_cache.view(num_blocks, -1)
        nope_rope = flat[:, : block_size * (d_nope + 2 * d_rope)].view(
            num_blocks, block_size, d_nope + 2 * d_rope
        )
        nope = nope_rope[..., :d_nope]
        rope = nope_rope[..., d_nope:].view(torch.bfloat16)
        scales = flat[:, block_size * (d_nope + 2 * d_rope) :].view(
            num_blocks, block_size, 8
        )[:, :, :num_tiles].view(torch.float8_e8m0fnu)
    else:
        raise AssertionError("Only head_dim 512 or 576 is supported")

    out = torch.empty((num_blocks, block_size, d_qk), device=k_cache.device, dtype=torch.bfloat16)
    out[..., d_nope:] = rope
    for tile_idx in range(num_tiles):
        beg = tile_idx * tile_size
        end = (tile_idx + 1) * tile_size
        cur_nope = nope[..., beg:end].to(torch.float32)
        cur_scales = scales[..., tile_idx].to(torch.float32).unsqueeze(-1)
        out[..., beg:end] = cur_nope * cur_scales
    return out.view(num_blocks, block_size, 1, d_qk)


def _dense_decode_reference(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    block_table: torch.Tensor,
    cache_seqlens: torch.Tensor,
    head_dim_v: int,
    softmax_scale: float,
    causal: bool,
) -> Tuple[torch.Tensor, torch.Tensor]:
    b, s_q, h_q, d_qk = q.shape
    block_size = k_cache.shape[1]
    h_k = k_cache.shape[2]
    if h_q % h_k != 0:
        raise AssertionError("num_heads_q must be divisible by num_heads_k")

    out = torch.empty((b, s_q, h_q, head_dim_v), device=q.device, dtype=q.dtype)
    lse = torch.empty((b, h_q, s_q), device=q.device, dtype=torch.float32)
    q_f = q.float()

    for batch_idx in range(b):
        cur_len = int(cache_seqlens[batch_idx].item())
        if cur_len <= 0:
            out[batch_idx].zero_()
            lse[batch_idx].fill_(float("inf"))
            continue

        num_blocks = (cur_len + block_size - 1) // block_size
        block_ids = block_table[batch_idx, :num_blocks].long()
        kv = k_cache.index_select(0, block_ids).view(-1, h_k, d_qk)[:cur_len]
        kv = kv.transpose(0, 1).float()
        kv[kv != kv] = 0.0
        if h_k != h_q:
            kv = kv.repeat_interleave(h_q // h_k, dim=0)

        scores = torch.matmul(q_f[batch_idx].transpose(0, 1), kv.transpose(-2, -1))
        scores *= softmax_scale
        if causal and s_q > 1:
            mask = torch.ones((s_q, cur_len), device=q.device, dtype=torch.bool).tril(
                diagonal=cur_len - s_q
            )
            scores = scores.masked_fill(~mask.view(1, s_q, cur_len), float("-inf"))

        cur_lse = scores.logsumexp(dim=-1)
        probs = torch.softmax(scores, dim=-1, dtype=torch.float32)
        cur_out = torch.matmul(probs, kv[..., :head_dim_v])

        lonely = cur_lse == float("-inf")
        if lonely.any():
            cur_out = cur_out.masked_fill(lonely.unsqueeze(-1), 0.0)
            cur_lse = cur_lse.masked_fill(lonely, float("inf"))

        out[batch_idx] = cur_out.transpose(0, 1).to(q.dtype)
        lse[batch_idx] = cur_lse
    return out, lse


def _gather_sparse_scope(
    k_cache: torch.Tensor,
    indices: torch.Tensor,
    topk_length: Optional[torch.Tensor],
    q_shape: Tuple[int, int, int, int],
    head_dim_v: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    b, s_q, _, d_qk = q_shape
    topk = indices.shape[-1]
    kv = _dequantize_fp8_kvcache(k_cache, d_qk).view(-1, d_qk)
    fixed_indices = torch.clamp_min(indices, 0).long()
    gathered = kv.index_select(0, fixed_indices.reshape(-1)).view(b, s_q, topk, d_qk)

    invalid = indices < 0
    if topk_length is not None:
        arange = torch.arange(topk, device=indices.device).view(1, 1, topk)
        invalid = invalid | (arange >= topk_length.view(b, 1, 1))

    gathered = gathered.float()
    gathered[gathered != gathered] = 0.0
    return gathered[..., : max(head_dim_v, d_qk)], invalid


def _sparse_decode_reference(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    indices: torch.Tensor,
    attn_sink: Optional[torch.Tensor],
    extra_k_cache: Optional[torch.Tensor],
    extra_indices: Optional[torch.Tensor],
    topk_length: Optional[torch.Tensor],
    extra_topk_length: Optional[torch.Tensor],
    head_dim_v: int,
    softmax_scale: float,
) -> Tuple[torch.Tensor, torch.Tensor]:
    b, s_q, h_q, d_qk = q.shape
    if k_cache.shape[2] != 1:
        raise AssertionError("Sparse FP8 decode currently requires num_heads_k == 1")

    gathered, invalid = _gather_sparse_scope(k_cache, indices, topk_length, q.shape, head_dim_v)
    if extra_k_cache is not None:
        if extra_indices is None:
            raise AssertionError("extra_indices_in_kvcache is required when extra_k_cache is provided")
        gathered_extra, invalid_extra = _gather_sparse_scope(
            extra_k_cache, extra_indices, extra_topk_length, q.shape, head_dim_v
        )
        gathered = torch.cat((gathered, gathered_extra), dim=2)
        invalid = torch.cat((invalid, invalid_extra), dim=2)

    gathered = gathered[..., :d_qk]
    q_f = q.float().view(b * s_q, h_q, d_qk)
    kv_f = gathered.view(b * s_q, -1, d_qk)
    scores = torch.matmul(q_f, kv_f.transpose(-1, -2)) * softmax_scale
    scores = scores.masked_fill(invalid.view(b * s_q, 1, -1), float("-inf"))

    cur_lse = scores.logsumexp(dim=-1)
    weights = torch.exp(scores - cur_lse.unsqueeze(-1))
    out = torch.matmul(weights, kv_f[..., :head_dim_v]).view(b, s_q, h_q, head_dim_v)
    cur_lse = cur_lse.view(b, s_q, h_q)

    if attn_sink is not None:
        scale = 1.0 / (1.0 + torch.exp(attn_sink.view(1, 1, h_q) - cur_lse))
        out = out * scale.unsqueeze(-1)

    lonely = cur_lse == float("-inf")
    if lonely.any():
        out = out.masked_fill(lonely.unsqueeze(-1), 0.0)
        cur_lse = cur_lse.masked_fill(lonely, float("inf"))

    return out.to(q.dtype), cur_lse.transpose(1, 2).contiguous()


def flash_mla_with_kvcache(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    block_table: Optional[torch.Tensor],
    cache_seqlens: Optional[torch.Tensor],
    head_dim_v: int,
    softmax_scale: float,
    causal: bool,
    is_fp8_kvcache: bool,
    indices: Optional[torch.Tensor],
    attn_sink: Optional[torch.Tensor],
    extra_k_cache: Optional[torch.Tensor],
    extra_indices_in_kvcache: Optional[torch.Tensor],
    topk_length: Optional[torch.Tensor],
    extra_topk_length: Optional[torch.Tensor],
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    _require_tilelang()
    use_reference_fallback = not _tilelang_is_available()

    if indices is None:
        _validate_dense_inputs(
            q,
            k_cache,
            block_table,
            cache_seqlens,
            head_dim_v,
            attn_sink,
            extra_k_cache,
            extra_indices_in_kvcache,
            topk_length,
            extra_topk_length,
        )
        assert block_table is not None and cache_seqlens is not None
        if use_reference_fallback:
            out, lse = _dense_decode_reference(
                q, k_cache, block_table, cache_seqlens, head_dim_v, softmax_scale, causal
            )
        else:
            out, lse = _run_dense_decode_tilelang(
                q, k_cache, block_table, cache_seqlens, head_dim_v, softmax_scale, causal
            )
        q_seq_per_hk = q.shape[1] * q.shape[2] // k_cache.shape[2]
        num_sm_parts = max(_num_sms(q.device) // k_cache.shape[2] // _ceildiv(q_seq_per_hk, 64), 1)
        meta, splits = _build_decode_scheduler_metadata(
            q,
            64,
            5,
            -1,
            -1,
            None,
            None,
            cache_seqlens,
            num_sm_parts,
        )
    else:
        if not is_fp8_kvcache:
            raise AssertionError("Sparse attention requires is_fp8_kvcache=True")
        _validate_sparse_inputs(
            q,
            k_cache,
            indices,
            attn_sink,
            extra_k_cache,
            extra_indices_in_kvcache,
            topk_length,
            extra_topk_length,
            head_dim_v,
        )
        if not use_reference_fallback:
            out, lse = _run_sparse_decode_tilelang_direct(
                q,
                k_cache,
                indices,
                attn_sink,
                extra_k_cache,
                extra_indices_in_kvcache,
                topk_length,
                extra_topk_length,
                head_dim_v,
                softmax_scale,
            )
        elif _reference_fallback_enabled():
            out, lse = _sparse_decode_reference(
                q,
                k_cache,
                indices,
                attn_sink,
                extra_k_cache,
                extra_indices_in_kvcache,
                topk_length,
                extra_topk_length,
                head_dim_v,
                softmax_scale,
            )
        num_sm_parts = max(_num_sms(q.device) // q.shape[1] // (q.shape[2] // 64), 1)
        meta, splits = _build_decode_scheduler_metadata(
            q,
            64,
            5,
            indices.shape[-1],
            extra_indices_in_kvcache.shape[-1] if extra_indices_in_kvcache is not None else 0,
            topk_length,
            extra_topk_length,
            None,
            num_sm_parts,
        )

    return out, lse, meta, splits
