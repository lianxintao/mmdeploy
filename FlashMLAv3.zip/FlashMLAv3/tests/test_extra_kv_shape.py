"""Shape verification for extra_kv merge."""
import sys, types, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
_mock_cuda = types.ModuleType("flash_mla.cuda")
sys.modules["flash_mla.cuda"] = _mock_cuda
import torch, importlib.util
_spec = importlib.util.spec_from_file_location(
    "ref_torch", os.path.join(os.path.dirname(__file__), "..", "flash_mla", "torch", "ref.py"),
)
ref_torch = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_torch)
from tests.quant import quantize_k_cache, FP8KVCacheLayout

device = torch.device("cuda:0")
all_ok = True

for B, s_q, h_q, d_v, topk in [
    (8, 1, 64, 512, 128),   # User reported case
    (4, 1, 64, 512, 64),
    (1, 1, 128, 512, 128),
    (2, 2, 32, 512, 64),    # Multi-token
]:
    d_qk = 512
    num_blocks = 8; e_blocks = 4
    N = num_blocks * 64; eN = e_blocks * 64
    torch.manual_seed(42)
    q = torch.randn(B, s_q, h_q, d_qk, dtype=torch.bfloat16, device=device)
    k_cache = quantize_k_cache(
        torch.randn(num_blocks, 64, 1, d_qk, dtype=torch.bfloat16, device=device).clamp_(-1, 1),
        FP8KVCacheLayout.MODEL1_FP8Sparse)
    ek = quantize_k_cache(
        torch.randn(e_blocks, 64, 1, d_qk, dtype=torch.bfloat16, device=device).clamp_(-1, 1),
        FP8KVCacheLayout.MODEL1_FP8Sparse)
    indices = torch.randint(0, N, (B, s_q, topk), dtype=torch.int32, device=device)
    ei = torch.randint(0, eN, (B, s_q, topk // 2), dtype=torch.int32, device=device)
    ss = d_qk ** (-0.5)

    out, lse = ref_torch.flash_mla_decode_torch(
        q=q, k_cache=k_cache, indices=indices, head_dim_v=d_v, softmax_scale=ss,
        extra_k_cache=ek, extra_indices=ei,
    )

    expected_out = (B, s_q, h_q, d_v)
    expected_lse = (B, h_q, s_q)
    ok_out = out.shape == expected_out
    ok_lse = lse.shape == expected_lse
    tag_out = "OK" if ok_out else "FAIL"
    tag_lse = "OK" if ok_lse else "FAIL"
    print(f"B={B:<2} s_q={s_q} h_q={h_q:<4} topk={topk:<4}: "
          f"out={tuple(out.shape)} expect={expected_out} [{tag_out}]  "
          f"lse={tuple(lse.shape)} expect={expected_lse} [{tag_lse}]")
    if not ok_out or not ok_lse:
        all_ok = False

if all_ok:
    print("\nAll shape checks PASSED")
else:
    print("\nShape check FAILED")
    sys.exit(1)
