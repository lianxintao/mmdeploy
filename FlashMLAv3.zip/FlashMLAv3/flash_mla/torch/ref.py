"""
Fused FlashMLA sparse decode — partial + combine architecture.

Two-kernel design (matching flash_atten/triton_kernel.py pattern):
  _partial_decode_kernel — load full K, dequant all, QK^T + online softmax + V accum
  _combine_decode_kernel — LSE merge + attn_sink + lonely_q

One head per block. Full K loaded at once (no per-tile loops), avoiding triton's
register indexing limitations. Element-wise QK and PV accumulation.
"""

from typing import Optional, Tuple

import torch
import triton
import triton.language as tl


# ---------------------------------------------------------------------------
# FP8 KV cache flatten
# ---------------------------------------------------------------------------

def _flatten_kvcache(k_cache: torch.Tensor, d_qk: int):
    assert k_cache.ndim == 4 and k_cache.shape[2] == 1
    num_blocks, block_size = k_cache.shape[:2]
    N = num_blocks * block_size

    if d_qk == 576:  # V32
        d_nope, d_rope, tile_size, num_tiles = 512, 64, 128, 4
        kv_flat = k_cache.squeeze(2).reshape(N, 656).contiguous()
        kv_fp8 = kv_flat
        kv_bf16 = kv_flat.view(torch.uint8).view(torch.bfloat16)
        k_scale = (kv_flat.view(torch.uint8)[:, 512:528].contiguous()
                   .view(torch.float32).view(N, 4))
        scale_is_e8m0 = False
        rope_bf16_off = 264
    elif d_qk == 512:  # MODEL1
        d_nope, d_rope, tile_size, num_tiles = 448, 64, 64, 7
        flat = k_cache.view(num_blocks, -1)
        nope_rope = (flat[:, :block_size * 576]
                     .view(num_blocks, block_size, 576).reshape(N, 576))
        kv_fp8 = nope_rope.view(torch.float8_e4m3fn)
        kv_bf16 = nope_rope.view(torch.bfloat16)
        k_scale = (flat[:, block_size * 576:]
                   .view(num_blocks, block_size, 8)[:, :, :7]
                   .reshape(N, 7).view(torch.uint8))
        scale_is_e8m0 = True
        rope_bf16_off = 224
    else:
        raise ValueError(f"Unsupported d_qk={d_qk}")

    return (kv_fp8, kv_bf16, k_scale, d_nope, d_rope,
            num_tiles, tile_size, rope_bf16_off, scale_is_e8m0)


# ---------------------------------------------------------------------------
# Grid helpers
# ---------------------------------------------------------------------------

def _pick_inner_iter(topk: int, BI: int) -> int:
    n = topk // BI
    it = 1
    while it * 2 <= n and n % (it * 2) == 0:
        it *= 2
    return min(it, 4)


# ---------------------------------------------------------------------------
# Partial attention kernel
# ---------------------------------------------------------------------------

@triton.jit
def _partial_decode_kernel(
    Q_ptr, kv_nope_ptr, kv_rope_ptr, k_scale_ptr,
    indices_ptr, topk_length_ptr,
    partial_o_ptr, partial_lse_ptr,
    #
    d_nope: tl.constexpr, d_rope: tl.constexpr,
    d_nope_rnd: tl.constexpr, d_rope_rnd: tl.constexpr,
    d_v: tl.constexpr,
    num_tiles: tl.constexpr, tile_size: tl.constexpr,
    rope_bf16_off: tl.constexpr,
    SCALE_IS_E8M0: tl.constexpr,
    topk: tl.constexpr, BI: tl.constexpr, inner_iter: tl.constexpr,
    HAS_TOPK_LENGTH: tl.constexpr,
    sm_scale: tl.float32, log2e: tl.float32,
    #
    stride_q_b: tl.int32, stride_q_s: tl.int32, stride_q_h: tl.int32,
    stride_nope_n: tl.int32, stride_rope_n: tl.int32, stride_scale_n: tl.int32,
    stride_idx_b: tl.int32, stride_idx_s: tl.int32,
    stride_po_b: tl.int32, stride_po_s: tl.int32, stride_po_g: tl.int32, stride_po_h: tl.int32,
    stride_pl_b: tl.int32, stride_pl_s: tl.int32, stride_pl_g: tl.int32, stride_pl_h: tl.int32,
    B: tl.int32, S_Q: tl.int32, H_Q: tl.int32, N_GROUPS: tl.int32,
):
    pid_x = tl.program_id(0)
    pid_y = tl.program_id(1)
    hid = pid_x % H_Q
    tmp = pid_x // H_Q
    s_i = tmp % S_Q
    b_i = tmp // S_Q
    group_i = pid_y

    q_base = b_i * stride_q_b + s_i * stride_q_s + hid * stride_q_h
    offs_n = tl.arange(0, d_nope_rnd)
    offs_r = tl.arange(0, d_rope_rnd)
    mask_n = offs_n < d_nope
    mask_r = offs_r < d_rope

    # Precompute per-dim group id: which scale tile each nope dim belongs to
    gids = (offs_n // tile_size).to(tl.int32)

    # State
    m_i: tl.float32 = -1e30
    l_i: tl.float32 = 0.0
    acc_n = tl.zeros([d_nope_rnd], dtype=tl.float32)
    acc_r = tl.zeros([d_rope_rnd], dtype=tl.float32)

    t_offs = tl.arange(0, BI)

    for k_i in range(inner_iter):
        base = (group_i * inner_iter + k_i) * BI
        t_idx = base + t_offs
        t_ok = t_idx < topk

        # Indices
        kv_idx = tl.load(indices_ptr + b_i * stride_idx_b + s_i * stride_idx_s + t_idx,
                         mask=t_ok, other=-1)
        ok = (kv_idx >= 0) & t_ok
        if HAS_TOPK_LENGTH:
            ok = ok & (t_idx < tl.load(topk_length_ptr + b_i))
        safe = tl.maximum(kv_idx, 0)

        # ---- Load full K nope [BI, d_nope_rnd] fp8 ----
        k_n = tl.load(kv_nope_ptr + safe[:, None] * stride_nope_n + offs_n[None, :],
                      mask=ok[:, None] & mask_n[None, :], other=0.0)

        # ---- Load full K scales [BI, num_tiles], broadcast → [BI, d_nope_rnd] ----
        k_s = tl.zeros([BI, d_nope_rnd], dtype=tl.float32)
        for t in tl.static_range(num_tiles):
            s_ptr = k_scale_ptr + safe * stride_scale_n + t
            if SCALE_IS_E8M0:
                s_val = tl.math.exp2(tl.load(s_ptr, mask=ok, other=127).to(tl.float32) - 127.0)
            else:
                s_val = tl.load(s_ptr, mask=ok, other=0.0)
            in_tile = (gids == t)[None, :]                               # [1, d_nope_rnd]
            k_s = tl.where(in_tile, s_val[:, None], k_s)                # broadcast

        # Dequant nope: [BI, d_nope_rnd] f32
        k_n_f32 = k_n.to(dtype=tl.float32) * k_s

        # ---- Load Q nope from global ----
        q_n = tl.load(Q_ptr + q_base + offs_n, mask=mask_n, other=0.0)
        q_n = q_n.to(tl.float32) * sm_scale

        # QK^T nope: [d_nope_rnd] @ [BI, d_nope_rnd]^T → [BI]
        scores = tl.sum(q_n[None, :] * k_n_f32, axis=1)

        # QK^T rope
        q_r = tl.load(Q_ptr + q_base + d_nope + offs_r, mask=mask_r, other=0.0)
        q_r = q_r.to(tl.float32) * sm_scale
        k_r = tl.load(kv_rope_ptr + safe[:, None] * stride_rope_n
                      + (rope_bf16_off + offs_r)[None, :],
                      mask=ok[:, None] & mask_r[None, :], other=0.0)
        scores += tl.sum(q_r[None, :] * k_r.to(tl.float32), axis=1)
        scores = tl.where(ok, scores, -1e30)

        # Softmax
        m_prev = m_i
        m_i = tl.maximum(m_prev, tl.max(scores))
        alpha = tl.math.exp2((m_prev - m_i) * log2e)
        p = tl.where(ok, tl.math.exp2((scores - m_i) * log2e), 0.0)
        l_i = l_i * alpha + tl.sum(p)

        # V accumulation (element-wise, no slicing)
        acc_n = acc_n * alpha + tl.sum(p[:, None] * k_n_f32, axis=0)
        acc_r = acc_r * alpha + tl.sum(p[:, None] * k_r.to(tl.float32), axis=0)

    # Normalize output by softmax sum, compute LSE
    inv_l = 1.0 / tl.maximum(l_i, 1e-30)
    acc_n = acc_n * inv_l
    acc_r = acc_r * inv_l
    lse_val = tl.where(l_i > 0.0, tl.math.log(l_i) + m_i, float("-inf"))

    # Store partial outputs
    po_b = (b_i * stride_po_b + s_i * stride_po_s + group_i * stride_po_g
            + hid * stride_po_h)
    pl_b = (b_i * stride_pl_b + s_i * stride_pl_s + group_i * stride_pl_g
            + hid * stride_pl_h)

    tl.store(partial_o_ptr + po_b + offs_n, acc_n.to(tl.bfloat16), mask=mask_n)
    if d_v > d_nope:
        tl.store(partial_o_ptr + po_b + d_nope + offs_r, acc_r.to(tl.bfloat16), mask=mask_r)
    tl.store(partial_lse_ptr + pl_b, lse_val)


# ---------------------------------------------------------------------------
# Combine kernel
# ---------------------------------------------------------------------------

@triton.jit
def _combine_decode_kernel(
    partial_o_ptr, partial_lse_ptr, attn_sink_ptr,
    output_ptr, lse_out_ptr,
    d_v: tl.constexpr, N_GROUPS: tl.constexpr, HAS_ATTN_SINK: tl.constexpr,
    stride_po_b: tl.int32, stride_po_s: tl.int32, stride_po_g: tl.int32, stride_po_h: tl.int32,
    stride_pl_b: tl.int32, stride_pl_s: tl.int32, stride_pl_g: tl.int32, stride_pl_h: tl.int32,
    stride_o_b: tl.int32, stride_o_s: tl.int32, stride_o_h: tl.int32,
    stride_ls_b: tl.int32, stride_ls_h: tl.int32,
    B: tl.int32, S_Q: tl.int32, H_Q: tl.int32,
):
    pid = tl.program_id(0)
    hid = pid % H_Q
    tmp = pid // H_Q
    s_i = tmp % S_Q
    b_i = tmp // S_Q

    offs_v = tl.arange(0, d_v)

    lse_max: tl.float32 = -1e30
    for g in range(N_GROUPS):
        lg = tl.load(partial_lse_ptr + b_i * stride_pl_b + s_i * stride_pl_s
                     + g * stride_pl_g + hid * stride_pl_h)
        lse_max = tl.maximum(lse_max, lg)

    lse_sum: tl.float32 = 0.0
    for g in range(N_GROUPS):
        lg = tl.load(partial_lse_ptr + b_i * stride_pl_b + s_i * stride_pl_s
                     + g * stride_pl_g + hid * stride_pl_h)
        lse_sum += tl.math.exp(lg - lse_max)

    acc = tl.zeros([d_v], dtype=tl.float32)
    for g in range(N_GROUPS):
        lg = tl.load(partial_lse_ptr + b_i * stride_pl_b + s_i * stride_pl_s
                     + g * stride_pl_g + hid * stride_pl_h)
        w = tl.math.exp(lg - lse_max) / tl.maximum(lse_sum, 1e-30)
        po = tl.load(partial_o_ptr + b_i * stride_po_b + s_i * stride_po_s
                     + g * stride_po_g + hid * stride_po_h + offs_v)
        acc += w * po.to(tl.float32)

    lse_final = tl.math.log(tl.maximum(lse_sum, 1e-30)) + lse_max

    if HAS_ATTN_SINK:
        sink = tl.load(attn_sink_ptr + hid)
        clse = tl.where(sink == float("-inf"), lse_final,
                        tl.where(sink == float("+inf"), sink,
                                 lse_final + tl.math.log(1.0 + tl.math.exp(sink - lse_final))))
        acc = acc * tl.math.exp(lse_final - clse)
        lse_final = clse

    if lse_sum == 0.0:
        acc = tl.zeros([d_v], dtype=tl.float32)
        lse_final = float("+inf")

    o_base = b_i * stride_o_b + s_i * stride_o_s + hid * stride_o_h
    tl.store(output_ptr + o_base + offs_v, acc.to(tl.bfloat16))
    tl.store(lse_out_ptr + b_i * stride_ls_b + hid * stride_ls_h + s_i, lse_final)


# ---------------------------------------------------------------------------
# Wrappers
# ---------------------------------------------------------------------------

def _run_partial_decode(q, k_nope, k_rope, k_scale, indices, topk_length,
                        d_nope, d_rope, num_tiles, tile_size,
                        rope_bf16_off, scale_is_e8m0, sm_scale, d_v):
    b, s_q, h_q, _ = q.shape
    topk = indices.shape[-1]
    BI = 32 if b * s_q < 4 else 64
    if topk < BI:
        BI = topk
    inner_iter = _pick_inner_iter(topk, BI)
    N_GROUPS = max(topk // (BI * inner_iter), 1)

    po = torch.empty(b, s_q, N_GROUPS, h_q, d_v, dtype=torch.bfloat16, device=q.device)
    pl = torch.empty(b, s_q, N_GROUPS, h_q, dtype=torch.float32, device=q.device)

    tl_tensor = (topk_length if topk_length is not None
                 else torch.empty(0, dtype=torch.int32, device=q.device))

    _partial_decode_kernel[(b * s_q * h_q, N_GROUPS)](
        q, k_nope, k_rope, k_scale, indices, tl_tensor, po, pl,
        d_nope=d_nope, d_rope=d_rope,
        d_nope_rnd=triton.next_power_of_2(d_nope),
        d_rope_rnd=triton.next_power_of_2(d_rope),
        d_v=d_v,
        num_tiles=num_tiles, tile_size=tile_size,
        rope_bf16_off=rope_bf16_off,
        SCALE_IS_E8M0=scale_is_e8m0,
        topk=topk, BI=BI, inner_iter=inner_iter,
        HAS_TOPK_LENGTH=topk_length is not None,
        sm_scale=sm_scale, log2e=1.4426950408889634,
        stride_q_b=q.stride(0), stride_q_s=q.stride(1), stride_q_h=q.stride(2),
        stride_nope_n=k_nope.stride(0), stride_rope_n=k_rope.stride(0),
        stride_scale_n=k_scale.stride(0),
        stride_idx_b=indices.stride(0), stride_idx_s=indices.stride(1),
        stride_po_b=po.stride(0), stride_po_s=po.stride(1),
        stride_po_g=po.stride(2), stride_po_h=po.stride(3),
        stride_pl_b=pl.stride(0), stride_pl_s=pl.stride(1),
        stride_pl_g=pl.stride(2), stride_pl_h=pl.stride(3),
        B=b, S_Q=s_q, H_Q=h_q, N_GROUPS=N_GROUPS,
    )
    return po, pl


def _run_combine_decode(po, pl, attn_sink, d_v):
    b, s_q, N_GROUPS, h_q, _ = po.shape
    out = torch.empty(b, s_q, h_q, d_v, dtype=torch.bfloat16, device=po.device)
    lse = torch.empty(b, h_q, s_q, dtype=torch.float32, device=po.device)
    sink = attn_sink if attn_sink is not None else torch.empty(0, dtype=torch.float32, device=po.device)

    _combine_decode_kernel[(b * s_q * h_q,)](
        po, pl, sink, out, lse,
        d_v=d_v, N_GROUPS=N_GROUPS, HAS_ATTN_SINK=attn_sink is not None,
        stride_po_b=po.stride(0), stride_po_s=po.stride(1),
        stride_po_g=po.stride(2), stride_po_h=po.stride(3),
        stride_pl_b=pl.stride(0), stride_pl_s=pl.stride(1),
        stride_pl_g=pl.stride(2), stride_pl_h=pl.stride(3),
        stride_o_b=out.stride(0), stride_o_s=out.stride(1), stride_o_h=out.stride(2),
        stride_ls_b=lse.stride(0), stride_ls_h=lse.stride(1),
        B=b, S_Q=s_q, H_Q=h_q,
    )
    return out, lse


def _merge_two_outputs(out1, lse1, out2, lse2):
    max_lse = torch.maximum(lse1, lse2)
    w1 = torch.where(lse1 > -1e20, torch.exp(lse1 - max_lse), torch.zeros_like(lse1))
    w2 = torch.where(lse2 > -1e20, torch.exp(lse2 - max_lse), torch.zeros_like(lse2))
    total = (w1 + w2).clamp(min=1e-20)
    merged = (w1.unsqueeze(-1) * out1.float() + w2.unsqueeze(-1) * out2.float()) / total.unsqueeze(-1)
    return merged.to(torch.bfloat16), max_lse + torch.log(total)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def flash_mla_decode_torch(
    q: torch.Tensor, k_cache: torch.Tensor, indices: torch.Tensor,
    head_dim_v: int, softmax_scale: float,
    attn_sink: Optional[torch.Tensor] = None,
    extra_k_cache: Optional[torch.Tensor] = None,
    extra_indices: Optional[torch.Tensor] = None,
    topk_length: Optional[torch.Tensor] = None,
    extra_topk_length: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    b, s_q, h_q, d_qk = q.shape
    d_v = head_dim_v

    (kv_fp8, kv_bf16, k_scale, dn, dr, nt, ts, ro, se8) = _flatten_kvcache(k_cache, d_qk)
    po, pl = _run_partial_decode(q, kv_fp8, kv_bf16, k_scale, indices, topk_length,
                                 dn, dr, nt, ts, ro, se8, softmax_scale, d_v)
    out, lse = _run_combine_decode(po, pl, attn_sink, d_v)

    if extra_k_cache is not None:
        (ek_fp8, ek_bf16, ek_s, _, _, _, _, ero, e8) = _flatten_kvcache(extra_k_cache, d_qk)
        epo, epl = _run_partial_decode(q, ek_fp8, ek_bf16, ek_s, extra_indices, extra_topk_length,
                                       dn, dr, nt, ts, ero, e8, softmax_scale, d_v)
        e_out, e_lse = _run_combine_decode(epo, epl, None, d_v)
        out, lse = _merge_two_outputs(out, lse, e_out, e_lse)
        if attn_sink is not None:
            sink_lse = attn_sink.view(1, 1, h_q).expand_as(lse)
            clse = torch.logaddexp(lse, sink_lse)
            w = torch.where(lse > -1e20, torch.exp(lse - clse), torch.zeros_like(lse))
            out = (out.float() * w.unsqueeze(-1)).to(torch.bfloat16)
            lse = clse

    return out, lse
